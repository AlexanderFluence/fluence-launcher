plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.fluence.launcher"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.fluence.launcher"
        minSdk = 24
        // La radio usa Android 10 (API 29)
        targetSdk = 29
        versionCode = 5
        versionName = "1.4"
    }

    // Firma fija: así las actualizaciones se instalan encima sin desinstalar
    signingConfigs {
        create("fija") {
            storeFile = file("fluence.keystore")
            storePassword = "fluence123"
            keyAlias = "fluence"
            keyPassword = "fluence123"
        }
    }

    buildTypes {
        debug {
            signingConfig = signingConfigs.getByName("fija")
        }
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("fija")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    lint {
        abortOnError = false
        checkReleaseBuilds = false
    }
}

dependencies {
    // Mapa de OpenStreetMap (sin claves ni cuentas)
    implementation("org.osmdroid:osmdroid-android:6.1.18")
}
