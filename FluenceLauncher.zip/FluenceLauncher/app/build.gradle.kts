plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.fluence.launcher"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.fluence.launcher"
        minSdk = 24
        // La radio usa Android 10 (API 29)
        targetSdk = 29
        versionCode = 7
        versionName = "1.6"

        // Las radios usan procesadores ARM (reduce el tamaño del APK)
        ndk {
            abiFilters += listOf("armeabi-v7a", "arm64-v8a")
        }
    }

    // Firma fija: así las actualizaciones se instalan encima sin desinstalar
    signingConfigs {
        create("fija") {
            storeFile = file("fluence.keystore")
            storePassword = "fluence123"
            keyAlias = "fluence"
            keyPassword = "fluence123"
        }
    }

    buildTypes {
        debug {
            signingConfig = signingConfigs.getByName("fija")
        }
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("fija")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    lint {
        abortOnError = false
        checkReleaseBuilds = false
    }
}

dependencies {
    // Mapa de OpenStreetMap (sin claves ni cuentas)
    implementation("org.osmdroid:osmdroid-android:6.1.18")
    // Reconocimiento de voz sin internet ("Oye copiloto")
    implementation("net.java.dev.jna:jna:5.18.1@aar")
    implementation("com.alphacephei:vosk-android:0.3.75@aar")
}
