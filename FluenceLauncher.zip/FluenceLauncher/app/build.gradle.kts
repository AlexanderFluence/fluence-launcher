plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.fluence.launcher"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.fluence.launcher"
        minSdk = 24
        // La radio usa Android 10 (API 29)
        targetSdk = 29
        versionCode = 15
        versionName = "1.14"
    }

    // Firma fija: así las actualizaciones se instalan encima sin desinstalar
    signingConfigs {
        create("fija") {
            storeFile = file("fluence.keystore")
            storePassword = "fluence123"
            keyAlias = "fluence"
            keyPassword = "fluence123"
        }
    }

    buildTypes {
        debug {
            signingConfig = signingConfigs.getByName("fija")
        }
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("fija")
        }
    }

    buildFeatures {
        buildConfig = true
    }

    // Dos apps desde el mismo código: la pantalla de inicio de la radio y la app para el celular
    flavorDimensions += "device"
    productFlavors {
        create("radio") {
            dimension = "device"
            buildConfigField("boolean", "PHONE", "false")
        }
        create("phone") {
            dimension = "device"
            applicationId = "com.fluence.drive"
            // El S24 Ultra usa Android 14 o más nuevo
            targetSdk = 33
            buildConfigField("boolean", "PHONE", "true")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    lint {
        abortOnError = false
        checkReleaseBuilds = false
    }
}

dependencies {
    // Mapa de OpenStreetMap (sin claves ni cuentas)
    implementation("org.osmdroid:osmdroid-android:6.1.18")
}
