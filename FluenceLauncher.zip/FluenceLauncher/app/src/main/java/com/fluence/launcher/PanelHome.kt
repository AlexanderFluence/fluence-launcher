package com.fluence.launcher

import android.content.Context
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.location.Location
import android.os.Handler
import android.os.Looper
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import java.util.Calendar
import java.util.Locale
import kotlin.math.roundToInt

/**
 * Estilo "Panel": tarjetas oscuras con acento dorado.
 * Reloj + clima + auto a la izquierda; Navegar (con voz), Spotify y Viaje a la derecha;
 * Aceite/odómetro abajo a la izquierda y barra de apps abajo.
 * Diseñado sobre 1024×600 y escalado a la pantalla real.
 */
class PanelHome(private val activity: MainActivity) : HomeScreen, Odometer.Listener {

    private val ctx: Context = activity
    private val es = Locale("es")
    private val main = Handler(Looper.getMainLooper())

    private val ACCENT = Color.rgb(230, 211, 166)
    private val TEXT = Color.rgb(240, 240, 242)
    private val MUTED = Color.rgb(140, 140, 146)
    private val CARD = Color.rgb(17, 17, 19)
    private val LINE = Color.rgb(46, 46, 50)
    private val GREEN = Color.rgb(74, 222, 128)

    override val root = FrameLayout(activity).apply { setBackgroundColor(Color.rgb(10, 10, 11)) }

    /** Escala de diseño: 1 px de diseño = s px reales. */
    private var s = 1f
    private var ox = 0f
    private var oy = 0f

    // Cada vista con su rectángulo de diseño (x, y, w, h); -2 = tamaño automático
    private val placed = ArrayList<Pair<View, FloatArray>>()
    // Textos con su tamaño de diseño para reescalar
    private val sized = ArrayList<Pair<TextView, Float>>()
    private val scaledPads = ArrayList<Pair<View, FloatArray>>()
    private val scaledRadius = ArrayList<Pair<GradientDrawable, Float>>()

    // ---- Izquierda ----
    private val greet = text(MUTED, 11.5f, "sans-serif-medium").apply { letterSpacing = 0.16f }
    private val clock = text(TEXT, 84f, "sans-serif-light")
    private val date = text(MUTED, 15f)
    private val weatherText = text(TEXT, 15f)
    private val weatherCity = text(ACCENT, 15f)
    private val car = CarView(activity)

    private val oilValue = text(TEXT, 20f)
    private val oilBar = bar()
    private val oilNext = text(MUTED, 10.5f)
    private val odoValue = text(TEXT, 20f)
    private val odoSub = label("ODÓMETRO")

    // ---- Derecha ----
    private val netDot = View(activity)
    private val netText = text(TEXT, 12.5f)
    private val navWaze = TextView(activity)
    private val navGmaps = TextView(activity)
    private val media = MediaPanel(activity, wide = true)

    private val tripStatusDot = View(activity)
    private val tripStatus = text(GREEN, 12.5f)
    private val tripKm = text(TEXT, 34f, "sans-serif-light")
    private val tripTime = text(TEXT, 24f, "sans-serif-light")
    private val tripAvg = text(TEXT, 24f, "sans-serif-light")
    private val barALabel = label("ACEITE")
    private val barAValue = text(TEXT, 11.5f)
    private val barA = bar()
    private val barBLabel = label("SOAT")
    private val barBValue = text(TEXT, 11.5f)
    private val barB = bar()
    private val lastDest = text(TEXT, 16f).apply {
        maxLines = 1
        ellipsize = TextUtils.TruncateAt.END
    }

    private var speedKmh = -1f
    private var micViews: Pair<ImageView, Float>? = null
    private var micLabel: TextView? = null
    private val bars = ArrayList<Pair<ProgressBar, Float>>()
    private var chipView: View? = null
    private var fieldView: View? = null
    private var navRow: View? = null
    private val sizedIcons = ArrayList<Pair<ImageView, Float>>()
    private val pills = ArrayList<TextView>()
    private val tiles = ArrayList<View>()
    private var lastKmInt = -1L

    private val ticker = object : Runnable {
        override fun run() {
            refreshNet()
            refreshTripTexts()
            refreshWeather(false)
            main.postDelayed(this, 30_000L)
        }
    }

    init {
        buildLeft()
        buildRight()
        buildDock()
        root.addOnLayoutChangeListener { _, l, t, r, b, ol, ot, or_, ob ->
            if (r - l != or_ - ol || b - t != ob - ot) layout(r - l, b - t)
        }
    }

    // =================== Construcción ===================

    private fun buildLeft() {
        put(greet, 28f, 24f)
        put(clock, 22f, 36f)

        // Botón de voz junto al reloj
        val mic = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setOnClickListener { Voice.start(activity) }
        }
        val micCircle = ImageView(ctx).apply {
            setImageResource(R.drawable.ic_mic)
            imageTintList = ColorStateList.valueOf(ACCENT)
            background = outline(28f, transparent = true)
        }
        mic.addView(micCircle)
        micLabel = text(MUTED, 11f).apply {
            text = "Voz"
            gravity = Gravity.CENTER
            maxLines = 2
        }
        mic.addView(micLabel)
        put(mic, 344f, 40f, 96f, -2f)
        pads(micCircle, 14f, 14f, 14f, 14f)
        micCircle.layoutParams = LinearLayout.LayoutParams(0, 0) // se ajusta en layout()
        micViews = Pair(micCircle, 56f)

        put(date, 28f, 128f)
        val weather = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        weather.addView(weatherText)
        weather.addView(weatherCity)
        weather.setOnClickListener { refreshWeather(true) }
        put(weather, 28f, 154f)

        car.setOnLongClickListener {
            activity.onCarLongClick()
            true
        }
        put(car, 14f, 182f, 430f, 232f)

        // Tarjeta Aceite + odómetro
        val oil = card()
        oil.orientation = LinearLayout.VERTICAL
        oil.addView(label("ACEITE Y KILOMETRAJE"))
        val row = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val leftCol = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        leftCol.addView(oilValue)
        leftCol.addView(label("PARA CAMBIO"))
        row.addView(leftCol)
        val midCol = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
        }
        midCol.addView(oilBar, LinearLayout.LayoutParams(-1, 0))
        midCol.addView(oilNext)
        row.addView(midCol, LinearLayout.LayoutParams(0, -2, 1f))
        pads(midCol, 16f, 0f, 16f, 0f)
        val rightCol = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.END
        }
        rightCol.addView(odoValue)
        rightCol.addView(odoSub)
        row.addView(rightCol)
        oil.addView(row, LinearLayout.LayoutParams(-1, -2))
        oil.setOnClickListener {
            if (Odometer.isSet(ctx)) activity.startActivity(Intent(ctx, MaintenanceActivity::class.java))
            else MaintenanceActivity.askOdometer(activity) { refreshMaintenance() }
        }
        oil.setOnLongClickListener {
            MaintenanceActivity.askOdometer(activity) { refreshMaintenance() }
            true
        }
        put(oil, 14f, 424f, 430f, 76f)
        bars.add(Pair(oilBar, 5f))
    }


    private fun buildRight() {
        // Estado de conexión + ajustes
        val chip = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = outline(14f)
            setOnClickListener { activity.startActivity(Intent(Settings_WIFI)) }
        }
        chip.addView(netDot)
        chip.addView(netText)
        pads(chip, 12f, 4f, 14f, 4f)
        put(chip, -1f, 10f, -2f, 28f) // alineado a la derecha en layout()
        chipView = chip

        val gear = ImageView(ctx).apply {
            setImageResource(R.drawable.ic_settings)
            imageTintList = ColorStateList.valueOf(MUTED)
            setOnClickListener { activity.startActivity(Intent(ctx, SettingsActivity::class.java)) }
        }
        put(gear, 984f, 12f, 26f, 26f)

        // ---- Navegar ----
        val nav = card()
        nav.orientation = LinearLayout.VERTICAL
        nav.addView(label("NAVEGAR"))
        val field = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = outline(10f, fill = Color.rgb(12, 12, 13))
            setOnClickListener { Voice.typed(activity) }
        }
        field.addView(text(MUTED, 14f).apply { text = "¿A dónde vamos?" }, LinearLayout.LayoutParams(0, -2, 1f))
        val fieldMic = ImageView(ctx).apply {
            setImageResource(R.drawable.ic_mic)
            imageTintList = ColorStateList.valueOf(ACCENT)
            setOnClickListener { Voice.start(activity) }
        }
        field.addView(fieldMic)
        sizedIcons.add(Pair(fieldMic, 20f))
        pads(field, 14f, 0f, 10f, 0f)
        nav.addView(field, LinearLayout.LayoutParams(-1, 0))
        fieldView = field

        val row = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        styleToggle(navWaze, "Waze")
        styleToggle(navGmaps, "Google Maps")
        navWaze.setOnClickListener { Navigator.setApp(ctx, Navigator.WAZE); refreshNavApp() }
        navGmaps.setOnClickListener { Navigator.setApp(ctx, Navigator.GMAPS); refreshNavApp() }
        row.addView(navWaze)
        row.addView(navGmaps)
        row.addView(View(ctx), LinearLayout.LayoutParams(0, 1, 1f))
        row.addView(pill("Casa") { Navigator.goSaved(activity, Prefs.DEST_HOME, "Casa") }.also {
            it.setOnLongClickListener { _ -> Navigator.askSaved(activity, Prefs.DEST_HOME, "Casa"); true }
        })
        row.addView(pill("Trabajo") { Navigator.goSaved(activity, Prefs.DEST_WORK, "Trabajo") }.also {
            it.setOnLongClickListener { _ -> Navigator.askSaved(activity, Prefs.DEST_WORK, "Trabajo"); true }
        })
        row.addView(pill("Último") { goLast() })
        nav.addView(row, LinearLayout.LayoutParams(-1, -2))
        navRow = row
        put(nav, 462f, 50f, 548f, 116f)

        // ---- Spotify ----
        put(media.view, 462f, 175f, 548f, 78f)

        // ---- Viaje ----
        val trip = card()
        trip.orientation = LinearLayout.VERTICAL
        val head = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        head.addView(label("VIAJE · HOY"), LinearLayout.LayoutParams(0, -2, 1f))
        head.addView(tripStatusDot)
        head.addView(tripStatus)
        trip.addView(head, LinearLayout.LayoutParams(-1, -2))

        val stats = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.BOTTOM
        }
        stats.addView(stat(tripKm, "DISTANCIA DEL VIAJE"), LinearLayout.LayoutParams(0, -2, 1.25f))
        stats.addView(stat(tripTime, "TIEMPO MANEJANDO"), LinearLayout.LayoutParams(0, -2, 1f))
        stats.addView(stat(tripAvg, "VEL. PROMEDIO"), LinearLayout.LayoutParams(0, -2, 1f))
        trip.addView(stats, LinearLayout.LayoutParams(-1, -2))
        pads(stats, 0f, 6f, 0f, 14f)

        val barsRow = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        barsRow.addView(barBlock(barALabel, barAValue, barA), LinearLayout.LayoutParams(0, -2, 1f))
        barsRow.addView(View(ctx), LinearLayout.LayoutParams(0, 1, 0.06f))
        barsRow.addView(barBlock(barBLabel, barBValue, barB), LinearLayout.LayoutParams(0, -2, 1f))
        barsRow.setOnClickListener { activity.startActivity(Intent(ctx, MaintenanceActivity::class.java)) }
        trip.addView(barsRow, LinearLayout.LayoutParams(-1, -2))
        bars.add(Pair(barA, 5f))
        bars.add(Pair(barB, 5f))

        val lastLabel = label("ÚLTIMO DESTINO")
        trip.addView(lastLabel)
        pads(lastLabel, 0f, 16f, 0f, 2f)
        val bottom = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        bottom.addView(lastDest, LinearLayout.LayoutParams(0, -2, 1f))
        bottom.addView(pill("Navegar", filled = true) { goLast() })
        bottom.addView(pill("Mapa") { activity.startActivity(Intent(ctx, MapActivity::class.java)) })
        bottom.addView(pill("Reiniciar viaje") {
            Odometer.resetTrip(ctx)
            refreshTripTexts()
            Toast.makeText(ctx, "Viaje en 0 km", Toast.LENGTH_SHORT).show()
        })
        trip.addView(bottom, LinearLayout.LayoutParams(-1, -2))
        put(trip, 462f, 263f, 548f, 238f)
    }


    private fun buildDock() {
        val dock = card()
        dock.orientation = LinearLayout.HORIZONTAL
        dock.gravity = Gravity.CENTER_VERTICAL
        fun item(title: String, icon: Int?, letter: String?, onLong: (() -> Unit)? = null, action: () -> Unit) {
            val cell = LinearLayout(ctx).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                setOnClickListener {
                    it.playSoundEffect(android.view.SoundEffectConstants.CLICK)
                    action()
                }
                if (onLong != null) setOnLongClickListener {
                    it.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
                    onLong()
                    true
                }
            }
            val tile = FrameLayout(ctx).apply { background = outline(10f) }
            if (icon != null) {
                val iv = ImageView(ctx).apply {
                    setImageResource(icon)
                    imageTintList = ColorStateList.valueOf(TEXT)
                }
                tile.addView(iv, FrameLayout.LayoutParams(0, 0, Gravity.CENTER))
                sizedIcons.add(Pair(iv, 20f))
            } else {
                tile.addView(text(TEXT, 17f, "sans-serif-medium").apply {
                    text = letter
                    gravity = Gravity.CENTER
                }, FrameLayout.LayoutParams(-1, -1))
            }
            cell.addView(tile, LinearLayout.LayoutParams(0, 0))
            tiles.add(tile)
            cell.addView(text(MUTED, 11f).apply {
                text = title
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
                gravity = Gravity.CENTER
            })
            dock.addView(cell, LinearLayout.LayoutParams(0, -1, 1f))
        }
        item("Waze", null, "W") { openPkg("com.waze", "Waze") }
        item("Spotify", R.drawable.ic_music, null) { openPkg(MediaPanel.SPOTIFY, "Spotify") }
        item("CarPlay", R.drawable.ic_car, null, onLong = { activity.onCarPlayLongClick() }) { CarPlay.open(activity) }
        item("YouTube", R.drawable.ic_play, null) { openPkg("com.google.android.youtube", "YouTube") }
        item("Teléfono", R.drawable.ic_phone, null, onLong = { activity.onLaneLongClick(1) }) { Shortcuts.launch(activity, 1) }
        item("Mapa", R.drawable.ic_map, null) { activity.startActivity(Intent(ctx, MapActivity::class.java)) }
        item("Mantenimiento", R.drawable.ic_build, null) {
            activity.startActivity(Intent(ctx, MaintenanceActivity::class.java))
        }
        item("Apps", R.drawable.ic_apps, null) { Shortcuts.launch(activity, 0) }
        put(dock, 14f, 512f, 996f, 78f)
    }


    // =================== Escalado ===================

    private fun layout(w: Int, h: Int) {
        s = minOf(w / 1024f, h / 600f)
        ox = (w - 1024f * s) / 2f
        oy = (h - 600f * s) / 2f

        for ((tv, size) in sized) tv.setTextSize(TypedValue.COMPLEX_UNIT_PX, size * s)
        for ((v, p) in scaledPads) v.setPadding(u(p[0]), u(p[1]), u(p[2]), u(p[3]))
        for ((g, r) in scaledRadius) g.setCornerRadius(r * s)
        for ((b, hgt) in bars) b.layoutParams = b.layoutParams.apply { height = u(hgt) }
        for ((iv, sz) in sizedIcons) {
            val lp = iv.layoutParams
            lp.width = u(sz)
            lp.height = u(sz)
            iv.layoutParams = lp
        }
        for (t in tiles) t.layoutParams = (t.layoutParams as LinearLayout.LayoutParams).apply {
            width = u(42f); height = u(42f); bottomMargin = u(6f)
        }
        micViews?.let { (iv, sz) -> iv.layoutParams = LinearLayout.LayoutParams(u(sz), u(sz)).apply { bottomMargin = u(4f) } }
        fieldView?.let { f -> f.layoutParams = (f.layoutParams as LinearLayout.LayoutParams).apply { height = u(36f); topMargin = u(6f); bottomMargin = u(10f) } }
        for (pl in pills) pl.layoutParams = LinearLayout.LayoutParams(-2, u(32f)).apply { leftMargin = u(8f) }
        for (tv in listOf(navWaze, navGmaps)) tv.layoutParams = LinearLayout.LayoutParams(-2, u(32f)).apply { rightMargin = u(8f) }
        netDot.layoutParams = LinearLayout.LayoutParams(u(7f), u(7f)).apply { rightMargin = u(8f) }
        tripStatusDot.layoutParams = LinearLayout.LayoutParams(u(7f), u(7f)).apply { rightMargin = u(6f) }

        for ((v, r) in placed) {
            val lp = (v.layoutParams as? FrameLayout.LayoutParams) ?: FrameLayout.LayoutParams(-2, -2)
            lp.gravity = Gravity.TOP or Gravity.START
            lp.width = if (r[2] < 0) -2 else u(r[2])
            lp.height = if (r[3] < 0) -2 else u(r[3])
            lp.topMargin = (oy + r[1] * s).toInt()
            if (r[0] < 0) {
                // Alineado a la derecha (chip de conexión): termina antes del engranaje
                lp.gravity = Gravity.TOP or Gravity.END
                lp.rightMargin = (ox + (1024f - 976f) * s).toInt()
            } else {
                lp.leftMargin = (ox + r[0] * s).toInt()
            }
            v.layoutParams = lp
        }
        media.placeAt((ox + 462f * s).toInt(), (oy + 175f * s).toInt(), u(548f), u(78f))
        media.usePanelStyle(ACCENT, 16f * s, s)
        media.setArtSize(u(46f))
    }

    private fun u(v: Float) = (v * s).roundToInt()

    // =================== HomeScreen ===================

    override fun setGreeting(text: String) {
        val name = Prefs.get(ctx).getString(Prefs.NAME, "")?.trim().orEmpty()
        val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        val hello = when (h) {
            in 5..11 -> "BUENOS DÍAS"
            in 12..18 -> "BUENAS TARDES"
            else -> "BUENAS NOCHES"
        }
        greet.text = if (name.isEmpty()) hello else "$hello, ${name.uppercase(es)}"
    }

    override fun setClock(time: String, date: String) {
        clock.text = time
        this.date.text = date
        setGreeting("")
    }

    override fun setSpeed(kmh: Float) {
        speedKmh = kmh
        val moving = kmh > 5f
        tripStatus.text = when {
            kmh < 0f -> "Sin GPS"
            moving -> "Manejando · ${kmh.roundToInt()} km/h"
            else -> "Detenido"
        }
        val c = if (moving) GREEN else MUTED
        tripStatus.setTextColor(c)
        dot(tripStatusDot, c)
    }

    override fun setCar(bmp: Bitmap?) { car.bitmap = bmp }

    override fun onLocation(loc: Location) {
        // El primer punto de GPS permite pedir el clima
        if (Weather.current == null) refreshWeather(false)
    }

    override fun refresh() {
        micLabel?.text = if (WakeWord.enabled(ctx) && WakeWord.hasModel(ctx)) "Di «${WakeWord.display(ctx)}»" else "Voz"
        refreshNavApp()
        refreshMaintenance()
        refreshTripTexts()
        refreshNet()
        Weather.cached(ctx)?.let { showWeather(it) } ?: run {
            weatherText.text = "Clima: esperando ubicación"
            weatherCity.text = ""
        }
        val last = Navigator.saved(ctx, Prefs.DEST_LAST)
        lastDest.text = last.ifBlank { "Di o escribe un destino arriba" }
        lastDest.setTextColor(if (last.isBlank()) MUTED else TEXT)
    }

    override fun onResume() {
        Odometer.addListener(ctx, this)
        media.onResume()
        main.removeCallbacks(ticker)
        main.post(ticker)
    }

    override fun onPause() {
        Odometer.removeListener(this)
        media.onPause()
        main.removeCallbacks(ticker)
    }

    override fun onDestroy() {
        main.removeCallbacksAndMessages(null)
        media.onDestroy()
    }


    override fun onOdometer(totalKm: Double, tripKm: Double) {
        this.tripKm.text = "${String.format(es, "%,.1f", tripKm)} km"
        if (totalKm.toLong() != lastKmInt) {
            lastKmInt = totalKm.toLong()
            refreshMaintenance()
        }
        refreshTripTexts()
    }

    // =================== Datos ===================

    private fun refreshTripTexts() {
        tripKm.text = "${String.format(es, "%,.1f", Odometer.tripKm(ctx))} km"
        val ms = Odometer.tripMovingMs(ctx)
        val hrs = ms / 3_600_000L
        val mins = (ms / 60_000L) % 60
        tripTime.text = if (hrs > 0) "$hrs h $mins m" else "$mins min"
        val avg = Odometer.tripAvgKmh(ctx)
        tripAvg.text = if (avg > 0) "${avg.roundToInt()} km/h" else "-- km/h"
    }

    private fun refreshMaintenance() {
        val km = Odometer.totalKm(ctx)
        val items = Maintenance.load(ctx)
        val oil = items.firstOrNull { it.id == "aceite" } ?: items.firstOrNull { it.type == Maintenance.BY_KM }
        if (oil != null && Odometer.isSet(ctx)) {
            val st = Maintenance.status(ctx, oil, km)
            oilValue.text = if (st.remaining >= 0) "${Maintenance.fmtKm(st.remaining)} km" else "Vencido"
            oilValue.setTextColor(if (st.level == Maintenance.Level.OK) TEXT else Maintenance.color(st.level))
            oilBar.progress = ((1f - st.fraction) * 1000).toInt()
            tint(oilBar, if (st.level == Maintenance.Level.OK) ACCENT else Maintenance.color(st.level))
            oilNext.text = "Próximo cambio a los ${Maintenance.fmtKm(oil.lastKm + oil.interval)} km"
            barALabel.text = "ACEITE"
            barAValue.text = st.text
            barA.progress = oilBar.progress
            tint(barA, if (st.level == Maintenance.Level.OK) ACCENT else Maintenance.color(st.level))
        } else {
            oilValue.text = "—"
            oilBar.progress = 0
            oilNext.text = "Toca para ingresar los km de tu tablero"
            barAValue.text = "sin datos"
            barA.progress = 0
        }
        odoValue.text = if (Odometer.isSet(ctx)) "${Maintenance.fmtKm(km)} km" else "Toca aquí"
        odoSub.text = if (Odometer.isSet(ctx)) "ODÓMETRO" else "INGRESAR KM"

        // Segunda barra: lo más urgente que no sea el aceite (SOAT, revisión, frenos…)
        val other = items.filter { it.id != oil?.id }.map { Maintenance.status(ctx, it, km) }
            .sortedWith(compareBy<Maintenance.Status> { -it.level.ordinal }.thenByDescending { it.fraction })
            .firstOrNull()
        if (other != null) {
            barBLabel.text = other.item.name.uppercase(es)
            barBValue.text = other.text
            barB.progress = ((1f - other.fraction) * 1000).toInt()
            tint(barB, if (other.level == Maintenance.Level.OK) ACCENT else Maintenance.color(other.level))
        }
    }

    private fun refreshNet() {
        val st = NetStatus.read(ctx)
        netText.text = if (st.online) "En línea · ${st.label}" else st.label
        dot(netDot, if (st.online) GREEN else Color.rgb(248, 113, 113))
    }

    private fun refreshWeather(force: Boolean) {
        Weather.refresh(ctx, force) { showWeather(it) }
    }

    private fun showWeather(w: Weather.Now) {
        weatherText.text = "${w.icon} ${w.tempC}°C · ${w.text}${if (w.city.isNotBlank()) " · " else ""}"
        weatherCity.text = w.city
    }

    private fun refreshNavApp() {
        val waze = Navigator.app(ctx) == Navigator.WAZE
        setToggle(navWaze, waze)
        setToggle(navGmaps, !waze)
    }

    private fun goLast() {
        val last = Navigator.saved(ctx, Prefs.DEST_LAST)
        if (last.isBlank()) Voice.start(activity) else Navigator.navigate(activity, last)
    }

    private fun openPkg(pkg: String, name: String) {
        if (!Shortcuts.launchPackage(ctx, pkg)) Toast.makeText(ctx, "$name no está instalado", Toast.LENGTH_SHORT).show()
    }

    // =================== Componentes ===================

    private fun put(v: View, x: Float, y: Float, w: Float = -2f, h: Float = -2f) {
        root.addView(v, FrameLayout.LayoutParams(-2, -2))
        placed.add(Pair(v, floatArrayOf(x, y, w, h)))
    }

    private fun pads(v: View, l: Float, t: Float, r: Float, b: Float) {
        scaledPads.add(Pair(v, floatArrayOf(l, t, r, b)))
    }

    private fun text(color: Int, size: Float, family: String = "sans-serif") = TextView(ctx).apply {
        setTextColor(color)
        typeface = Typeface.create(family, Typeface.NORMAL)
        includeFontPadding = false
        sized.add(Pair(this, size))
    }

    private fun label(t: String) = text(MUTED, 10.5f, "sans-serif-medium").apply {
        text = t
        letterSpacing = 0.14f
    }

    private fun outline(radius: Float, transparent: Boolean = false, fill: Int = CARD) = GradientDrawable().apply {
        setColor(if (transparent) Color.TRANSPARENT else fill)
        setStroke(1, LINE)
        scaledRadius.add(Pair(this, radius))
    }

    private fun card() = LinearLayout(ctx).apply {
        background = outline(16f)
        pads(this, 16f, 12f, 16f, 12f)
    }

    private fun bar() = ProgressBar(ctx, null, android.R.attr.progressBarStyleHorizontal).apply {
        max = 1000
        progressTintList = ColorStateList.valueOf(ACCENT)
        progressBackgroundTintList = ColorStateList.valueOf(Color.rgb(50, 50, 54))
    }

    private fun tint(b: ProgressBar, c: Int) { b.progressTintList = ColorStateList.valueOf(c) }

    private fun dot(v: View, c: Int) {
        v.background = GradientDrawable().apply {
            setShape(GradientDrawable.OVAL)
            setColor(c)
        }
    }

    private fun stat(value: TextView, sub: String) = LinearLayout(ctx).apply {
        orientation = LinearLayout.VERTICAL
        addView(value)
        val l = label(sub)
        addView(l)
        pads(l, 0f, 6f, 0f, 0f)
    }

    private fun barBlock(name: TextView, value: TextView, b: ProgressBar) = LinearLayout(ctx).apply {
        orientation = LinearLayout.VERTICAL
        val head = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        name.maxLines = 1
        name.ellipsize = TextUtils.TruncateAt.END
        head.addView(name, LinearLayout.LayoutParams(0, -2, 1f))
        value.gravity = Gravity.END
        head.addView(value)
        addView(head, LinearLayout.LayoutParams(-1, -2))
        val spacer = View(ctx)
        addView(spacer, LinearLayout.LayoutParams(1, 0))
        pads(spacer, 0f, 0f, 0f, 0f)
        addView(b, LinearLayout.LayoutParams(-1, 0).apply { topMargin = 8 })
    }

    private fun pill(t: String, filled: Boolean = false, action: () -> Unit) = TextView(ctx).apply {
        text = t
        gravity = Gravity.CENTER
        setTextColor(if (filled) Color.rgb(20, 18, 14) else TEXT)
        typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        includeFontPadding = false
        sized.add(Pair(this, 13f))
        background = if (filled) GradientDrawable().apply {
            setColor(ACCENT)
            scaledRadius.add(Pair(this, 9f))
        } else outline(9f, transparent = true)
        pads(this, 14f, 0f, 14f, 0f)
        setOnClickListener { action() }
        pills.add(this)
    }

    private fun styleToggle(tv: TextView, t: String) {
        tv.text = t
        tv.gravity = Gravity.CENTER
        tv.includeFontPadding = false
        tv.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        sized.add(Pair(tv, 13f))
        pads(tv, 16f, 0f, 16f, 0f)
    }

    private fun setToggle(tv: TextView, on: Boolean) {
        tv.setTextColor(if (on) Color.rgb(20, 18, 14) else TEXT)
        tv.background = GradientDrawable().apply {
            setColor(if (on) ACCENT else Color.TRANSPARENT)
            if (!on) setStroke(1, LINE)
            setCornerRadius(9f * s)
        }
    }

    companion object {
        private const val Settings_WIFI = "android.settings.WIFI_SETTINGS"
    }
}
