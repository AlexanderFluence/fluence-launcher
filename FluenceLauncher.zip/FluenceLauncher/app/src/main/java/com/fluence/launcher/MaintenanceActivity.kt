package com.fluence.launcher

import android.app.Activity
import android.app.AlertDialog
import android.app.DatePickerDialog
import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.InputType
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/** Odómetro, viaje, mantenimientos y documentos. */
class MaintenanceActivity : Activity(), Odometer.Listener {

    private val dp by lazy { resources.displayMetrics.density }
    private lateinit var list: LinearLayout
    private lateinit var totalText: TextView
    private lateinit var tripText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val scroll = ScrollView(this).apply { setBackgroundColor(Color.rgb(8, 9, 12)) }
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            val p = (24 * dp).toInt()
            setPadding(p, (14 * dp).toInt(), p, (40 * dp).toInt())
        }
        scroll.addView(content)

        // Encabezado
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        header.addView(TextView(this).apply {
            text = "Mantenimiento"
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 26f)
            typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
        }, LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(ImageView(this).apply {
            setImageResource(R.drawable.ic_close)
            val pp = (10 * dp).toInt()
            setPadding(pp, pp, pp, pp)
            setOnClickListener { finish() }
        }, LinearLayout.LayoutParams((48 * dp).toInt(), (48 * dp).toInt()))
        content.addView(header)

        // Odómetro
        val odo = card()
        odo.orientation = LinearLayout.HORIZONTAL
        odo.gravity = Gravity.CENTER_VERTICAL
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(small("ODÓMETRO"))
        totalText = TextView(this).apply {
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 34f)
            typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
        }
        col.addView(totalText)
        tripText = TextView(this).apply {
            setTextColor(Color.rgb(160, 168, 182))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
        }
        col.addView(tripText)
        odo.addView(col, LinearLayout.LayoutParams(0, -2, 1f))
        odo.addView(button("Corregir km") { askOdometer(this) { refresh() } })
        odo.addView(button("Reiniciar viaje") {
            Odometer.resetTrip(this)
            toast("Viaje en 0 km")
        })
        content.addView(odo, cardParams())
        content.addView(small(
            "Los km se suman con el GPS de la radio, también mientras usas CarPlay o Waze. " +
                "Si no coinciden con tu tablero, toca \"Corregir km\"."
        ).apply { setPadding(0, (6 * dp).toInt(), 0, (10 * dp).toInt()) })

        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(list)

        content.addView(button("+ Agregar recordatorio") { editItem(null) }.apply {
            layoutParams = LinearLayout.LayoutParams(-2, (46 * dp).toInt()).apply { topMargin = (14 * dp).toInt() }
        })

        setContentView(scroll)
    }

    override fun onResume() {
        super.onResume()
        Odometer.addListener(this, this)
        refresh()
    }

    override fun onPause() {
        super.onPause()
        Odometer.removeListener(this)
    }

    override fun onOdometer(totalKm: Double, tripKm: Double) {
        totalText.text = if (Odometer.isSet(this)) "${Maintenance.fmtKm(totalKm)} km" else "Toca \"Corregir km\""
        tripText.text = "Viaje · ${String.format(Locale("es"), "%.1f", tripKm)} km"
    }

    private fun refresh() {
        onOdometer(Odometer.totalKm(this), Odometer.tripKm(this))
        list.removeAllViews()
        val items = Maintenance.load(this)
        val km = Odometer.totalKm(this)
        addSection("POR KILÓMETROS")
        for (it in items.filter { i -> i.type == Maintenance.BY_KM }) list.addView(itemCard(Maintenance.status(this, it, km)), cardParams())
        addSection("DOCUMENTOS")
        for (it in items.filter { i -> i.type == Maintenance.BY_DAYS }) list.addView(itemCard(Maintenance.status(this, it, km)), cardParams())
    }

    private fun addSection(title: String) {
        list.addView(small(title).apply { setPadding(0, (18 * dp).toInt(), 0, (2 * dp).toInt()) })
    }

    private fun itemCard(s: Maintenance.Status): View {
        val it = s.item
        val c = card()
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        top.addView(View(this).apply {
            background = GradientDrawable().apply {
                setShape(GradientDrawable.OVAL)
                setColor(Maintenance.color(s.level))
            }
        }, LinearLayout.LayoutParams((10 * dp).toInt(), (10 * dp).toInt()).apply { rightMargin = (12 * dp).toInt() })

        val texts = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        texts.addView(TextView(this).apply {
            text = it.name
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 17f)
        })
        val detail = if (it.type == Maintenance.BY_KM) {
            "Cada ${Maintenance.fmtKm(it.interval.toDouble())} km · último a los ${Maintenance.fmtKm(it.lastKm)} km"
        } else {
            "Vence el ${dateText(it.lastDate + it.interval * DAY_MS)}"
        }
        texts.addView(TextView(this).apply {
            text = "${s.text}  ·  $detail"
            setTextColor(Color.rgb(160, 168, 182))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13.5f)
        })
        top.addView(texts, LinearLayout.LayoutParams(0, -2, 1f))
        top.addView(button(if (it.type == Maintenance.BY_KM) "Lo hice hoy" else "Lo renové hoy") { markDone(it.id) })
        top.addView(button("Editar") { editItem(it) })
        c.addView(top)

        c.addView(ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 1000
            progress = (s.fraction * 1000).toInt()
            progressTintList = ColorStateList.valueOf(Maintenance.color(s.level))
            progressBackgroundTintList = ColorStateList.valueOf(Color.argb(50, 255, 255, 255))
        }, LinearLayout.LayoutParams(-1, (4 * dp).toInt()).apply { topMargin = (12 * dp).toInt() })
        return c
    }

    private fun markDone(id: String) {
        val items = Maintenance.load(this)
        val item = items.firstOrNull { it.id == id } ?: return
        if (item.type == Maintenance.BY_KM) item.lastKm = Odometer.totalKm(this)
        else item.lastDate = System.currentTimeMillis()
        Maintenance.save(this, items)
        toast("Listo: ${item.name}")
        refresh()
    }

    private fun editItem(existing: Maintenance.Item?) {
        val isNew = existing == null
        val form = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            val p = (20 * dp).toInt()
            setPadding(p, (8 * dp).toInt(), p, 0)
        }
        val name = field("Nombre", existing?.name ?: "", InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES)
        form.addView(name)

        val typeGroup = RadioGroup(this).apply { orientation = RadioGroup.HORIZONTAL }
        val byKm = RadioButton(this).apply { text = "Por kilómetros"; id = View.generateViewId() }
        val byDays = RadioButton(this).apply { text = "Por fecha"; id = View.generateViewId() }
        typeGroup.addView(byKm)
        typeGroup.addView(byDays)
        typeGroup.check(if (existing?.type == Maintenance.BY_DAYS) byDays.id else byKm.id)
        if (isNew) form.addView(typeGroup)

        val interval = field(
            if (existing?.type == Maintenance.BY_DAYS) "Cada cuántos días" else "Cada cuántos km (o días si es por fecha)",
            existing?.interval?.toString() ?: "", InputType.TYPE_CLASS_NUMBER
        )
        form.addView(interval)

        val lastKm = field("Km del tablero cuando lo hiciste", existing?.lastKm?.let { Maintenance.fmtKm(it) } ?: "",
            InputType.TYPE_CLASS_NUMBER)
        if (existing == null || existing.type == Maintenance.BY_KM) form.addView(lastKm)

        var due: Long = existing?.let { it.lastDate + it.interval * DAY_MS } ?: 0L
        val dueBtn = button(if (due > 0) "Vence el ${dateText(due)}" else "Elegir fecha de vencimiento") { }
        dueBtn.setOnClickListener {
            val cal = Calendar.getInstance()
            if (due > 0) cal.timeInMillis = due
            DatePickerDialog(this, { _, y, m, d ->
                val c = Calendar.getInstance()
                c.set(y, m, d, 12, 0, 0)
                due = c.timeInMillis
                dueBtn.text = "Vence el ${dateText(due)}"
            }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show()
        }
        if (existing == null || existing.type == Maintenance.BY_DAYS) form.addView(dueBtn)

        val b = AlertDialog.Builder(this)
            .setTitle(if (isNew) "Nuevo recordatorio" else existing!!.name)
            .setView(form)
            .setPositiveButton("Guardar") { _, _ ->
                val items = Maintenance.load(this)
                val type = if (isNew) (if (typeGroup.checkedRadioButtonId == byDays.id) Maintenance.BY_DAYS else Maintenance.BY_KM)
                else existing!!.type
                val iv = digits(interval.text.toString())?.toInt()?.takeIf { it > 0 }
                if (iv == null) {
                    toast("Escribe cada cuánto se hace")
                    return@setPositiveButton
                }
                val item = if (isNew) {
                    Maintenance.Item("i" + System.currentTimeMillis(), "", type, iv, Odometer.totalKm(this), System.currentTimeMillis())
                        .also { items.add(it) }
                } else items.firstOrNull { it.id == existing!!.id } ?: return@setPositiveButton
                item.name = name.text.toString().trim().ifEmpty { "Recordatorio" }
                item.interval = iv
                if (type == Maintenance.BY_KM) {
                    digits(lastKm.text.toString())?.let { item.lastKm = it }
                } else if (due > 0) {
                    item.lastDate = due - iv * DAY_MS
                }
                Maintenance.save(this, items)
                refresh()
            }
            .setNegativeButton("Cancelar", null)
        if (!isNew) {
            b.setNeutralButton("Eliminar") { _, _ ->
                val items = Maintenance.load(this)
                items.removeAll { it.id == existing!!.id }
                Maintenance.save(this, items)
                refresh()
            }
        }
        b.show()
    }

    // ---------- Componentes ----------

    private fun card() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        val p = (16 * dp).toInt()
        setPadding(p, p, p, p)
        background = GradientDrawable().apply {
            setCornerRadius(16 * dp)
            setColor(Color.rgb(20, 22, 28))
        }
    }

    private fun cardParams() = LinearLayout.LayoutParams(-1, -2).apply { topMargin = (10 * dp).toInt() }

    private fun small(text: String) = TextView(this).apply {
        this.text = text
        setTextColor(Color.rgb(130, 138, 152))
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
        letterSpacing = 0.08f
    }

    private fun field(hint: String, value: String, type: Int) = EditText(this).apply {
        this.hint = hint
        setText(value)
        inputType = type
        setSingleLine(true)
    }

    private fun button(text: String, action: () -> Unit) = Button(this).apply {
        this.text = text
        isAllCaps = false
        setTextColor(Color.WHITE)
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
        background = GradientDrawable().apply {
            setCornerRadius(22 * dp)
            setColor(Color.rgb(34, 38, 48))
        }
        val ph = (16 * dp).toInt()
        setPadding(ph, 0, ph, 0)
        stateListAnimator = null
        layoutParams = LinearLayout.LayoutParams(-2, (42 * dp).toInt()).apply { leftMargin = (8 * dp).toInt() }
        setOnClickListener { action() }
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    companion object {
        private const val DAY_MS = 24L * 60 * 60 * 1000

        fun dateText(ms: Long): String = SimpleDateFormat("d MMM yyyy", Locale("es")).format(Date(ms))

        /** "86.427" o "86,427 km" → 86427 */
        fun digits(s: String): Double? = s.filter { it.isDigit() }.takeIf { it.isNotEmpty() }?.toDoubleOrNull()

        /** Diálogo para ingresar los km del tablero. */
        fun askOdometer(ctx: Context, onDone: () -> Unit) {
            val dpx = ctx.resources.displayMetrics.density
            val input = EditText(ctx).apply {
                hint = "Ej: 86427"
                inputType = InputType.TYPE_CLASS_NUMBER
                setSingleLine(true)
                if (Odometer.isSet(ctx)) setText(Odometer.totalKm(ctx).toLong().toString())
            }
            val box = LinearLayout(ctx).apply {
                val p = (20 * dpx).toInt()
                setPadding(p, 0, p, 0)
                addView(input, LinearLayout.LayoutParams(-1, -2))
            }
            AlertDialog.Builder(ctx)
                .setTitle("¿Cuántos km marca tu tablero?")
                .setView(box)
                .setPositiveButton("Guardar") { _, _ ->
                    val km = digits(input.text.toString()) ?: return@setPositiveButton
                    val wasSet = Odometer.isSet(ctx)
                    val old = Odometer.totalKm(ctx)
                    Odometer.setTotalKm(ctx, km)
                    // La primera vez, los mantenimientos empiezan a contar desde este km
                    if (!wasSet) Maintenance.rebaseUntouched(ctx, old, km)
                    onDone()
                }
                .setNegativeButton("Cancelar", null)
                .show()
        }
    }
}
