package com.fluence.launcher

import android.content.Context
import android.os.Handler
import android.os.Looper
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

/** Clima actual (Open-Meteo, gratis y sin cuenta) y ciudad según la ubicación. */
object Weather {

    class Now(val tempC: Int, val code: Int, val city: String, val at: Long) {
        val icon: String get() = iconFor(code)
        val text: String get() = textFor(code)
    }

    private val main = Handler(Looper.getMainLooper())
    private var running = false
    var current: Now? = null
        private set

    /** Último clima guardado, para mostrar algo apenas se abre el launcher. */
    fun cached(ctx: Context): Now? {
        current?.let { return it }
        val raw = Prefs.get(ctx).getString(Prefs.WEATHER, null) ?: return null
        return try {
            val o = JSONObject(raw)
            Now(o.getInt("t"), o.getInt("c"), o.optString("city", ""), o.optLong("at", 0L)).also { current = it }
        } catch (e: Exception) {
            null
        }
    }

    /** Actualiza si pasaron más de 30 minutos. onDone se llama en el hilo principal. */
    fun refresh(ctx: Context, force: Boolean = false, onDone: (Now) -> Unit) {
        val c = cached(ctx)
        if (!force && c != null && System.currentTimeMillis() - c.at < 30 * 60_000L) {
            onDone(c)
            return
        }
        if (running) return
        val loc = LocationHub.last
        val p = Prefs.get(ctx)
        val lat = loc?.latitude ?: p.getFloat(Prefs.LAST_LAT, Float.NaN).toDouble()
        val lon = loc?.longitude ?: p.getFloat(Prefs.LAST_LON, Float.NaN).toDouble()
        if (lat.isNaN() || lon.isNaN()) return
        running = true
        val app = ctx.applicationContext
        Thread {
            val now = try {
                val json = fetch(
                    String.format(
                        Locale.US,
                        "https://api.open-meteo.com/v1/forecast?latitude=%.4f&longitude=%.4f&current=temperature_2m,weather_code",
                        lat, lon
                    )
                )
                val cur = JSONObject(json!!).getJSONObject("current")
                val t = Math.round(cur.getDouble("temperature_2m")).toInt()
                val code = cur.getInt("weather_code")
                val city = cityName(lat, lon) ?: c?.city.orEmpty()
                Now(t, code, city, System.currentTimeMillis())
            } catch (e: Exception) {
                null
            }
            main.post {
                running = false
                if (now != null) {
                    current = now
                    val o = JSONObject()
                    o.put("t", now.tempC)
                    o.put("c", now.code)
                    o.put("city", now.city)
                    o.put("at", now.at)
                    Prefs.get(app).edit().putString(Prefs.WEATHER, o.toString()).apply()
                    onDone(now)
                }
            }
        }.start()
    }

    private fun cityName(lat: Double, lon: Double): String? = try {
        val json = fetch(
            String.format(
                Locale.US,
                "https://nominatim.openstreetmap.org/reverse?format=jsonv2&lat=%.4f&lon=%.4f&zoom=10&accept-language=es",
                lat, lon
            )
        )
        val a = JSONObject(json!!).optJSONObject("address")
        if (a == null) null else {
            arrayOf("city", "town", "village", "county", "state_district", "state")
                .map { a.optString(it, "") }.firstOrNull { it.isNotBlank() }
                ?.removePrefix("Provincia de ")?.removePrefix("Lima Metropolitana")?.ifBlank { "Lima" }
        }
    } catch (e: Exception) {
        null
    }

    private fun fetch(url: String): String? {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 7000
        c.readTimeout = 7000
        c.setRequestProperty("User-Agent", "FluenceLauncher/1.5 (Android car launcher)")
        return try {
            if (c.responseCode != 200) null else c.inputStream.bufferedReader().use { it.readText() }
        } finally {
            c.disconnect()
        }
    }

    /** Códigos del tiempo de la OMM. */
    fun textFor(code: Int): String = when (code) {
        0 -> "Despejado"
        1, 2 -> "Parcialmente nublado"
        3 -> "Nublado"
        45, 48 -> "Neblina"
        in 51..57 -> "Llovizna"
        in 61..67, in 80..82 -> "Lluvia"
        in 71..77, 85, 86 -> "Nieve"
        in 95..99 -> "Tormenta"
        else -> "—"
    }

    fun iconFor(code: Int): String = when (code) {
        0 -> "☀"
        1, 2 -> "⛅"
        3 -> "☁"
        45, 48 -> "🌫"
        in 51..57 -> "🌦"
        in 61..67, in 80..82 -> "🌧"
        in 71..77, 85, 86 -> "❄"
        in 95..99 -> "⛈"
        else -> "☁"
    }
}
