package com.fluence.launcher

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import kotlin.math.max

/** Dibujo del auto por defecto (se usa en los dos estilos de inicio). Solo hilo principal. */
object CarArt {
    private val path = Path()
    private val rect = RectF()
    private val carPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val carLine = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; color = Color.rgb(103, 232, 249); strokeCap = Paint.Cap.ROUND
    }

    /** Proporción alto / ancho del dibujo. */
    const val ASPECT = 0.60f

    /** Sedán gris estilizado (vista frontal) cuando no hay foto del auto. */
    fun draw(canvas: Canvas, left: Float, top: Float, cw: Float) {
        carLine.strokeWidth = max(1.5f, cw * 0.006f)
        fun poly(color: Int, vararg pts: Float) {
            path.reset()
            path.moveTo(left + pts[0] * cw, top + pts[1] * cw)
            var i = 2
            while (i < pts.size) {
                path.lineTo(left + pts[i] * cw, top + pts[i + 1] * cw)
                i += 2
            }
            path.close()
            carPaint.color = color
            canvas.drawPath(path, carPaint)
        }
        fun rrect(color: Int, l: Float, t: Float, r: Float, b: Float, rad: Float) {
            rect.set(left + l * cw, top + t * cw, left + r * cw, top + b * cw)
            carPaint.color = color
            canvas.drawRoundRect(rect, rad * cw, rad * cw, carPaint)
        }
        fun oval(color: Int, l: Float, t: Float, r: Float, b: Float) {
            rect.set(left + l * cw, top + t * cw, left + r * cw, top + b * cw)
            carPaint.color = color
            canvas.drawOval(rect, carPaint)
        }

        // Llantas
        rrect(Color.rgb(17, 19, 23), 0.09f, 0.46f, 0.25f, 0.60f, 0.025f)
        rrect(Color.rgb(17, 19, 23), 0.75f, 0.46f, 0.91f, 0.60f, 0.025f)
        // Techo y parabrisas
        poly(Color.rgb(128, 136, 145), 0.30f, 0.03f, 0.70f, 0.03f, 0.82f, 0.23f, 0.18f, 0.23f)
        poly(Color.rgb(34, 46, 62), 0.33f, 0.055f, 0.67f, 0.055f, 0.77f, 0.215f, 0.23f, 0.215f)
        poly(Color.argb(150, 90, 115, 145), 0.36f, 0.07f, 0.45f, 0.07f, 0.34f, 0.20f, 0.27f, 0.20f)
        // Espejos
        poly(Color.rgb(110, 118, 127), 0.12f, 0.19f, 0.19f, 0.20f, 0.19f, 0.25f, 0.11f, 0.25f)
        poly(Color.rgb(110, 118, 127), 0.88f, 0.19f, 0.81f, 0.20f, 0.81f, 0.25f, 0.89f, 0.25f)
        // Capó
        poly(Color.rgb(176, 183, 191), 0.17f, 0.22f, 0.83f, 0.22f, 0.95f, 0.31f, 0.05f, 0.31f)
        // Frente / parachoques
        poly(
            Color.rgb(140, 148, 157),
            0.04f, 0.30f, 0.96f, 0.30f, 0.985f, 0.48f, 0.93f, 0.555f, 0.07f, 0.555f, 0.015f, 0.48f
        )
        // Faros
        poly(Color.rgb(220, 231, 242), 0.06f, 0.325f, 0.31f, 0.355f, 0.33f, 0.405f, 0.10f, 0.40f, 0.05f, 0.36f)
        poly(Color.rgb(220, 231, 242), 0.94f, 0.325f, 0.69f, 0.355f, 0.67f, 0.405f, 0.90f, 0.40f, 0.95f, 0.36f)
        canvas.drawLine(left + 0.08f * cw, top + 0.37f * cw, left + 0.29f * cw, top + 0.385f * cw, carLine)
        canvas.drawLine(left + 0.92f * cw, top + 0.37f * cw, left + 0.71f * cw, top + 0.385f * cw, carLine)
        // Parrilla y logo
        rrect(Color.rgb(40, 45, 52), 0.35f, 0.355f, 0.65f, 0.395f, 0.012f)
        poly(Color.rgb(229, 231, 235), 0.5f, 0.345f, 0.522f, 0.375f, 0.5f, 0.405f, 0.478f, 0.375f)
        // Toma de aire inferior y neblineros
        poly(Color.rgb(30, 34, 40), 0.28f, 0.44f, 0.72f, 0.44f, 0.68f, 0.53f, 0.32f, 0.53f)
        oval(Color.rgb(200, 210, 220), 0.12f, 0.45f, 0.18f, 0.49f)
        oval(Color.rgb(200, 210, 220), 0.82f, 0.45f, 0.88f, 0.49f)
        // Placa
        rrect(Color.rgb(20, 20, 20), 0.405f, 0.46f, 0.595f, 0.52f, 0.006f)
        rrect(Color.rgb(240, 240, 240), 0.41f, 0.465f, 0.59f, 0.515f, 0.005f)
    }

}
