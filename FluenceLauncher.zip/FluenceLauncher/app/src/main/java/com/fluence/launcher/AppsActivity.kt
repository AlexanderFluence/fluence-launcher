package com.fluence.launcher

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.Editable
import android.text.TextUtils
import android.text.TextWatcher
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.GridView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

/** Cajón con todas las apps. También sirve para elegir la app de un acceso. */
class AppsActivity : Activity() {

    data class AppEntry(val label: String, val pkg: String, val cls: String, val icon: Drawable)

    companion object {
        const val EXTRA_PICK_LANE = "pick_lane"
        // Caché en memoria para que el cajón abra al instante
        @Volatile private var cache: List<AppEntry>? = null
    }

    private var pickLane = -1
    private var all: List<AppEntry> = emptyList()
    private var shown: List<AppEntry> = emptyList()
    private lateinit var adapter: AppsAdapter
    private lateinit var empty: TextView
    private val dp by lazy { resources.displayMetrics.density }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        pickLane = intent.getIntExtra(EXTRA_PICK_LANE, -1)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(11, 20, 36))
            val p = (16 * dp).toInt()
            setPadding(p, (10 * dp).toInt(), p, 0)
        }

        // Barra superior: título, buscador y cerrar
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val title = TextView(this).apply {
            text = if (pickLane > 0) "Elige una app para \"${Shortcuts.DEFAULT_LABELS[pickLane]}\"" else "Todas las apps"
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 22f)
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        }
        bar.addView(title, LinearLayout.LayoutParams(0, -2, 1f))

        val search = EditText(this).apply {
            hint = "Buscar"
            setHintTextColor(Color.rgb(120, 135, 160))
            setTextColor(Color.WHITE)
            setSingleLine(true)
            setCompoundDrawablesRelativeWithIntrinsicBounds(R.drawable.ic_search, 0, 0, 0)
            compoundDrawablePadding = (8 * dp).toInt()
            val p = (12 * dp).toInt()
            setPadding(p, (8 * dp).toInt(), p, (8 * dp).toInt())
            background = GradientDrawable().apply {
                setCornerRadius(22 * dp)
                setColor(Color.rgb(24, 38, 66))
            }
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
                override fun afterTextChanged(s: Editable?) { filter(s?.toString().orEmpty()) }
            })
        }
        bar.addView(search, LinearLayout.LayoutParams((260 * dp).toInt(), (44 * dp).toInt()).apply {
            marginEnd = (12 * dp).toInt()
        })

        val close = ImageView(this).apply {
            setImageResource(R.drawable.ic_close)
            val p = (10 * dp).toInt()
            setPadding(p, p, p, p)
            val ta = obtainStyledAttributes(intArrayOf(android.R.attr.selectableItemBackgroundBorderless))
            background = ta.getDrawable(0)
            ta.recycle()
            setOnClickListener { finish() }
        }
        bar.addView(close, LinearLayout.LayoutParams((48 * dp).toInt(), (48 * dp).toInt()))
        root.addView(bar, LinearLayout.LayoutParams(-1, -2))

        empty = TextView(this).apply {
            text = "Cargando apps…"
            setTextColor(Color.rgb(168, 179, 199))
            gravity = Gravity.CENTER
            setPadding(0, (24 * dp).toInt(), 0, 0)
        }
        root.addView(empty, LinearLayout.LayoutParams(-1, -2))

        adapter = AppsAdapter()
        val grid = GridView(this).apply {
            numColumns = GridView.AUTO_FIT
            columnWidth = (112 * dp).toInt()
            stretchMode = GridView.STRETCH_COLUMN_WIDTH
            verticalSpacing = (6 * dp).toInt()
            horizontalSpacing = (6 * dp).toInt()
            setPadding(0, (10 * dp).toInt(), 0, (16 * dp).toInt())
            clipToPadding = false
            isFastScrollEnabled = true
            setSelector(android.R.color.transparent)
            adapter = this@AppsActivity.adapter
            setOnItemClickListener { _, _, pos, _ -> onAppClick(shown[pos]) }
            setOnItemLongClickListener { _, _, pos, _ ->
                if (pickLane <= 0) openAppInfo(shown[pos])
                true
            }
        }
        root.addView(grid, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)

        cache?.let { setApps(it) }
        loadApps()
    }

    override fun onPause() {
        super.onPause()
        currentFocus?.let {
            (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(it.windowToken, 0)
        }
    }

    private fun loadApps() {
        Thread {
            val pm = packageManager
            val launcherIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val list = try { pm.queryIntentActivities(launcherIntent, 0) } catch (e: Exception) { emptyList() }
            val apps = list
                .filter { it.activityInfo.packageName != packageName }
                .map {
                    AppEntry(
                        it.loadLabel(pm).toString(),
                        it.activityInfo.packageName,
                        it.activityInfo.name,
                        it.loadIcon(pm)
                    )
                }
                .sortedBy { it.label.lowercase() }
            cache = apps
            runOnUiThread { if (!isFinishing) setApps(apps) }
        }.start()
    }

    private var query = ""

    private fun setApps(apps: List<AppEntry>) {
        all = apps
        filter(query)
    }

    private fun filter(q: String) {
        query = q
        val needle = q.trim().lowercase()
        shown = if (needle.isEmpty()) all else all.filter { it.label.lowercase().contains(needle) }
        adapter.notifyDataSetChanged()
        empty.visibility = if (shown.isEmpty()) View.VISIBLE else View.GONE
        if (all.isNotEmpty() && shown.isEmpty()) empty.text = "No hay apps con ese nombre"
    }

    private fun onAppClick(app: AppEntry) {
        if (pickLane > 0) {
            Shortcuts.setCustom(this, pickLane, app.pkg)
            Toast.makeText(this, "Acceso cambiado a ${app.label}", Toast.LENGTH_SHORT).show()
            finish()
            return
        }
        try {
            val i = Intent(Intent.ACTION_MAIN)
                .addCategory(Intent.CATEGORY_LAUNCHER)
                .setClassName(app.pkg, app.cls)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
            startActivity(i)
            finish()
        } catch (e: Exception) {
            Toast.makeText(this, "No se pudo abrir ${app.label}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun openAppInfo(app: AppEntry) {
        try {
            startActivity(
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${app.pkg}"))
            )
        } catch (e: Exception) { }
    }

    private inner class AppsAdapter : BaseAdapter() {
        override fun getCount(): Int = shown.size
        override fun getItem(position: Int): Any = shown[position]
        override fun getItemId(position: Int): Long = position.toLong()

        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val cell = (convertView as? LinearLayout) ?: makeCell()
            val app = shown[position]
            (cell.getChildAt(0) as ImageView).setImageDrawable(app.icon)
            (cell.getChildAt(1) as TextView).text = app.label
            return cell
        }

        private fun makeCell(): LinearLayout {
            val ctx = this@AppsActivity
            return LinearLayout(ctx).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_HORIZONTAL
                val p = (8 * dp).toInt()
                setPadding(p, p, p, p)
                val ta = ctx.obtainStyledAttributes(intArrayOf(android.R.attr.selectableItemBackground))
                background = ta.getDrawable(0)
                ta.recycle()
                val icon = ImageView(ctx)
                addView(icon, LinearLayout.LayoutParams((60 * dp).toInt(), (60 * dp).toInt()))
                val label = TextView(ctx).apply {
                    setTextColor(Color.rgb(235, 240, 248))
                    setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
                    gravity = Gravity.CENTER
                    maxLines = 2
                    ellipsize = TextUtils.TruncateAt.END
                    setPadding(0, (6 * dp).toInt(), 0, 0)
                }
                addView(label, LinearLayout.LayoutParams(-1, -2))
            }
        }
    }
}
