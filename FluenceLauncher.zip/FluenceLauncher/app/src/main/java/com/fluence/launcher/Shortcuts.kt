package com.fluence.launcher

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.widget.Toast

/**
 * Accesos de la carretera: 0 = Todas las apps, 1 = Llamadas, 2 = Navegación, 3 = Ajustes.
 * Los accesos 1-3 se pueden cambiar con una pulsación larga.
 */
object Shortcuts {
    val DEFAULT_LABELS = arrayOf("Todas las apps", "Llamadas", "Navegación", "Ajustes")

    private val CANDIDATES: Array<Array<String>> = arrayOf(
        emptyArray<String>(),
        // Apps de teléfono Bluetooth de radios comunes (FYT, MTCD, TS) y marcadores estándar
        arrayOf(
            "com.syu.bt", "com.microntek.bluetooth", "com.ts.bt", "com.android.bluetooth.phone",
            "com.google.android.dialer", "com.android.dialer"
        ),
        arrayOf(
            "com.waze", "com.google.android.apps.maps", "com.google.android.apps.mapslite",
            "com.here.app.maps", "com.sygic.aura"
        ),
        arrayOf("com.syu.settings", "com.android.settings")
    )

    fun customPackage(ctx: Context, lane: Int): String? =
        Prefs.get(ctx).getString(Prefs.LANE_PKG + lane, null)

    fun setCustom(ctx: Context, lane: Int, pkg: String?) {
        val e = Prefs.get(ctx).edit()
        if (pkg == null) e.remove(Prefs.LANE_PKG + lane) else e.putString(Prefs.LANE_PKG + lane, pkg)
        e.apply()
    }

    fun labels(ctx: Context): Array<String> {
        val out = DEFAULT_LABELS.copyOf()
        val pm = ctx.packageManager
        for (lane in 1..3) {
            val pkg = customPackage(ctx, lane) ?: continue
            try {
                val info = pm.getApplicationInfo(pkg, 0)
                out[lane] = pm.getApplicationLabel(info).toString()
            } catch (e: Exception) {
                // App desinstalada: volver al acceso por defecto
                setCustom(ctx, lane, null)
            }
        }
        return out
    }

    fun launch(ctx: Context, lane: Int) {
        if (lane == 0) {
            ctx.startActivity(Intent(ctx, AppsActivity::class.java))
            return
        }
        val custom = customPackage(ctx, lane)
        if (custom != null && launchPackage(ctx, custom)) return
        for (pkg in CANDIDATES[lane]) {
            if (launchPackage(ctx, pkg)) return
        }
        val fallback = when (lane) {
            1 -> Intent(Intent.ACTION_DIAL)
            2 -> Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q="))
            else -> Intent(Settings.ACTION_SETTINGS)
        }
        try {
            fallback.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            ctx.startActivity(fallback)
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(
                ctx, "No encontré una app para esto. Mantén presionado para elegir una.",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    fun launchPackage(ctx: Context, pkg: String): Boolean {
        val intent = ctx.packageManager.getLaunchIntentForPackage(pkg) ?: return false
        return try {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
            ctx.startActivity(intent)
            true
        } catch (e: Exception) {
            false
        }
    }
}
