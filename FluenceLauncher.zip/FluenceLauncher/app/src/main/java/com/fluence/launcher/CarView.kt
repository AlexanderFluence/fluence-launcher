package com.fluence.launcher

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.view.View

/** El auto (foto del usuario o el dibujo por defecto) con una sombra suave. */
class CarView(context: Context) : View(context) {
    var bitmap: Bitmap? = null
        set(value) { field = value; invalidate() }
    private val shadow = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(170, 0, 0, 0) }
    private val bmpPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val rect = RectF()

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return
        val bmp = bitmap
        val aspect = if (bmp != null && bmp.width > 0) bmp.height.toFloat() / bmp.width else CarArt.ASPECT
        // Ajustar dentro del espacio dejando lugar para la sombra
        var cw = w * 0.92f
        var ch = cw * aspect
        if (ch > h * 0.9f) { ch = h * 0.9f; cw = ch / aspect }
        val left = (w - cw) / 2f
        val bottom = h * 0.95f
        val top = bottom - ch
        rect.set(left - cw * 0.03f, bottom - cw * 0.03f, left + cw * 1.03f, bottom + cw * 0.03f)
        canvas.drawOval(rect, shadow)
        if (bmp != null) {
            rect.set(left, top, left + cw, bottom)
            canvas.drawBitmap(bmp, null, rect, bmpPaint)
        } else {
            CarArt.draw(canvas, left, top, cw)
        }
    }
}
