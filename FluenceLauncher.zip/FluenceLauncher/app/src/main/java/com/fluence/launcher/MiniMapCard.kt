package com.fluence.launcher

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.location.Location
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.TextView

/** Mapa pequeño en la esquina superior derecha del inicio. Al tocarlo abre el mapa grande. */
class MiniMapCard(private val activity: Activity) {

    private val dp = activity.resources.displayMetrics.density
    val view = FrameLayout(activity)
    val map = LiveMap(activity, false)
    private val label = TextView(activity)
    private var hasFix = false
    private var hasStreet = false

    init {
        val radius = 16 * dp
        view.background = GradientDrawable().apply {
            setCornerRadius(radius)
            setColor(Color.rgb(14, 24, 44))
        }
        view.clipToOutline = true
        view.foreground = GradientDrawable().apply {
            setCornerRadius(radius)
            setColor(Color.TRANSPARENT)
            setStroke((1 * dp).toInt().coerceAtLeast(1), Color.argb(110, 34, 211, 238))
        }
        view.elevation = 6 * dp

        view.addView(map.view, FrameLayout.LayoutParams(-1, -1))

        label.apply {
            text = "Buscando señal GPS…"
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            gravity = Gravity.CENTER
            val p = (6 * dp).toInt()
            setPadding(p * 2, p, p * 2, p)
            setBackgroundColor(Color.argb(205, 11, 20, 36))
        }
        view.addView(label, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))

        // Capa transparente encima: el mapa pequeño no se arrastra, solo se toca para abrir
        val touch = View(activity).apply {
            contentDescription = "Abrir mapa"
            setOnClickListener { activity.startActivity(Intent(activity, MapActivity::class.java)) }
        }
        view.addView(touch, FrameLayout.LayoutParams(-1, -1))
    }

    /** Ubica el mapa a la derecha del auto, sin tapar la carretera ni los botones. */
    fun place(w: Int, h: Int) {
        val lp = (view.layoutParams as? FrameLayout.LayoutParams) ?: FrameLayout.LayoutParams(0, 0)
        val left = (0.765f * w).toInt()
        val right = (0.97f * w).toInt()
        val top = maxOf((0.12f * h).toInt(), (64 * dp).toInt())
        val bottom = (0.47f * h).toInt()
        lp.width = right - left
        lp.height = (bottom - top).coerceAtLeast((90 * dp).toInt())
        lp.leftMargin = left
        lp.topMargin = top
        lp.gravity = Gravity.TOP or Gravity.START
        view.layoutParams = lp
    }

    fun update(loc: Location) {
        map.update(loc)
        if (!hasFix) {
            hasFix = true
            if (!hasStreet) label.text = "Ubicación en vivo"
        }
    }

    fun setStreet(name: String) {
        hasStreet = true
        label.text = name
    }

    fun onResume() = map.onResume()
    fun onPause() = map.onPause()
    fun onDestroy() = map.onDestroy()
}
