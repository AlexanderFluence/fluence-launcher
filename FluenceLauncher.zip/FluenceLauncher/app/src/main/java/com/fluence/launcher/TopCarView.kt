package com.fluence.launcher

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.view.View
import kotlin.math.min

/** Auto blanco visto desde arriba (estilo "Claro"). Dibujado con formas: no usa imágenes. */
class TopCarView(context: Context) : View(context) {

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val shadow = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(60, 0, 0, 0) }
    private val r = RectF()
    private val path = Path()

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return
        // Proporción del auto: ancho = 0.46 × largo
        var len = h * 0.94f
        var wid = len * 0.46f
        if (wid > w * 0.9f) { wid = w * 0.9f; len = wid / 0.46f }
        val l = (w - wid) / 2f
        val t = (h - len) / 2f
        fun x(f: Float) = l + f * wid
        fun y(f: Float) = t + f * len

        // Sombra
        r.set(x(-0.04f), y(0.02f), x(1.04f), y(1.01f))
        canvas.drawRoundRect(r, wid * 0.42f, wid * 0.42f, shadow)

        // Espejos
        p.shader = null
        p.color = Color.rgb(230, 232, 236)
        r.set(x(-0.12f), y(0.30f), x(0.06f), y(0.36f)); canvas.drawRoundRect(r, wid * 0.04f, wid * 0.04f, p)
        r.set(x(0.94f), y(0.30f), x(1.12f), y(0.36f)); canvas.drawRoundRect(r, wid * 0.04f, wid * 0.04f, p)

        // Carrocería
        p.shader = LinearGradient(x(0f), 0f, x(1f), 0f,
            intArrayOf(Color.rgb(218, 221, 226), Color.WHITE, Color.rgb(218, 221, 226)), null, Shader.TileMode.CLAMP)
        r.set(x(0f), y(0f), x(1f), y(1f))
        canvas.drawRoundRect(r, wid * 0.40f, wid * 0.30f, p)

        // Techo de vidrio (parabrisas + techo + luneta)
        p.shader = LinearGradient(0f, y(0.24f), 0f, y(0.82f),
            intArrayOf(Color.rgb(70, 78, 92), Color.rgb(28, 32, 40), Color.rgb(60, 66, 78)), null, Shader.TileMode.CLAMP)
        path.reset()
        path.moveTo(x(0.16f), y(0.27f))
        path.quadTo(x(0.5f), y(0.21f), x(0.84f), y(0.27f))
        path.lineTo(x(0.88f), y(0.76f))
        path.quadTo(x(0.5f), y(0.82f), x(0.12f), y(0.76f))
        path.close()
        canvas.drawPath(path, p)

        // Brillo del techo
        p.shader = null
        p.color = Color.argb(45, 255, 255, 255)
        path.reset()
        path.moveTo(x(0.24f), y(0.30f)); path.lineTo(x(0.40f), y(0.29f)); path.lineTo(x(0.30f), y(0.70f)); path.lineTo(x(0.18f), y(0.70f)); path.close()
        canvas.drawPath(path, p)

        // Capó (línea)
        p.color = Color.rgb(205, 209, 215)
        p.style = Paint.Style.STROKE
        p.strokeWidth = min(w, h) * 0.006f
        path.reset()
        path.moveTo(x(0.20f), y(0.06f)); path.quadTo(x(0.5f), y(0.15f), x(0.80f), y(0.06f))
        canvas.drawPath(path, p)
        p.style = Paint.Style.FILL

        // Faros y luces traseras
        p.color = Color.rgb(250, 250, 240)
        r.set(x(0.08f), y(0.025f), x(0.30f), y(0.045f)); canvas.drawRoundRect(r, wid * 0.03f, wid * 0.03f, p)
        r.set(x(0.70f), y(0.025f), x(0.92f), y(0.045f)); canvas.drawRoundRect(r, wid * 0.03f, wid * 0.03f, p)
        p.color = Color.rgb(220, 60, 60)
        r.set(x(0.06f), y(0.955f), x(0.94f), y(0.972f)); canvas.drawRoundRect(r, wid * 0.03f, wid * 0.03f, p)
    }
}
