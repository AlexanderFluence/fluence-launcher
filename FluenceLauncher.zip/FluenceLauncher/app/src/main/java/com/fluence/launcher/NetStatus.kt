package com.fluence.launcher

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.wifi.WifiManager

/** "En línea · MiWiFi" / "En línea · Datos" / "Sin conexión". */
object NetStatus {

    class State(val online: Boolean, val label: String)

    @Suppress("DEPRECATION")
    fun read(ctx: Context): State {
        return try {
            val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val caps = cm.getNetworkCapabilities(cm.activeNetwork) ?: return State(false, "Sin conexión")
            val online = caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            if (!online) return State(false, "Sin conexión")
            when {
                caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> {
                    val wm = ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
                    val ssid = wm.connectionInfo?.ssid?.trim('"').orEmpty()
                    State(true, if (ssid.isBlank() || ssid.contains("unknown")) "WiFi" else ssid)
                }
                caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> State(true, "Datos móviles")
                else -> State(true, "Conectado")
            }
        } catch (e: Exception) {
            State(false, "Sin conexión")
        }
    }
}
