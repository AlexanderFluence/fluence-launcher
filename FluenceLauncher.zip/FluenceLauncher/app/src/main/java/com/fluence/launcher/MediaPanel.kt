package com.fluence.launcher

import android.app.Activity
import android.app.AlertDialog
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.AudioManager
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast

/** Tarjeta de música (Spotify u otra app) en la pantalla de inicio. */
class MediaPanel(private val activity: Activity) {

    private val ctx: Context = activity
    private val dp = ctx.resources.displayMetrics.density
    private val handler = Handler(Looper.getMainLooper())
    private val listenerComponent = ComponentName(ctx, MediaListener::class.java)

    val view: LinearLayout
    private val art: ImageView
    private val title: TextView
    private val artist: TextView
    private val playBtn: ImageButton
    private val progress: ProgressBar

    private var controller: MediaController? = null
    private var sessionManager: MediaSessionManager? = null
    private var listening = false
    private var resumed = false

    private val callback = SimpleMediaCallback(Runnable { updateUi() }, Runnable { refreshSessions() })

    private val sessionsListener = MediaSessionManager.OnActiveSessionsChangedListener { list ->
        pickController(list)
    }

    // Canción avisada directamente por Spotify (funciona sin "Acceso a notificaciones")
    private val spotifyListener: () -> Unit = { if (controller == null) updateUi() }

    private val ticker = object : Runnable {
        override fun run() {
            updateProgress()
            if (resumed && isPlaying()) handler.postDelayed(this, 1000)
        }
    }

    init {
        view = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            val pad = (10 * dp).toInt()
            setPadding(pad, pad, pad, pad)
            background = GradientDrawable().apply {
                setCornerRadius(16 * dp)
                setColor(Color.argb(215, 17, 28, 51))
                setStroke((1 * dp).toInt().coerceAtLeast(1), Color.argb(90, 34, 211, 238))
            }
            elevation = 6 * dp
        }

        art = ImageView(ctx).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            clipToOutline = true
            background = GradientDrawable().apply {
                setCornerRadius(10 * dp)
                setColor(Color.rgb(29, 185, 84))
            }
            setOnClickListener { onCardClick() }
        }
        view.addView(art, LinearLayout.LayoutParams(0, 0))

        val column = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding((12 * dp).toInt(), 0, 0, 0)
            setOnClickListener { onCardClick() }
        }
        view.addView(column, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f))

        title = TextView(ctx).apply {
            setTextColor(Color.WHITE)
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
            setTextSize(TypedValue.COMPLEX_UNIT_PX, 15 * dp)
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        }
        artist = TextView(ctx).apply {
            setTextColor(Color.rgb(168, 179, 199))
            setTextSize(TypedValue.COMPLEX_UNIT_PX, 12.5f * dp)
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        }
        column.addView(title)
        column.addView(artist)
        column.addView(View(ctx), LinearLayout.LayoutParams(1, 0, 1f))

        val controls = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        controls.addView(button(R.drawable.ic_prev) { prev() })
        playBtn = button(R.drawable.ic_play) { playPause() }
        controls.addView(playBtn)
        controls.addView(button(R.drawable.ic_next) { next() })
        column.addView(controls)

        progress = ProgressBar(ctx, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 1000
            progress = 0
            progressTintList = ColorStateList.valueOf(Color.rgb(34, 211, 238))
            progressBackgroundTintList = ColorStateList.valueOf(Color.argb(80, 255, 255, 255))
        }
        column.addView(progress, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, (4 * dp).toInt()))

        showIdle()
        SpotifyBroadcast.register(ctx)
        SpotifyBroadcast.addListener(spotifyListener)
    }

    private fun button(icon: Int, action: () -> Unit): ImageButton {
        val size = (38 * dp).toInt()
        return ImageButton(ctx).apply {
            setImageResource(icon)
            scaleType = ImageView.ScaleType.FIT_CENTER
            val p = (7 * dp).toInt()
            setPadding(p, p, p, p)
            val attrs = intArrayOf(android.R.attr.selectableItemBackgroundBorderless)
            val ta = ctx.obtainStyledAttributes(attrs)
            background = ta.getDrawable(0)
            ta.recycle()
            layoutParams = LinearLayout.LayoutParams(size, size)
            setOnClickListener { action() }
        }
    }

    /** Ubica la tarjeta según el tamaño de la pantalla (estilo neón). */
    fun place(w: Int, h: Int) {
        val cardW = maxOf((0.25f * w).toInt(), (240 * dp).toInt())
        val cardH = maxOf((0.22f * h).toInt(), (112 * dp).toInt())
        placeAt((0.035f * w).toInt(), (0.32f * h).toInt(), cardW, cardH)
    }

    /** Ubica la tarjeta en una posición exacta dentro de un FrameLayout. */
    fun placeAt(left: Int, top: Int, width: Int, height: Int) {
        val lp = (view.layoutParams as? FrameLayout.LayoutParams)
            ?: FrameLayout.LayoutParams(0, 0)
        lp.width = width
        lp.height = height
        lp.leftMargin = left
        lp.topMargin = top
        lp.gravity = Gravity.TOP or Gravity.START
        view.layoutParams = lp

        val artSize = height - (20 * dp).toInt()
        art.layoutParams = LinearLayout.LayoutParams(artSize, artSize)
    }

    /** Estilo plano y discreto para el inicio moderno. */
    fun useFlatStyle() {
        view.background = GradientDrawable().apply {
            setCornerRadius(18 * dp)
            setColor(Color.rgb(20, 22, 28))
        }
        view.elevation = 0f
        progress.progressTintList = ColorStateList.valueOf(Color.rgb(29, 185, 84))
    }

    fun onResume() {
        resumed = true
        refreshSessions()
        handler.removeCallbacks(ticker)
        handler.post(ticker)
    }

    fun onPause() {
        resumed = false
        handler.removeCallbacks(ticker)
    }

    fun onDestroy() {
        SpotifyBroadcast.removeListener(spotifyListener)
        handler.removeCallbacksAndMessages(null)
        stopListening()
        controller?.unregisterCallback(callback)
        controller = null
    }

    fun hasNotificationAccess(): Boolean {
        val flat = Settings.Secure.getString(ctx.contentResolver, "enabled_notification_listeners") ?: return false
        return flat.contains(listenerComponent.flattenToString()) || flat.contains(ctx.packageName)
    }

    fun refreshSessions() {
        if (!hasNotificationAccess()) {
            controller?.unregisterCallback(callback)
            controller = null
            updateUi()
            return
        }
        try {
            val msm = sessionManager
                ?: (ctx.getSystemService(Context.MEDIA_SESSION_SERVICE) as MediaSessionManager).also {
                    sessionManager = it
                }
            if (!listening) {
                msm.addOnActiveSessionsChangedListener(sessionsListener, listenerComponent, handler)
                listening = true
            }
            pickController(msm.getActiveSessions(listenerComponent))
        } catch (e: SecurityException) {
            showIdle()
        } catch (e: Exception) {
            showIdle()
        }
    }

    private fun stopListening() {
        if (listening) {
            try { sessionManager?.removeOnActiveSessionsChangedListener(sessionsListener) } catch (e: Exception) { }
            listening = false
        }
    }

    private fun pickController(list: List<MediaController>?) {
        val sessions = list ?: emptyList()
        val chosen = sessions.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING }
            ?: sessions.firstOrNull { it.packageName == SPOTIFY }
            ?: sessions.firstOrNull()

        if (chosen?.sessionToken != controller?.sessionToken || chosen == null) {
            controller?.unregisterCallback(callback)
            controller = chosen
            chosen?.registerCallback(callback, handler)
        }
        updateUi()
    }

    private fun isPlaying(): Boolean {
        val c = controller ?: return SpotifyBroadcast.hasData && SpotifyBroadcast.playing
        return c.playbackState?.state == PlaybackState.STATE_PLAYING
    }

    private fun showIdle() {
        title.text = "Spotify"
        artist.text = if (hasNotificationAccess() || SpotifyBroadcast.hasData) "Toca para abrir" else "Toca para ver la canción aquí"
        art.setImageResource(R.drawable.ic_music)
        art.scaleType = ImageView.ScaleType.CENTER_INSIDE
        progress.progress = 0
        playBtn.setImageResource(R.drawable.ic_play)
    }

    /** Muestra lo que avisa Spotify cuando no hay acceso a las sesiones de música. */
    private fun showSpotifyBroadcast() {
        title.text = SpotifyBroadcast.title.ifBlank { "Spotify" }
        artist.text = SpotifyBroadcast.artist
        val bmp = SpotifyBroadcast.art
        if (bmp != null) {
            art.scaleType = ImageView.ScaleType.CENTER_CROP
            art.setImageBitmap(bmp)
        } else {
            art.scaleType = ImageView.ScaleType.CENTER_INSIDE
            art.setImageResource(R.drawable.ic_music)
        }
        val playing = isPlaying()
        playBtn.setImageResource(if (playing) R.drawable.ic_pause else R.drawable.ic_play)
        updateProgress()
        if (playing && resumed) {
            handler.removeCallbacks(ticker)
            handler.postDelayed(ticker, 1000)
        }
    }

    private fun updateUi() {
        val c = controller
        val meta = c?.metadata
        if (c == null && SpotifyBroadcast.hasData) {
            showSpotifyBroadcast()
            return
        }
        if (c == null || meta == null) {
            showIdle()
            if (c != null) playBtn.setImageResource(if (isPlaying()) R.drawable.ic_pause else R.drawable.ic_play)
            return
        }
        val t = meta.getString(MediaMetadata.METADATA_KEY_TITLE)
            ?: meta.getString(MediaMetadata.METADATA_KEY_DISPLAY_TITLE) ?: "Sin título"
        val a = meta.getString(MediaMetadata.METADATA_KEY_ARTIST)
            ?: meta.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST)
            ?: meta.getString(MediaMetadata.METADATA_KEY_DISPLAY_SUBTITLE) ?: ""
        title.text = t
        artist.text = a

        val bmp: Bitmap? = meta.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
            ?: meta.getBitmap(MediaMetadata.METADATA_KEY_ART)
            ?: meta.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON)
        if (bmp != null) {
            art.scaleType = ImageView.ScaleType.CENTER_CROP
            art.setImageBitmap(bmp)
        } else {
            art.scaleType = ImageView.ScaleType.CENTER_INSIDE
            art.setImageResource(R.drawable.ic_music)
        }

        val playing = isPlaying()
        playBtn.setImageResource(if (playing) R.drawable.ic_pause else R.drawable.ic_play)
        updateProgress()
        if (playing && resumed) {
            handler.removeCallbacks(ticker)
            handler.postDelayed(ticker, 1000)
        }
    }

    private fun updateProgress() {
        val c = controller
        if (c == null) {
            val len = SpotifyBroadcast.lengthMs
            progress.progress = if (SpotifyBroadcast.hasData && len > 0)
                ((SpotifyBroadcast.positionNow() * 1000L) / len).toInt() else 0
            return
        }
        val state = c.playbackState ?: return
        val duration = c.metadata?.getLong(MediaMetadata.METADATA_KEY_DURATION) ?: 0L
        if (duration <= 0L) {
            progress.progress = 0
            return
        }
        var pos = state.position
        if (state.state == PlaybackState.STATE_PLAYING && state.lastPositionUpdateTime > 0) {
            val elapsed = SystemClock.elapsedRealtime() - state.lastPositionUpdateTime
            pos += (elapsed * state.playbackSpeed).toLong()
        }
        progress.progress = ((pos.coerceIn(0L, duration) * 1000L) / duration).toInt()
    }

    private fun playPause() {
        val c = controller
        if (c != null) {
            if (isPlaying()) c.transportControls.pause() else c.transportControls.play()
        } else {
            mediaKey(KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE)
            SpotifyBroadcast.assumePlaying(!SpotifyBroadcast.playing)
        }
    }

    private fun next() {
        val c = controller
        if (c != null) c.transportControls.skipToNext() else mediaKey(KeyEvent.KEYCODE_MEDIA_NEXT)
    }

    private fun prev() {
        val c = controller
        if (c != null) c.transportControls.skipToPrevious() else mediaKey(KeyEvent.KEYCODE_MEDIA_PREVIOUS)
    }

    private fun mediaKey(code: Int) {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
    }

    private fun onCardClick() {
        if (!hasNotificationAccess() && !SpotifyBroadcast.hasData) {
            AlertDialog.Builder(activity)
                .setTitle("Mostrar la canción en el inicio")
                .setMessage(
                    "Abre Spotify → Configuración (engranaje) y activa " +
                        "\"Estado de transmisión del dispositivo\" (Device Broadcast Status). " +
                        "Luego pon una canción y aparecerá aquí.\n\n" +
                        "Si tu radio lo permite, también puedes activar \"Fluence Launcher\" en Acceso a notificaciones.\n\n" +
                        "Los botones de reproducir, siguiente y anterior funcionan igual."
                )
                .setPositiveButton("Abrir Spotify") { _, _ -> openPlayer() }
                .setNeutralButton("Acceso a notificaciones") { _, _ ->
                    try {
                        activity.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
                    } catch (e: Exception) {
                        Toast.makeText(ctx, "Tu radio no tiene esta opción", Toast.LENGTH_LONG).show()
                    }
                }
                .setNegativeButton("Cerrar", null)
                .show()
            return
        }
        openPlayer()
    }

    private fun openPlayer() {
        val pkg = controller?.packageName ?: SPOTIFY
        if (!Shortcuts.launchPackage(ctx, pkg) && !Shortcuts.launchPackage(ctx, SPOTIFY)) {
            Toast.makeText(ctx, "Spotify no está instalado", Toast.LENGTH_LONG).show()
        }
    }

    companion object {
        const val SPOTIFY = "com.spotify.music"
    }
}
