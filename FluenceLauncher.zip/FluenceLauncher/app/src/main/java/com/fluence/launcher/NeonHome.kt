package com.fluence.launcher

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.location.Location
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

/** Estilo "Carretera neón": la primera versión del launcher. */
class NeonHome(private val activity: MainActivity) : HomeScreen {

    private val home = HomeView(activity)
    private val media = MediaPanel(activity)
    private val miniMap = MiniMapCard(activity)
    private val dp = activity.resources.displayMetrics.density
    override val root = FrameLayout(activity)

    init {
        home.listener = activity
        root.addView(home, FrameLayout.LayoutParams(-1, -1))
        root.addView(media.view, FrameLayout.LayoutParams(0, 0))
        root.addView(miniMap.view, FrameLayout.LayoutParams(0, 0))

        val gear = ImageView(activity).apply {
            setImageResource(R.drawable.ic_settings)
            val p = (10 * dp).toInt()
            setPadding(p, p, p, p)
            val ta = activity.obtainStyledAttributes(intArrayOf(android.R.attr.selectableItemBackgroundBorderless))
            background = ta.getDrawable(0)
            ta.recycle()
            contentDescription = "Ajustes del launcher"
            setOnClickListener { activity.startActivity(Intent(activity, SettingsActivity::class.java)) }
        }
        val gearSize = (48 * dp).toInt()
        root.addView(gear, FrameLayout.LayoutParams(gearSize, gearSize, Gravity.TOP or Gravity.END).apply {
            topMargin = (8 * dp).toInt()
            rightMargin = (12 * dp).toInt()
        })

        // Botón CarPlay: vuelve a ZLink sin reiniciarlo
        val carplay = LinearLayout(activity).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            val ph = (16 * dp).toInt()
            setPadding(ph, 0, ph + (4 * dp).toInt(), 0)
            background = GradientDrawable().apply {
                setCornerRadius(24 * dp)
                setColor(Color.argb(215, 17, 28, 51))
                setStroke((1.5f * dp).toInt().coerceAtLeast(1), Color.rgb(34, 211, 238))
            }
            elevation = 6 * dp
            addView(ImageView(activity).apply { setImageResource(R.drawable.ic_car) },
                LinearLayout.LayoutParams((24 * dp).toInt(), (24 * dp).toInt()))
            addView(TextView(activity).apply {
                text = "CarPlay"
                setTextColor(Color.WHITE)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 17f)
                typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
                setPadding((8 * dp).toInt(), 0, 0, 0)
            })
            contentDescription = "Abrir CarPlay"
            setOnClickListener { CarPlay.open(activity) }
            setOnLongClickListener {
                activity.onCarPlayLongClick()
                true
            }
        }
        root.addView(carplay, FrameLayout.LayoutParams(-2, (48 * dp).toInt(), Gravity.TOP or Gravity.END).apply {
            topMargin = (8 * dp).toInt()
            rightMargin = (72 * dp).toInt()
        })

        root.addOnLayoutChangeListener { _, l, t, r, b, ol, ot, or_, ob ->
            if (r - l != or_ - ol || b - t != ob - ot) {
                media.place(r - l, b - t)
                miniMap.place(r - l, b - t)
            }
        }
    }

    override fun setGreeting(text: String) { home.greetingText = text }

    override fun setClock(time: String, date: String) {
        home.timeText = time
        home.dateText = date
    }

    override fun setSpeed(kmh: Float) { home.speedKmh = kmh }
    override fun setCar(bmp: Bitmap?) { home.carBitmap = bmp }

    override fun onLocation(loc: Location) {
        if (miniMap.view.visibility == View.VISIBLE) miniMap.update(loc)
    }

    override fun onStreet(name: String) = miniMap.setStreet(name)

    override fun refresh() {
        val p = Prefs.get(activity)
        home.showSpeed = p.getBoolean(Prefs.SHOW_SPEED, true)
        home.animateRoad = p.getBoolean(Prefs.ANIMATE_ROAD, true)
        home.laneLabels = Shortcuts.labels(activity)
        miniMap.view.visibility = if (p.getBoolean(Prefs.MAP_HOME, true)) View.VISIBLE else View.GONE
    }

    /** Para que MainActivity actualice los nombres tras cambiar un acceso. */
    val laneLabels: Array<String> get() = home.laneLabels
    fun reloadLanes() { home.laneLabels = Shortcuts.labels(activity) }

    override fun onResume() {
        media.onResume()
        if (miniMap.view.visibility == View.VISIBLE) miniMap.onResume()
    }

    override fun onPause() {
        media.onPause()
        miniMap.onPause()
    }

    override fun onDestroy() {
        media.onDestroy()
        miniMap.onDestroy()
    }
}
