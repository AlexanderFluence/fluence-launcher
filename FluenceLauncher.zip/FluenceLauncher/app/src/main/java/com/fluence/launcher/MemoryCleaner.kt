package com.fluence.launcher

import android.app.ActivityManager
import android.content.Context
import android.content.pm.ApplicationInfo

/** Cierra procesos en segundo plano para liberar RAM (no toca la música que esté sonando). */
object MemoryCleaner {
    private val KEEP = setOf(
        "com.spotify.music", "com.waze", "com.google.android.apps.maps",
        "com.google.android.youtube", "com.zjinnova.zlink", "com.android.vending"
    )

    data class Ram(val availMb: Long, val totalMb: Long)

    fun ram(ctx: Context): Ram {
        val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        return Ram(mi.availMem / 1048576L, mi.totalMem / 1048576L)
    }

    /** Ejecutar en segundo plano. Devuelve los MB liberados. */
    fun clean(ctx: Context, keepAlso: Set<String> = emptySet()): Long {
        val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val before = ram(ctx).availMb
        val pm = ctx.packageManager
        val apps = try { pm.getInstalledApplications(0) } catch (e: Exception) { emptyList<ApplicationInfo>() }
        for (app in apps) {
            val pkg = app.packageName
            if (pkg == ctx.packageName || pkg in KEEP || pkg in keepAlso) continue
            if (app.flags and ApplicationInfo.FLAG_SYSTEM != 0) continue
            try { am.killBackgroundProcesses(pkg) } catch (e: Exception) { }
        }
        Runtime.getRuntime().gc()
        try { Thread.sleep(900) } catch (e: InterruptedException) { }
        val after = ram(ctx).availMb
        return (after - before).coerceAtLeast(0L)
    }
}
