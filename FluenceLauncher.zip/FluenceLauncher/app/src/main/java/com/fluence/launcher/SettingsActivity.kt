package com.fluence.launcher

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.audiofx.AudioEffect
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class SettingsActivity : Activity() {

    private val dp by lazy { resources.displayMetrics.density }
    private val main = Handler(Looper.getMainLooper())
    private lateinit var content: LinearLayout
    private lateinit var nameInput: EditText
    private lateinit var ramText: TextView
    private val bandBars = ArrayList<SeekBar>()
    private val bandValues = ArrayList<TextView>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val p = Prefs.get(this)

        val scroll = ScrollView(this).apply { setBackgroundColor(Color.rgb(11, 20, 36)) }
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            val pad = (20 * dp).toInt()
            setPadding(pad, (12 * dp).toInt(), pad, (40 * dp).toInt())
        }
        scroll.addView(content)

        // Encabezado
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        header.addView(TextView(this).apply {
            text = "Ajustes del launcher"
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 24f)
            typeface = Typeface.DEFAULT_BOLD
        }, LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(ImageView(this).apply {
            setImageResource(R.drawable.ic_close)
            val pp = (10 * dp).toInt()
            setPadding(pp, pp, pp, pp)
            val ta = obtainStyledAttributes(intArrayOf(android.R.attr.selectableItemBackgroundBorderless))
            background = ta.getDrawable(0)
            ta.recycle()
            setOnClickListener { finish() }
        }, LinearLayout.LayoutParams((48 * dp).toInt(), (48 * dp).toInt()))
        content.addView(header)

        // ---------- Personalización ----------
        section("Estilo de la pantalla de inicio")
        val styleNow = p.getString(Prefs.HOME_STYLE, MainActivity.STYLE_PANEL) ?: MainActivity.STYLE_PANEL
        fun styleBtn(id: String, name: String) = button((if (styleNow == id) "● " else "") + name) {
            p.edit().putString(Prefs.HOME_STYLE, id).apply()
            toast("Estilo $name")
            finish()
        }
        row(
            styleBtn(MainActivity.STYLE_PANEL, "Panel"),
            styleBtn(MainActivity.STYLE_MODERN, "Moderno"),
            styleBtn(MainActivity.STYLE_NEON, "Carretera neón")
        )

        section("Odómetro y mantenimiento")
        row(
            button("Corregir km del tablero") { MaintenanceActivity.askOdometer(this) { toast("Odómetro actualizado") } },
            button("Mantenimiento y SOAT") { startActivity(Intent(this, MaintenanceActivity::class.java)) }
        )
        note("Los km se suman con el GPS, también mientras usas CarPlay o Waze. Corrígelos de vez en cuando para que coincidan con tu tablero.")

        section("Personalización")
        label("Tu nombre (para el saludo)")
        nameInput = EditText(this).apply {
            setText(p.getString(Prefs.NAME, ""))
            hint = "Ej: Esteban"
            setHintTextColor(Color.rgb(120, 135, 160))
            setTextColor(Color.WHITE)
            setSingleLine(true)
            background = field()
            val pp = (12 * dp).toInt()
            setPadding(pp, pp, pp, pp)
        }
        content.addView(nameInput, LinearLayout.LayoutParams(-1, -2))
        row(
            button("Elegir foto de mi auto") { CarImage.pick(this) },
            button("Usar auto por defecto") {
                CarImage.reset(this)
                toast("Listo: auto por defecto")
            }
        )
        note(
            "Consejo: usa una imagen PNG \"sin fondo\" de un Renault Fluence gris (búscala así en Google " +
                "Imágenes y guárdala en una USB o en la radio). Si la foto tiene fondo blanco, la app " +
                "intentará quitarlo sola. También puedes mantener presionado el auto en el inicio."
        )

        // ---------- Sonido ----------
        section("Sonido")
        buildSound()

        // ---------- Música ----------
        section("Música (Spotify)")
        note("Para ver el título, artista y carátula en el inicio, activa \"Fluence Launcher\" en Acceso a notificaciones.")
        row(button("Activar acceso a notificaciones") {
            open(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        })

        // ---------- Mapa ----------
        section("Mapa en vivo")
        toggle("Mostrar mapa en el inicio", p.getBoolean(Prefs.MAP_HOME, true)) {
            p.edit().putBoolean(Prefs.MAP_HOME, it).apply()
        }
        toggle("Mapa oscuro", p.getBoolean(Prefs.MAP_DARK, true)) {
            p.edit().putBoolean(Prefs.MAP_DARK, it).apply()
        }
        row(button("Abrir mapa") { startActivity(Intent(this, MapActivity::class.java)) })
        note(
            "El mapa necesita internet para cargar las calles. Las zonas que ya viste quedan " +
                "guardadas en la radio y se ven aunque no haya señal. La posición usa el GPS de la radio."
        )

        // ---------- Rendimiento ----------
        section("Rendimiento")
        ramText = label("")
        updateRam()
        row(button("Liberar memoria ahora") { cleanMemory() })
        toggle("Animar la carretera al conducir", p.getBoolean(Prefs.ANIMATE_ROAD, true)) {
            p.edit().putBoolean(Prefs.ANIMATE_ROAD, it).apply()
        }
        toggle("Mostrar velocidad (GPS)", p.getBoolean(Prefs.SHOW_SPEED, true)) {
            p.edit().putBoolean(Prefs.SHOW_SPEED, it).apply()
        }
        note(
            "Para que toda la radio vaya más fluida: Ajustes > Acerca del dispositivo > toca 7 veces " +
                "\"Número de compilación\". Luego en Opciones de desarrollador pon las tres escalas de " +
                "animación en 0.5x y \"Límite de procesos en segundo plano\" en 3 o 4."
        )

        // ---------- Inicio y accesos ----------
        section("Pantalla de inicio")
        row(
            button("Usar como pantalla de inicio") {
                if (!open(Intent(Settings.ACTION_HOME_SETTINGS))) open(Intent(Settings.ACTION_SETTINGS))
            },
            button("Restablecer accesos") {
                for (lane in 1..3) Shortcuts.setCustom(this, lane, null)
                toast("Accesos restablecidos")
            }
        )
        note("En el inicio, mantén presionado Llamadas, Navegación o Ajustes para asignarles otra app.")

        setContentView(scroll)
    }

    override fun onPause() {
        super.onPause()
        Prefs.get(this).edit().putString(Prefs.NAME, nameInput.text.toString().trim()).apply()
    }

    override fun onDestroy() {
        super.onDestroy()
        main.removeCallbacksAndMessages(null)
    }

    // ---------- Sonido ----------

    private fun buildSound() {
        val p = Prefs.get(this)
        val bands = AudioFx.bandCount()
        val hasAny = bands > 0 || AudioFx.bass != null || AudioFx.loud != null

        if (!hasAny) {
            note(
                "Tu radio no permite un ecualizador global desde otras apps. " +
                    "Usa el ecualizador propio de la radio con el botón de abajo."
            )
        } else {
            toggle("Activar mejoras de sonido", p.getBoolean(Prefs.EQ_ENABLED, false)) {
                p.edit().putBoolean(Prefs.EQ_ENABLED, it).apply()
                AudioFx.applyFromPrefs(this)
            }
        }

        if (bands > 0) {
            label("Ajustes rápidos")
            val presets = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for (name in AudioFx.PRESETS.keys) {
                presets.addView(button(name) {
                    if (!p.getBoolean(Prefs.EQ_ENABLED, false)) {
                        p.edit().putBoolean(Prefs.EQ_ENABLED, true).apply()
                        toast("Mejoras de sonido activadas")
                    }
                    AudioFx.applyPreset(this, name)
                    refreshBands()
                })
            }
            val hs = HorizontalScrollView(this).apply {
                isHorizontalScrollBarEnabled = false
                addView(presets)
            }
            content.addView(hs, LinearLayout.LayoutParams(-1, -2))

            label("Ecualizador")
            val range = AudioFx.bandRange()
            for (b in 0 until bands) {
                val valueText = TextView(this)
                val bar = slider(
                    AudioFx.bandLabel(b), range[1] - range[0],
                    p.getInt(Prefs.EQ_BAND + b, 0) - range[0], valueText
                ) { progress ->
                    val level = progress + range[0]
                    valueText.text = db(level)
                    p.edit().putInt(Prefs.EQ_BAND + b, level).apply()
                    AudioFx.applyFromPrefs(this)
                }
                valueText.text = db(p.getInt(Prefs.EQ_BAND + b, 0))
                bandBars.add(bar)
                bandValues.add(valueText)
            }
        }

        if (AudioFx.bass != null) {
            val v = TextView(this)
            slider("Graves extra", 1000, p.getInt(Prefs.BASS, 0), v) { progress ->
                v.text = "${progress / 10}%"
                p.edit().putInt(Prefs.BASS, progress).apply()
                AudioFx.applyFromPrefs(this)
            }
            v.text = "${p.getInt(Prefs.BASS, 0) / 10}%"
        }

        if (AudioFx.loud != null) {
            val v = TextView(this)
            slider("Volumen extra", 1000, p.getInt(Prefs.LOUD, 0), v) { progress ->
                v.text = db(progress)
                p.edit().putInt(Prefs.LOUD, progress).apply()
                AudioFx.applyFromPrefs(this)
            }
            v.text = db(p.getInt(Prefs.LOUD, 0))
            note("Sube el volumen extra con cuidado: a mucho volumen puede distorsionar los parlantes.")
        }

        row(button("Ecualizador de la radio") { openSystemEq() })
    }

    private fun refreshBands() {
        val p = Prefs.get(this)
        val range = AudioFx.bandRange()
        for (b in bandBars.indices) {
            val lvl = p.getInt(Prefs.EQ_BAND + b, 0)
            bandBars[b].progress = lvl - range[0]
            bandValues[b].text = db(lvl)
        }
    }

    private fun db(mB: Int): String {
        val v = mB / 100f
        return (if (v > 0) "+" else "") + String.format(java.util.Locale.US, "%.1f dB", v)
    }

    private fun openSystemEq() {
        // Apps de ecualizador de radios comunes
        val known = arrayOf("com.syu.eq", "com.syu.sound", "com.microntek.eqaudio", "com.ts.eq", "com.android.audiofx")
        for (pkg in known) if (Shortcuts.launchPackage(this, pkg)) return
        val i = Intent(AudioEffect.ACTION_DISPLAY_AUDIO_EFFECT_CONTROL_PANEL)
            .putExtra(AudioEffect.EXTRA_AUDIO_SESSION, 0)
            .putExtra(AudioEffect.EXTRA_PACKAGE_NAME, packageName)
        if (!open(i)) toast("No encontré el ecualizador de la radio. Búscalo en Ajustes > Sonido.")
    }

    // ---------- Rendimiento ----------

    private fun updateRam() {
        val r = MemoryCleaner.ram(this)
        ramText.text = "Memoria libre: ${r.availMb} MB de ${r.totalMb} MB"
    }

    private fun cleanMemory() {
        toast("Liberando memoria…")
        Thread {
            val freed = MemoryCleaner.clean(this, setOfNotNull(CarPlay.findPackage(this)))
            main.post {
                if (!isFinishing) {
                    updateRam()
                    toast(if (freed > 0) "Se liberaron $freed MB" else "La memoria ya estaba optimizada")
                }
            }
        }.start()
    }

    // ---------- Imagen del auto ----------

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != CarImage.REQUEST_PICK || resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        toast("Procesando imagen…")
        Thread {
            val ok = CarImage.importFrom(this, uri)
            main.post { toast(if (ok) "¡Listo! Vuelve al inicio para verlo" else "No pude abrir esa imagen") }
        }.start()
    }

    // ---------- Componentes de la pantalla ----------

    private fun field() = GradientDrawable().apply {
        setCornerRadius(12 * dp)
        setColor(Color.rgb(24, 38, 66))
    }

    private fun section(title: String) {
        content.addView(TextView(this).apply {
            text = title
            setTextColor(Color.rgb(34, 211, 238))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 17f)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, (26 * dp).toInt(), 0, (6 * dp).toInt())
        })
    }

    private fun label(text: String): TextView {
        val t = TextView(this).apply {
            this.text = text
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
            setPadding(0, (10 * dp).toInt(), 0, (4 * dp).toInt())
        }
        content.addView(t)
        return t
    }

    private fun note(text: String) {
        content.addView(TextView(this).apply {
            this.text = text
            setTextColor(Color.rgb(150, 162, 184))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            setPadding(0, (6 * dp).toInt(), 0, (4 * dp).toInt())
        })
    }

    private fun button(text: String, action: () -> Unit): Button {
        return Button(this).apply {
            this.text = text
            isAllCaps = false
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            background = GradientDrawable().apply {
                setCornerRadius(22 * dp)
                setColor(Color.rgb(28, 50, 96))
                setStroke((1 * dp).toInt().coerceAtLeast(1), Color.argb(120, 34, 211, 238))
            }
            val ph = (18 * dp).toInt()
            setPadding(ph, 0, ph, 0)
            stateListAnimator = null
            setOnClickListener { action() }
            layoutParams = LinearLayout.LayoutParams(-2, (44 * dp).toInt()).apply {
                marginEnd = (10 * dp).toInt()
                topMargin = (8 * dp).toInt()
            }
        }
    }

    private fun row(vararg views: View) {
        val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for (v in views) r.addView(v)
        content.addView(r, LinearLayout.LayoutParams(-1, -2))
    }

    private fun toggle(text: String, checked: Boolean, onChange: (Boolean) -> Unit) {
        val s = Switch(this).apply {
            this.text = text
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
            isChecked = checked
            setPadding(0, (10 * dp).toInt(), 0, (10 * dp).toInt())
            setOnCheckedChangeListener { _, isOn -> onChange(isOn) }
        }
        content.addView(s, LinearLayout.LayoutParams(-1, -2))
    }

    private fun slider(
        title: String,
        max: Int,
        value: Int,
        valueText: TextView,
        onChange: (Int) -> Unit
    ): SeekBar {
        val r = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, (4 * dp).toInt(), 0, (4 * dp).toInt())
        }
        r.addView(TextView(this).apply {
            text = title
            setTextColor(Color.rgb(220, 225, 235))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
        }, LinearLayout.LayoutParams((110 * dp).toInt(), -2))
        val bar = SeekBar(this).apply {
            this.max = max
            progress = value.coerceIn(0, max)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    if (fromUser) onChange(progress)
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
        }
        r.addView(bar, LinearLayout.LayoutParams(0, (40 * dp).toInt(), 1f))
        valueText.setTextColor(Color.WHITE)
        valueText.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
        valueText.gravity = Gravity.END
        r.addView(valueText, LinearLayout.LayoutParams((80 * dp).toInt(), -2))
        content.addView(r, LinearLayout.LayoutParams(-1, -2))
        return bar
    }

    private fun open(intent: Intent): Boolean {
        return try {
            startActivity(intent)
            true
        } catch (e: Exception) {
            false
        }
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
}
