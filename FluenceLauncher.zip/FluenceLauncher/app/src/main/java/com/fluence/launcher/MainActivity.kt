package com.fluence.launcher

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.location.Location
import android.location.LocationManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.format.DateFormat
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity(), HomeView.Listener, LocationHub.Listener {

    private lateinit var home: HomeView
    private lateinit var media: MediaPanel
    private lateinit var miniMap: MiniMapCard
    private val main = Handler(Looper.getMainLooper())
    private val spanish = Locale("es")

    private var loadedCarVersion = -1L
    private var gpsOn = false
    private var lastSpeedAt = 0L
    private var askedLocation = false

    private val timeReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            updateClock()
        }
    }

    private val speedTimeout = object : Runnable {
        override fun run() {
            // Sin datos de GPS por más de 6 s: mostrar "--"
            if (System.currentTimeMillis() - lastSpeedAt > 6000) home.speedKmh = -1f
            main.postDelayed(this, 3000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = FrameLayout(this)
        home = HomeView(this)
        home.listener = this
        root.addView(home, FrameLayout.LayoutParams(-1, -1))

        media = MediaPanel(this)
        root.addView(media.view, FrameLayout.LayoutParams(0, 0))

        miniMap = MiniMapCard(this)
        root.addView(miniMap.view, FrameLayout.LayoutParams(0, 0))

        val dp = resources.displayMetrics.density
        val gear = ImageView(this).apply {
            setImageResource(R.drawable.ic_settings)
            val p = (10 * dp).toInt()
            setPadding(p, p, p, p)
            val ta = obtainStyledAttributes(intArrayOf(android.R.attr.selectableItemBackgroundBorderless))
            background = ta.getDrawable(0)
            ta.recycle()
            contentDescription = "Ajustes del launcher"
            setOnClickListener { startActivity(Intent(this@MainActivity, SettingsActivity::class.java)) }
        }
        val gearSize = (48 * dp).toInt()
        root.addView(gear, FrameLayout.LayoutParams(gearSize, gearSize, Gravity.TOP or Gravity.END).apply {
            topMargin = (8 * dp).toInt()
            rightMargin = (12 * dp).toInt()
        })

        // Botón CarPlay: vuelve a ZLink sin reiniciarlo
        val carplay = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            val ph = (16 * dp).toInt()
            setPadding(ph, 0, ph + (4 * dp).toInt(), 0)
            background = GradientDrawable().apply {
                setCornerRadius(24 * dp)
                setColor(Color.argb(215, 17, 28, 51))
                setStroke((1.5f * dp).toInt().coerceAtLeast(1), Color.rgb(34, 211, 238))
            }
            foreground = obtainStyledAttributes(intArrayOf(android.R.attr.selectableItemBackground)).let {
                val d = it.getDrawable(0)
                it.recycle()
                d
            }
            elevation = 6 * dp
            addView(ImageView(this@MainActivity).apply { setImageResource(R.drawable.ic_car) },
                LinearLayout.LayoutParams((24 * dp).toInt(), (24 * dp).toInt()))
            addView(TextView(this@MainActivity).apply {
                text = "CarPlay"
                setTextColor(Color.WHITE)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 17f)
                typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
                setPadding((8 * dp).toInt(), 0, 0, 0)
            })
            contentDescription = "Abrir CarPlay"
            setOnClickListener { CarPlay.open(this@MainActivity) }
            setOnLongClickListener {
                onCarPlayLongClick()
                true
            }
        }
        root.addView(carplay, FrameLayout.LayoutParams(-2, (48 * dp).toInt(), Gravity.TOP or Gravity.END).apply {
            topMargin = (8 * dp).toInt()
            rightMargin = (72 * dp).toInt()
        })

        root.addOnLayoutChangeListener { _, l, t, r, b, ol, ot, or_, ob ->
            if (r - l != or_ - ol || b - t != ob - ot) {
                media.place(r - l, b - t)
                miniMap.place(r - l, b - t)
            }
        }

        setContentView(root)
    }

    override fun onStart() {
        super.onStart()
        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_TIME_TICK)
            addAction(Intent.ACTION_TIME_CHANGED)
            addAction(Intent.ACTION_TIMEZONE_CHANGED)
            addAction(Intent.ACTION_DATE_CHANGED)
        }
        registerReceiver(timeReceiver, filter)
        startGps()
    }

    override fun onResume() {
        super.onResume()
        val p = Prefs.get(this)
        val name = p.getString(Prefs.NAME, "")?.trim().orEmpty()
        home.greetingText = if (name.isEmpty()) "Hola" else "Hola $name"
        home.showSpeed = p.getBoolean(Prefs.SHOW_SPEED, true)
        home.animateRoad = p.getBoolean(Prefs.ANIMATE_ROAD, true)
        home.laneLabels = Shortcuts.labels(this)
        updateClock()
        loadCarIfChanged()
        media.onResume()
        val showMap = p.getBoolean(Prefs.MAP_HOME, true)
        miniMap.view.visibility = if (showMap) View.VISIBLE else View.GONE
        if (showMap) miniMap.onResume()
        // Si cambió un ajuste (velocidad / mapa), encender o apagar el GPS
        if (p.getBoolean(Prefs.SHOW_SPEED, true) || showMap) startGps() else stopGps()
    }

    override fun onPause() {
        super.onPause()
        media.onPause()
        miniMap.onPause()
    }

    override fun onStop() {
        super.onStop()
        try { unregisterReceiver(timeReceiver) } catch (e: Exception) { }
        stopGps()
    }

    override fun onDestroy() {
        super.onDestroy()
        media.onDestroy()
        miniMap.onDestroy()
        main.removeCallbacksAndMessages(null)
    }

    // El botón atrás no hace nada en la pantalla de inicio
    @Deprecated("Deprecated in Java")
    override fun onBackPressed() { }

    private fun updateClock() {
        val now = Date()
        val pattern = if (DateFormat.is24HourFormat(this)) "H:mm" else "h:mm a"
        home.timeText = SimpleDateFormat(pattern, spanish).format(now)
        val date = SimpleDateFormat("EEEE, d 'de' MMMM", spanish).format(now)
        home.dateText = date.replaceFirstChar { if (it.isLowerCase()) it.titlecase(spanish) else it.toString() }
    }

    private fun loadCarIfChanged() {
        val version = Prefs.get(this).getLong(Prefs.CAR_VERSION, 0L)
        if (version == loadedCarVersion) return
        loadedCarVersion = version
        Thread {
            val bmp: Bitmap? = CarImage.load(this)
            main.post { home.carBitmap = bmp }
        }.start()
    }

    // ---------- GPS / velocidad ----------

    private fun startGps() {
        val p = Prefs.get(this)
        if (!p.getBoolean(Prefs.SHOW_SPEED, true) && !p.getBoolean(Prefs.MAP_HOME, true)) return
        if (gpsOn) return
        if (Build.VERSION.SDK_INT >= 23 && !LocationHub.hasPermission(this)) {
            if (!askedLocation) {
                askedLocation = true
                requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), REQ_LOCATION)
            }
            return
        }
        gpsOn = true
        LocationHub.add(this, this)
        main.removeCallbacks(speedTimeout)
        main.postDelayed(speedTimeout, 3000)
    }

    private fun stopGps() {
        if (!gpsOn) return
        gpsOn = false
        LocationHub.remove(this, this)
        main.removeCallbacks(speedTimeout)
    }

    override fun onLocation(loc: Location) {
        if (loc.provider == LocationManager.GPS_PROVIDER) {
            lastSpeedAt = System.currentTimeMillis()
            home.speedKmh = if (loc.hasSpeed()) loc.speed * 3.6f else 0f
        }
        if (miniMap.view.visibility == View.VISIBLE) miniMap.update(loc)
    }

    override fun onStreet(name: String) {
        miniMap.setStreet(name)
    }

    override fun onGpsLost() {
        home.speedKmh = -1f
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ_LOCATION && grantResults.isNotEmpty() &&
            grantResults[0] == PackageManager.PERMISSION_GRANTED
        ) {
            startGps()
        }
    }

    // ---------- Accesos de la carretera ----------

    override fun onLaneClick(lane: Int) {
        Shortcuts.launch(this, lane)
    }

    override fun onLaneLongClick(lane: Int) {
        if (lane == 0) {
            startActivity(Intent(this, SettingsActivity::class.java))
            return
        }
        val current = Shortcuts.DEFAULT_LABELS[lane]
        val options = arrayOf("Elegir otra app para \"$current\"", "Volver a la opción por defecto")
        AlertDialog.Builder(this)
            .setTitle(home.laneLabels[lane])
            .setItems(options) { _, which ->
                if (which == 0) {
                    startActivity(
                        Intent(this, AppsActivity::class.java).putExtra(AppsActivity.EXTRA_PICK_LANE, lane)
                    )
                } else {
                    Shortcuts.setCustom(this, lane, null)
                    home.laneLabels = Shortcuts.labels(this)
                }
            }
            .show()
    }

    private fun onCarPlayLongClick() {
        val current = CarPlay.findPackage(this)
        val name = current?.let {
            try { packageManager.getApplicationLabel(packageManager.getApplicationInfo(it, 0)).toString() }
            catch (e: Exception) { it }
        } ?: "ninguna"
        AlertDialog.Builder(this)
            .setTitle("CarPlay abre: $name")
            .setItems(arrayOf("Elegir otra app", "Buscar ZLink automáticamente")) { _, which ->
                if (which == 0) {
                    startActivity(
                        Intent(this, AppsActivity::class.java).putExtra(AppsActivity.EXTRA_PICK_LANE, CarPlay.PICK_ID)
                    )
                } else {
                    CarPlay.setPackage(this, null)
                    Toast.makeText(this, "Listo", Toast.LENGTH_SHORT).show()
                }
            }
            .show()
    }

    override fun onCarLongClick() {
        AlertDialog.Builder(this)
            .setTitle("Imagen del auto")
            .setItems(arrayOf("Elegir foto de mi auto", "Usar el auto por defecto")) { _, which ->
                if (which == 0) {
                    CarImage.pick(this)
                } else {
                    CarImage.reset(this)
                    loadCarIfChanged()
                }
            }
            .show()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != CarImage.REQUEST_PICK || resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        Toast.makeText(this, "Procesando imagen…", Toast.LENGTH_SHORT).show()
        Thread {
            val ok = CarImage.importFrom(this, uri)
            main.post {
                if (ok) loadCarIfChanged()
                else Toast.makeText(this, "No pude abrir esa imagen", Toast.LENGTH_LONG).show()
            }
        }.start()
    }

    companion object {
        private const val REQ_LOCATION = 77
    }
}
