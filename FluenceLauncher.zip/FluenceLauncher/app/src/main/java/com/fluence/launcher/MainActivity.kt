package com.fluence.launcher

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.location.Location
import android.location.LocationManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.format.DateFormat
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Pantalla de inicio. Maneja reloj, GPS, imagen del auto y diálogos;
 * el dibujo lo hace el estilo elegido (Moderno o Carretera neón).
 */
class MainActivity : Activity(), HomeView.Listener, LocationHub.Listener {

    private lateinit var screen: HomeScreen
    private var style = ""
    private val main = Handler(Looper.getMainLooper())
    private val spanish = Locale("es")

    private var loadedCarVersion = -1L
    private var gpsOn = false
    private var lastSpeedAt = 0L
    private var askedLocation = false
    private var pendingVoice: String? = null

    private val timeReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            updateClock()
        }
    }

    private val speedTimeout = object : Runnable {
        override fun run() {
            // Sin datos de GPS por más de 6 s: mostrar "--"
            if (System.currentTimeMillis() - lastSpeedAt > 6000) screen.setSpeed(-1f)
            main.postDelayed(this, 3000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        style = currentStyle()
        screen = when (style) {
            STYLE_NEON -> NeonHome(this)
            STYLE_MODERN -> ModernHome(this)
            STYLE_PANEL -> PanelHome(this)
            else -> LightHome(this)
        }
        setContentView(screen.root)
        screen.setSpeed(-1f)
        pendingVoice = intent?.getStringExtra(EXTRA_VOICE_TEXT)
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        intent?.getStringExtra(EXTRA_VOICE_TEXT)?.let { pendingVoice = it }
    }

    private fun currentStyle(): String =
        Prefs.get(this).getString(Prefs.HOME_STYLE, STYLE_LIGHT) ?: STYLE_LIGHT

    override fun onStart() {
        super.onStart()
        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_TIME_TICK)
            addAction(Intent.ACTION_TIME_CHANGED)
            addAction(Intent.ACTION_TIMEZONE_CHANGED)
            addAction(Intent.ACTION_DATE_CHANGED)
        }
        registerReceiver(timeReceiver, filter)
    }

    override fun onResume() {
        super.onResume()
        // Si se cambió el estilo en Ajustes, reconstruir la pantalla
        if (currentStyle() != style || dayNightChanged()) {
            recreate()
            return
        }
        // Primero mostrar la pantalla (reloj); el resto se hace después del primer cuadro
        updateClock()
        main.removeCallbacks(deferredResume)
        main.post(deferredResume)
        // Comando de voz que llegó desde la ventana "Te escucho…"
        pendingVoice?.let { text ->
            pendingVoice = null
            main.post { Voice.handle(this, text) }
        }
    }

    private val deferredResume = Runnable {
        if (isFinishing) return@Runnable
        val p = Prefs.get(this)
        val name = p.getString(Prefs.NAME, "")?.trim().orEmpty()
        screen.setGreeting(if (name.isEmpty()) "Hola" else "Hola $name")
        screen.refresh()
        loadCarIfChanged()
        screen.onResume()
        startGps()
    }

    override fun onPause() {
        super.onPause()
        main.removeCallbacks(deferredResume)
        screen.onPause()
        if (!WakeWord.background(this)) WakeWord.stop()
    }

    override fun onStop() {
        super.onStop()
        try { unregisterReceiver(timeReceiver) } catch (e: Exception) { }
        stopGps()
    }

    override fun onDestroy() {
        super.onDestroy()
        screen.onDestroy()
        main.removeCallbacksAndMessages(null)
    }

    // El botón atrás no hace nada en la pantalla de inicio
    @Deprecated("Deprecated in Java")
    override fun onBackPressed() { }

    /** Estilo Claro: ¿cambió de día a noche (o al revés) desde que se dibujó? */
    private fun dayNightChanged(): Boolean {
        val s = screen
        return s is LightHome && s.night != DayNight.isNight(this)
    }

    fun checkDayNight() {
        if (dayNightChanged()) recreate()
    }

    private fun updateClock() {
        if (::screen.isInitialized && dayNightChanged()) {
            main.post { recreate() }
            return
        }
        val now = Date()
        val pattern = if (DateFormat.is24HourFormat(this)) "H:mm" else "h:mm a"
        val datePattern = if (style == STYLE_MODERN || style == STYLE_LIGHT) "EEE d MMM" else "EEEE, d 'de' MMMM"
        val date = SimpleDateFormat(datePattern, spanish).format(now).replace(".", "")
        screen.setClock(
            SimpleDateFormat(pattern, spanish).format(now),
            date.replaceFirstChar { if (it.isLowerCase()) it.titlecase(spanish) else it.toString() }
        )
    }

    private fun loadCarIfChanged() {
        val version = Prefs.get(this).getLong(Prefs.CAR_VERSION, 0L)
        if (version == loadedCarVersion) return
        loadedCarVersion = version
        Thread {
            val bmp: Bitmap? = CarImage.load(this)
            main.post { screen.setCar(bmp) }
        }.start()
    }

    // ---------- GPS / velocidad / odómetro ----------

    private fun startGps() {
        val needMic = WakeWord.enabled(this) && WakeWord.hasModel(this) && !WakeWord.hasMic(this)
        if (Build.VERSION.SDK_INT >= 23 && (!LocationHub.hasPermission(this) || needMic)) {
            if (!askedLocation) {
                askedLocation = true
                val perms = ArrayList<String>()
                if (!LocationHub.hasPermission(this)) perms.add(Manifest.permission.ACCESS_FINE_LOCATION)
                if (needMic) perms.add(Manifest.permission.RECORD_AUDIO)
                requestPermissions(perms.toTypedArray(), REQ_LOCATION)
            }
            if (!LocationHub.hasPermission(this)) return
        }
        // El servicio suma km aunque el launcher no esté en pantalla (CarPlay, Waze…)
        TrackerService.start(this)
        if (gpsOn) return
        gpsOn = true
        LocationHub.add(this, this)
        main.removeCallbacks(speedTimeout)
        main.postDelayed(speedTimeout, 3000)
    }

    private fun stopGps() {
        if (!gpsOn) return
        gpsOn = false
        LocationHub.remove(this, this)
        main.removeCallbacks(speedTimeout)
    }

    override fun onLocation(loc: Location) {
        if (loc.provider == LocationManager.GPS_PROVIDER) {
            lastSpeedAt = System.currentTimeMillis()
            screen.setSpeed(if (loc.hasSpeed()) loc.speed * 3.6f else 0f)
        }
        screen.onLocation(loc)
    }

    override fun onStreet(name: String) = screen.onStreet(name)

    override fun onGpsLost() = screen.setSpeed(-1f)

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode != REQ_LOCATION) return
        if (LocationHub.hasPermission(this)) {
            startGps()
            LocationHub.retry(this)
        }
        if (WakeWord.hasMic(this)) WakeWord.start(this)
    }

    // ---------- Accesos ----------

    override fun onLaneClick(lane: Int) {
        Shortcuts.launch(this, lane)
    }

    override fun onLaneLongClick(lane: Int) {
        if (lane == 0) {
            startActivity(Intent(this, SettingsActivity::class.java))
            return
        }
        val current = Shortcuts.DEFAULT_LABELS[lane]
        val options = arrayOf("Elegir otra app para \"$current\"", "Volver a la opción por defecto")
        AlertDialog.Builder(this)
            .setTitle(Shortcuts.labels(this)[lane])
            .setItems(options) { _, which ->
                if (which == 0) {
                    startActivity(
                        Intent(this, AppsActivity::class.java).putExtra(AppsActivity.EXTRA_PICK_LANE, lane)
                    )
                } else {
                    Shortcuts.setCustom(this, lane, null)
                    screen.refresh()
                }
            }
            .show()
    }

    fun onCarPlayLongClick() {
        val current = CarPlay.findPackage(this)
        val name = current?.let {
            try { packageManager.getApplicationLabel(packageManager.getApplicationInfo(it, 0)).toString() }
            catch (e: Exception) { it }
        } ?: "ninguna"
        AlertDialog.Builder(this)
            .setTitle("CarPlay abre: $name")
            .setItems(arrayOf("Elegir otra app", "Buscar ZLink automáticamente")) { _, which ->
                if (which == 0) {
                    startActivity(
                        Intent(this, AppsActivity::class.java).putExtra(AppsActivity.EXTRA_PICK_LANE, CarPlay.PICK_ID)
                    )
                } else {
                    CarPlay.setPackage(this, null)
                    Toast.makeText(this, "Listo", Toast.LENGTH_SHORT).show()
                }
            }
            .show()
    }

    override fun onCarLongClick() {
        AlertDialog.Builder(this)
            .setTitle("Imagen del auto")
            .setItems(arrayOf("Elegir foto de mi auto", "Usar el auto por defecto")) { _, which ->
                if (which == 0) {
                    CarImage.pick(this)
                } else {
                    CarImage.reset(this)
                    loadCarIfChanged()
                }
            }
            .show()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == Voice.REQUEST) {
            if (resultCode == RESULT_OK) Voice.onResult(this, data)
            return
        }
        if (requestCode != CarImage.REQUEST_PICK || resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        Toast.makeText(this, "Procesando imagen…", Toast.LENGTH_SHORT).show()
        Thread {
            val ok = CarImage.importFrom(this, uri)
            main.post {
                if (ok) loadCarIfChanged()
                else Toast.makeText(this, "No pude abrir esa imagen", Toast.LENGTH_LONG).show()
            }
        }.start()
    }

    companion object {
        private const val REQ_LOCATION = 77
        const val STYLE_MODERN = "modern"
        const val STYLE_NEON = "neon"
        const val STYLE_PANEL = "panel"
        const val STYLE_LIGHT = "light"
        const val EXTRA_VOICE_TEXT = "voice_text"
    }
}
