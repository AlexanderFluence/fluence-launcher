package com.fluence.launcher

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationManager
import android.os.Handler
import android.os.Looper
import android.os.SystemClock

/**
 * Un solo GPS para toda la app: el inicio y el mapa grande reciben la misma ubicación.
 * También busca el nombre de la calle actual (cada ~12 s y solo si el auto se movió).
 */
object LocationHub {

    interface Listener {
        fun onLocation(loc: Location)
        fun onStreet(name: String) {}
        fun onGpsLost() {}
    }

    var last: Location? = null
        private set
    var street: String = ""
        private set

    private val listeners = LinkedHashSet<Listener>()
    private val main = Handler(Looper.getMainLooper())
    private var gps: GpsListener? = null
    private var app: Context? = null

    private var lastLookupAt = 0L
    private var lastLookupLoc: Location? = null
    private var lookupRunning = false
    private var lastSaveAt = 0L

    fun hasPermission(ctx: Context): Boolean =
        ctx.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED

    fun add(ctx: Context, l: Listener) {
        listeners.add(l)
        start(ctx)
        last?.let { l.onLocation(it) }
        if (street.isNotEmpty()) l.onStreet(street)
    }

    fun remove(ctx: Context, l: Listener) {
        listeners.remove(l)
        if (listeners.isEmpty()) stop(ctx)
    }

    /** Llamar después de conceder el permiso de ubicación. */
    fun retry(ctx: Context) {
        if (listeners.isNotEmpty()) start(ctx)
    }

    private fun start(ctx: Context) {
        if (gps != null || !hasPermission(ctx)) return
        val appCtx = ctx.applicationContext
        app = appCtx
        val lm = appCtx.getSystemService(Context.LOCATION_SERVICE) as? LocationManager ?: return

        if (last == null) {
            val known = listOfNotNull(
                lastKnown(lm, LocationManager.GPS_PROVIDER),
                lastKnown(lm, LocationManager.NETWORK_PROVIDER)
            ).maxByOrNull { it.time }
            if (known != null) last = known
        }

        val listener = GpsListener(object : GpsListener.Callback {
            override fun onLocation(location: Location) = deliver(location)
            override fun onLost() {
                for (l in listeners.toList()) l.onGpsLost()
            }
        })
        try {
            lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 0f, listener, Looper.getMainLooper())
            gps = listener
        } catch (e: SecurityException) {
        } catch (e: IllegalArgumentException) {
            // La radio no tiene GPS
        }
    }

    private fun stop(ctx: Context) {
        val listener = gps ?: return
        try {
            (ctx.applicationContext.getSystemService(Context.LOCATION_SERVICE) as LocationManager).removeUpdates(listener)
        } catch (e: Exception) { }
        gps = null
    }

    private fun lastKnown(lm: LocationManager, provider: String): Location? = try {
        lm.getLastKnownLocation(provider)
    } catch (e: Exception) {
        null
    }

    private fun deliver(loc: Location) {
        last = loc
        for (l in listeners.toList()) l.onLocation(loc)
        saveLast(loc)
        maybeLookupStreet(loc)
    }

    private fun saveLast(loc: Location) {
        val ctx = app ?: return
        val now = SystemClock.elapsedRealtime()
        if (now - lastSaveAt < 60_000L) return
        lastSaveAt = now
        Prefs.get(ctx).edit()
            .putFloat(Prefs.LAST_LAT, loc.latitude.toFloat())
            .putFloat(Prefs.LAST_LON, loc.longitude.toFloat())
            .apply()
    }

    private fun maybeLookupStreet(loc: Location) {
        val ctx = app ?: return
        if (lookupRunning) return
        val now = SystemClock.elapsedRealtime()
        val prev = lastLookupLoc
        val due = prev == null ||
            (now - lastLookupAt >= 12_000L && loc.distanceTo(prev) >= 30f) ||
            (street.isEmpty() && now - lastLookupAt >= 30_000L)
        if (!due) return

        lookupRunning = true
        lastLookupAt = now
        lastLookupLoc = Location(loc)
        val lat = loc.latitude
        val lon = loc.longitude
        Thread {
            val name = StreetName.lookup(ctx, lat, lon)
            main.post {
                lookupRunning = false
                if (!name.isNullOrBlank() && name != street) {
                    street = name
                    for (l in listeners.toList()) l.onStreet(name)
                }
            }
        }.start()
    }
}
