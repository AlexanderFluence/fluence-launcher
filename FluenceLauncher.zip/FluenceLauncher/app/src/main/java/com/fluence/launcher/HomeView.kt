package com.fluence.launcher

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.os.SystemClock
import android.util.AttributeSet
import android.view.GestureDetector
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Dibuja toda la pantalla de inicio: fondo, carretera con bordes de neón,
 * línea central animada, auto, velocidad, saludo, reloj y accesos.
 * Todo se dibuja en un solo View para que sea liviano en la radio.
 */
class HomeView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    interface Listener {
        fun onLaneClick(lane: Int)
        fun onLaneLongClick(lane: Int)
        fun onCarLongClick()
    }

    var listener: Listener? = null

    var greetingText = "Hola"
        set(value) { field = value; invalidate() }
    var timeText = ""
        set(value) { field = value; invalidate() }
    var dateText = ""
        set(value) { field = value; invalidate() }
    var laneLabels: Array<String> = Shortcuts.DEFAULT_LABELS.copyOf()
        set(value) { field = value; invalidate() }
    var carBitmap: Bitmap? = null
        set(value) { field = value; updateCarGeometry(); invalidate() }
    var showSpeed = true
        set(value) { field = value; invalidate() }
    var animateRoad = true
        set(value) { field = value; invalidate() }

    /** Velocidad en km/h; negativo = sin datos de GPS. */
    var speedKmh = -1f
        set(value) { field = value; invalidate() }

    // Límites de los carriles (fracción del ancho de la carretera en la base)
    private val laneBounds = floatArrayOf(0f, 0.40f, 0.567f, 0.725f, 1f)
    private val centerT = 0.567f

    private val dp = resources.displayMetrics.density

    private var w = 0f
    private var h = 0f
    private var vx = 0f
    private var vy = 0f
    private var leftB = 0f
    private var rightB = 0f
    private var carBottomY = 0f
    private var carW = 0f
    private var carH = 0f
    private var carCx = 0f
    private var lineEndF = 0f
    private var leftEndF = 0f
    private var rightEndF = 0f
    private var carTopF = 0f

    private val bgPaint = Paint()
    private val roadPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val pressPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(45, 34, 211, 238) }
    private val lanePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(150, 70, 100, 150)
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val dashPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(235, 229, 231, 235) }
    private val neonGlow1 = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(40, 34, 211, 238); style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND
    }
    private val neonGlow2 = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(90, 34, 211, 238); style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND
    }
    private val neonCore = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(103, 232, 249); style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND
    }
    private val shadowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(130, 0, 0, 0) }
    private val bmpPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val carPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val carLine = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; color = Color.rgb(103, 232, 249); strokeCap = Paint.Cap.ROUND
    }

    private val greetPaint = textPaint(Typeface.create("sans-serif-medium", Typeface.BOLD), Color.WHITE)
    private val timePaint = textPaint(Typeface.create("sans-serif", Typeface.BOLD), Color.WHITE)
    private val datePaint = textPaint(Typeface.create("sans-serif", Typeface.NORMAL), Color.rgb(220, 225, 235))
    private val labelPaint = textPaint(Typeface.create("sans-serif-medium", Typeface.NORMAL), Color.rgb(235, 240, 248)).apply {
        textAlign = Paint.Align.CENTER
        setShadowLayer(4f, 0f, 1f, Color.argb(160, 0, 0, 0))
    }
    private val speedPaint = textPaint(Typeface.create("sans-serif", Typeface.BOLD), Color.WHITE).apply {
        textAlign = Paint.Align.RIGHT
    }
    private val unitPaint = textPaint(Typeface.create("sans-serif", Typeface.NORMAL), Color.rgb(200, 210, 225))

    private val path = Path()
    private val rect = RectF()
    private val carRect = RectF()
    private val bmpRect = RectF()

    private var dashOffset = 0f
    private var lastFrame = 0L
    private var pressedLane = -1

    private fun textPaint(tf: Typeface, c: Int) = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        typeface = tf; color = c
    }

    private val gestures = GestureDetector(context, object : GestureDetector.SimpleOnGestureListener() {
        override fun onDown(e: MotionEvent): Boolean = true

        override fun onSingleTapUp(e: MotionEvent): Boolean {
            val lane = laneAt(e.x, e.y)
            if (lane >= 0) {
                playSoundEffect(android.view.SoundEffectConstants.CLICK)
                listener?.onLaneClick(lane)
            }
            return true
        }

        override fun onLongPress(e: MotionEvent) {
            if (carRect.contains(e.x, e.y)) {
                performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
                listener?.onCarLongClick()
                return
            }
            val lane = laneAt(e.x, e.y)
            if (lane >= 0) {
                performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
                listener?.onLaneLongClick(lane)
            }
        }
    })

    override fun onSizeChanged(nw: Int, nh: Int, ow: Int, oh: Int) {
        super.onSizeChanged(nw, nh, ow, oh)
        w = nw.toFloat()
        h = nh.toFloat()
        vx = 0.58f * w
        vy = 0.23f * h
        leftB = -0.12f * w
        rightB = 1.08f * w

        carBottomY = 0.62f * h
        val fc = fAt(carBottomY)
        val roadW = fc * (rightB - leftB)
        carW = 0.54f * roadW
        carCx = xAt(bx(centerT), fc)

        bgPaint.shader = LinearGradient(
            0f, 0f, 0f, h,
            Color.rgb(10, 18, 34), Color.rgb(18, 32, 60), Shader.TileMode.CLAMP
        )
        lanePaint.strokeWidth = 1.5f * dp
        neonGlow1.strokeWidth = 12f * dp
        neonGlow2.strokeWidth = 6f * dp
        neonCore.strokeWidth = 2.5f * dp
        carLine.strokeWidth = max(1.5f, carW * 0.006f)

        greetPaint.textSize = 0.048f * h
        timePaint.textSize = 0.13f * h
        datePaint.textSize = 0.038f * h
        labelPaint.textSize = 0.042f * h
        speedPaint.textSize = 0.08f * h
        unitPaint.textSize = 0.035f * h

        updateCarGeometry()
    }

    private fun updateCarGeometry() {
        if (w == 0f) return
        val bmp = carBitmap
        carH = if (bmp != null && bmp.width > 0) carW * bmp.height / bmp.width else carW * 0.60f
        // Si la imagen es muy alta, limitar su altura
        val maxH = (carBottomY - 0.06f * h)
        if (carH > maxH) carH = maxH
        carTopF = fAt(carBottomY - carH)
        val fc = fAt(carBottomY)
        // Cada borde de neón termina justo donde toca el costado del auto
        val carLeft = carCx - carW * 0.47f
        val carRight = carCx + carW * 0.47f
        leftEndF = ((vx - carLeft) / (vx - leftB)).coerceIn(carTopF, fc)
        rightEndF = ((carRight - vx) / (rightB - vx)).coerceIn(carTopF, fc)
        lineEndF = min(leftEndF, rightEndF)

        // La carretera se desvanece hacia el horizonte
        val topY = yAt(lineEndF)
        roadPaint.shader = LinearGradient(
            0f, topY, 0f, h,
            intArrayOf(Color.argb(0, 20, 36, 70), Color.rgb(20, 36, 70), Color.rgb(28, 50, 96)),
            floatArrayOf(0f, 0.25f, 1f),
            Shader.TileMode.CLAMP
        )
    }

    fun refreshCarGeometry() {
        updateCarGeometry()
        invalidate()
    }

    // f = 1 en la base de la pantalla, 0 en el punto de fuga
    private fun fAt(y: Float) = ((y - vy) / (h - vy)).coerceIn(0f, 1f)
    private fun bx(t: Float) = leftB + t * (rightB - leftB)
    private fun xAt(baseX: Float, f: Float) = vx + f * (baseX - vx)
    private fun yAt(f: Float) = vy + f * (h - vy)

    private fun laneAt(x: Float, y: Float): Int {
        if (y < 0.70f * h) return -1
        val f = fAt(y)
        val left = xAt(leftB, f)
        val right = xAt(rightB, f)
        val t = (x - left) / (right - left)
        for (i in 0 until 4) {
            if (t < laneBounds[i + 1]) return i
        }
        return 3
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                pressedLane = laneAt(event.x, event.y)
                if (pressedLane >= 0) invalidate()
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (pressedLane >= 0) {
                    pressedLane = -1
                    invalidate()
                }
            }
        }
        gestures.onTouchEvent(event)
        return true
    }

    private fun isMoving() = animateRoad && speedKmh > 2f

    override fun onDraw(canvas: Canvas) {
        if (w == 0f) return

        // Animación de la línea central (solo cuando el auto se mueve)
        val now = SystemClock.uptimeMillis()
        if (isMoving()) {
            val dt = if (lastFrame == 0L) 0f else min(0.1f, (now - lastFrame) / 1000f)
            dashOffset = (dashOffset + dt * (speedKmh / 3.6f) / 6f) % DASH_PERIOD
            lastFrame = now
        } else {
            lastFrame = 0L
        }

        canvas.drawRect(0f, 0f, w, h, bgPaint)

        // Superficie de la carretera
        val fEnd = lineEndF
        path.reset()
        path.moveTo(bx(0f), h)
        path.lineTo(bx(1f), h)
        path.lineTo(xAt(rightB, fEnd), yAt(fEnd))
        path.lineTo(xAt(leftB, fEnd), yAt(fEnd))
        path.close()
        canvas.drawPath(path, roadPaint)

        // Carril presionado
        if (pressedLane >= 0) {
            val fTop = fAt(0.70f * h)
            val a = bx(laneBounds[pressedLane])
            val b = bx(laneBounds[pressedLane + 1])
            path.reset()
            path.moveTo(a, h)
            path.lineTo(b, h)
            path.lineTo(xAt(b, fTop), yAt(fTop))
            path.lineTo(xAt(a, fTop), yAt(fTop))
            path.close()
            canvas.drawPath(path, pressPaint)
        }

        // Líneas tenues entre carriles
        val fLane = fAt(carBottomY)
        for (t in floatArrayOf(laneBounds[1], laneBounds[3])) {
            canvas.drawLine(bx(t), h, xAt(bx(t), fLane), yAt(fLane), lanePaint)
        }

        drawCenterDashes(canvas)

        // Bordes de neón
        for (side in 0..1) {
            val base = if (side == 0) leftB else rightB
            val fe = if (side == 0) leftEndF else rightEndF
            val x1 = xAt(base, fe)
            val y1 = yAt(fe)
            canvas.drawLine(base, h, x1, y1, neonGlow1)
            canvas.drawLine(base, h, x1, y1, neonGlow2)
            canvas.drawLine(base, h, x1, y1, neonCore)
        }

        drawCar(canvas)

        // Velocidad
        if (showSpeed) {
            val sy = 0.74f * h
            val sx = xAt(bx(centerT), fAt(sy))
            val txt = if (speedKmh < 0f) "--" else speedKmh.roundToInt().toString()
            canvas.drawText(txt, sx - 10f * dp, sy, speedPaint)
            canvas.drawText("km/h", sx + 10f * dp, sy, unitPaint)
        }

        // Etiquetas de los accesos
        val ly = 0.90f * h
        val fl = fAt(ly)
        for (i in 0 until 4) {
            val a = max(xAt(bx(laneBounds[i]), fl), 0.04f * w)
            val b = min(xAt(bx(laneBounds[i + 1]), fl), 0.96f * w)
            labelPaint.color = if (i == pressedLane) Color.rgb(103, 232, 249) else Color.rgb(235, 240, 248)
            canvas.drawText(fit(laneLabels[i], b - a), (a + b) / 2f, ly, labelPaint)
        }

        // Saludo, hora y fecha
        val x0 = 0.035f * w
        canvas.drawText(greetingText, x0, 0.10f * h, greetPaint)
        canvas.drawText(timeText, x0, 0.235f * h, timePaint)
        canvas.drawText(dateText, x0, 0.29f * h, datePaint)

        if (isMoving()) postInvalidateOnAnimation()
    }

    private fun fit(text: String, maxW: Float): String {
        if (labelPaint.measureText(text) <= maxW) return text
        var t = text
        while (t.length > 3 && labelPaint.measureText("$t…") > maxW) t = t.dropLast(1)
        return "$t…"
    }

    private fun drawCenterDashes(canvas: Canvas) {
        val base = bx(centerT)
        val fMin = max(lineEndF, carTopF)
        val maxS = 1f / max(fMin, 0.05f)
        var k = 0
        while (k < 60) {
            var s0 = k * DASH_PERIOD - dashOffset
            val s1 = s0 + DASH_LEN
            k++
            if (s0 > maxS) break
            if (s1 <= 0f) continue
            if (s0 < 0f) s0 = 0f
            val f0 = 1f / (1f + s0)
            var f1 = 1f / (1f + s1)
            if (f1 < fMin) f1 = fMin
            if (f0 <= f1) continue
            val x0 = xAt(base, f0)
            val y0 = yAt(f0)
            val x1 = xAt(base, f1)
            val y1 = yAt(f1)
            val w0 = 0.006f * w * f0
            val w1 = 0.006f * w * f1
            path.reset()
            path.moveTo(x0 - w0, y0)
            path.lineTo(x0 + w0, y0)
            path.lineTo(x1 + w1, y1)
            path.lineTo(x1 - w1, y1)
            path.close()
            canvas.drawPath(path, dashPaint)
        }
    }

    private fun drawCar(canvas: Canvas) {
        val left = carCx - carW / 2f
        val top = carBottomY - carH
        carRect.set(left, top, left + carW, carBottomY)

        // Sombra
        rect.set(left - carW * 0.04f, carBottomY - carW * 0.035f, left + carW * 1.04f, carBottomY + carW * 0.035f)
        canvas.drawOval(rect, shadowPaint)

        val bmp = carBitmap
        if (bmp != null) {
            bmpRect.set(left, top, left + carW, carBottomY)
            canvas.drawBitmap(bmp, null, bmpRect, bmpPaint)
        } else {
            drawDefaultCar(canvas, left, top, carW)
        }
    }

    /** Sedán gris estilizado (vista frontal) cuando no hay foto del auto. */
    private fun drawDefaultCar(canvas: Canvas, left: Float, top: Float, cw: Float) {
        fun poly(color: Int, vararg pts: Float) {
            path.reset()
            path.moveTo(left + pts[0] * cw, top + pts[1] * cw)
            var i = 2
            while (i < pts.size) {
                path.lineTo(left + pts[i] * cw, top + pts[i + 1] * cw)
                i += 2
            }
            path.close()
            carPaint.color = color
            canvas.drawPath(path, carPaint)
        }
        fun rrect(color: Int, l: Float, t: Float, r: Float, b: Float, rad: Float) {
            rect.set(left + l * cw, top + t * cw, left + r * cw, top + b * cw)
            carPaint.color = color
            canvas.drawRoundRect(rect, rad * cw, rad * cw, carPaint)
        }
        fun oval(color: Int, l: Float, t: Float, r: Float, b: Float) {
            rect.set(left + l * cw, top + t * cw, left + r * cw, top + b * cw)
            carPaint.color = color
            canvas.drawOval(rect, carPaint)
        }

        // Llantas
        rrect(Color.rgb(17, 19, 23), 0.09f, 0.46f, 0.25f, 0.60f, 0.025f)
        rrect(Color.rgb(17, 19, 23), 0.75f, 0.46f, 0.91f, 0.60f, 0.025f)
        // Techo y parabrisas
        poly(Color.rgb(128, 136, 145), 0.30f, 0.03f, 0.70f, 0.03f, 0.82f, 0.23f, 0.18f, 0.23f)
        poly(Color.rgb(34, 46, 62), 0.33f, 0.055f, 0.67f, 0.055f, 0.77f, 0.215f, 0.23f, 0.215f)
        poly(Color.argb(150, 90, 115, 145), 0.36f, 0.07f, 0.45f, 0.07f, 0.34f, 0.20f, 0.27f, 0.20f)
        // Espejos
        poly(Color.rgb(110, 118, 127), 0.12f, 0.19f, 0.19f, 0.20f, 0.19f, 0.25f, 0.11f, 0.25f)
        poly(Color.rgb(110, 118, 127), 0.88f, 0.19f, 0.81f, 0.20f, 0.81f, 0.25f, 0.89f, 0.25f)
        // Capó
        poly(Color.rgb(176, 183, 191), 0.17f, 0.22f, 0.83f, 0.22f, 0.95f, 0.31f, 0.05f, 0.31f)
        // Frente / parachoques
        poly(
            Color.rgb(140, 148, 157),
            0.04f, 0.30f, 0.96f, 0.30f, 0.985f, 0.48f, 0.93f, 0.555f, 0.07f, 0.555f, 0.015f, 0.48f
        )
        // Faros
        poly(Color.rgb(220, 231, 242), 0.06f, 0.325f, 0.31f, 0.355f, 0.33f, 0.405f, 0.10f, 0.40f, 0.05f, 0.36f)
        poly(Color.rgb(220, 231, 242), 0.94f, 0.325f, 0.69f, 0.355f, 0.67f, 0.405f, 0.90f, 0.40f, 0.95f, 0.36f)
        canvas.drawLine(left + 0.08f * cw, top + 0.37f * cw, left + 0.29f * cw, top + 0.385f * cw, carLine)
        canvas.drawLine(left + 0.92f * cw, top + 0.37f * cw, left + 0.71f * cw, top + 0.385f * cw, carLine)
        // Parrilla y logo
        rrect(Color.rgb(40, 45, 52), 0.35f, 0.355f, 0.65f, 0.395f, 0.012f)
        poly(Color.rgb(229, 231, 235), 0.5f, 0.345f, 0.522f, 0.375f, 0.5f, 0.405f, 0.478f, 0.375f)
        // Toma de aire inferior y neblineros
        poly(Color.rgb(30, 34, 40), 0.28f, 0.44f, 0.72f, 0.44f, 0.68f, 0.53f, 0.32f, 0.53f)
        oval(Color.rgb(200, 210, 220), 0.12f, 0.45f, 0.18f, 0.49f)
        oval(Color.rgb(200, 210, 220), 0.82f, 0.45f, 0.88f, 0.49f)
        // Placa
        rrect(Color.rgb(20, 20, 20), 0.405f, 0.46f, 0.595f, 0.52f, 0.006f)
        rrect(Color.rgb(240, 240, 240), 0.41f, 0.465f, 0.59f, 0.515f, 0.005f)
    }

    companion object {
        private const val DASH_PERIOD = 0.5f
        private const val DASH_LEN = 0.25f
    }
}
