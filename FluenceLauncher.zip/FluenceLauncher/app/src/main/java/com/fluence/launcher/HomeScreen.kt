package com.fluence.launcher

import android.graphics.Bitmap
import android.location.Location
import android.view.View

/** Lo que MainActivity le pide a cualquier estilo de pantalla de inicio. */
interface HomeScreen {
    val root: View
    fun setGreeting(text: String) {}
    fun setClock(time: String, date: String)
    fun setSpeed(kmh: Float)
    fun setCar(bmp: Bitmap?)
    fun onLocation(loc: Location) {}
    fun onStreet(name: String) {}
    /** Relee ajustes (nombres de accesos, mapa, etc.) al volver al inicio. */
    fun refresh() {}
    fun onResume() {}
    fun onPause() {}
    fun onDestroy() {}
}
