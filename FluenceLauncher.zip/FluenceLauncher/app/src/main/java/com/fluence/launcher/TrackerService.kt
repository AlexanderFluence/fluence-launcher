package com.fluence.launcher

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.location.Location
import android.os.Build
import android.os.IBinder

/**
 * Servicio que mantiene el GPS encendido y suma kilómetros aunque estés en CarPlay, Waze u otra app.
 */
class TrackerService : Service(), LocationHub.Listener {

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        startForeground(NOTIF_ID, buildNotification())
        LocationHub.add(this, this)
        // "Oye copiloto" también con otras apps abiertas (si se activó en Ajustes)
        if (WakeWord.background(this)) WakeWord.start(this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // Por si el permiso se concedió después de crear el servicio
        LocationHub.retry(this)
        return START_STICKY
    }

    override fun onDestroy() {
        LocationHub.remove(this, this)
        Odometer.save(this)
        super.onDestroy()
    }

    override fun onLocation(loc: Location) {
        Odometer.onLocation(this, loc)
    }

    private fun buildNotification(): Notification {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val builder = if (Build.VERSION.SDK_INT >= 26) {
            val ch = NotificationChannel(CHANNEL, "Odómetro", NotificationManager.IMPORTANCE_MIN)
            ch.setShowBadge(false)
            nm.createNotificationChannel(ch)
            Notification.Builder(this, CHANNEL)
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
        }
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return builder
            .setSmallIcon(R.drawable.ic_car)
            .setContentTitle("Fluence Launcher")
            .setContentText("Contando kilómetros")
            .setContentIntent(open)
            .setOngoing(true)
            .build()
    }

    companion object {
        private const val CHANNEL = "odometro"
        private const val NOTIF_ID = 7

        fun start(ctx: Context) {
            if (!LocationHub.hasPermission(ctx)) return
            val i = Intent(ctx, TrackerService::class.java)
            try {
                if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(i) else ctx.startService(i)
            } catch (e: Exception) { }
        }
    }
}
