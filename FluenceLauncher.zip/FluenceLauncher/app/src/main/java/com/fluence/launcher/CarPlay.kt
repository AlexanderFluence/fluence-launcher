package com.fluence.launcher

import android.content.Context
import android.content.Intent

/**
 * Acceso rápido a CarPlay / Android Auto a través de ZLink.
 * Trae ZLink al frente sin reiniciarlo, así la conexión inalámbrica no se corta.
 */
object CarPlay {
    const val PICK_ID = 99

    private val KNOWN = arrayOf(
        "com.zjinnova.zlink", "com.zjinnova.zlink.carplay", "com.zjinnova.zlinkpro"
    )
    private val NAME_HINTS = arrayOf("zlink", "carplay", "autokit", "carlink", "tlink")

    fun setPackage(ctx: Context, pkg: String?) {
        val e = Prefs.get(ctx).edit()
        if (pkg == null) e.remove(Prefs.CARPLAY_PKG) else e.putString(Prefs.CARPLAY_PKG, pkg)
        e.apply()
    }

    private fun isInstalled(ctx: Context, pkg: String): Boolean =
        ctx.packageManager.getLaunchIntentForPackage(pkg) != null

    /** Busca la app de CarPlay: la elegida por el usuario, ZLink, o una app con nombre parecido. */
    fun findPackage(ctx: Context): String? {
        val saved = Prefs.get(ctx).getString(Prefs.CARPLAY_PKG, null)
        if (saved != null && isInstalled(ctx, saved)) return saved
        for (pkg in KNOWN) if (isInstalled(ctx, pkg)) return pkg

        val pm = ctx.packageManager
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = try { pm.queryIntentActivities(launcher, 0) } catch (e: Exception) { emptyList() }
        for (ri in apps) {
            val pkg = ri.activityInfo.packageName
            val label = ri.loadLabel(pm).toString().lowercase()
            if (NAME_HINTS.any { label.contains(it) || pkg.lowercase().contains(it) }) return pkg
        }
        return null
    }

    /** Devuelve false si no hay app de CarPlay (entonces se abre el selector). */
    fun open(ctx: Context): Boolean {
        val pkg = findPackage(ctx)
        if (pkg != null && Shortcuts.launchPackage(ctx, pkg)) return true
        ctx.startActivity(
            Intent(ctx, AppsActivity::class.java)
                .putExtra(AppsActivity.EXTRA_PICK_LANE, PICK_ID)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
        return false
    }
}
