package com.fluence.launcher

import android.content.Context
import android.location.Location
import android.location.LocationManager
import android.os.SystemClock

/**
 * Odómetro por GPS. El usuario ingresa una vez los km de su tablero y aquí se suma lo recorrido.
 * El "viaje" se reinicia solo cuando el auto estuvo detenido más de 3 horas.
 */
object Odometer {

    interface Listener { fun onOdometer(totalKm: Double, tripKm: Double) }

    private const val KEY_TOTAL = "odo_m"
    private const val KEY_TRIP = "trip_m"
    private const val KEY_SET = "odo_set"
    private const val KEY_LAST_MOVE = "odo_last_move"
    private const val KEY_TRIP_TIME = "trip_time_ms"
    private const val TRIP_GAP_MS = 3L * 60 * 60 * 1000

    private var loaded = false
    private var totalM = 0.0
    private var tripM = 0.0
    private var lastMoveAt = 0L
    private var tripMoveMs = 0L
    private var unsaved = 0.0

    private var anchor: Location? = null
    private var anchorAt = 0L

    private val listeners = LinkedHashSet<Listener>()

    private fun load(ctx: Context) {
        if (loaded) return
        loaded = true
        val p = Prefs.get(ctx)
        totalM = p.getLong(KEY_TOTAL, 0L).toDouble()
        tripM = p.getLong(KEY_TRIP, 0L).toDouble()
        lastMoveAt = p.getLong(KEY_LAST_MOVE, 0L)
        tripMoveMs = p.getLong(KEY_TRIP_TIME, 0L)
    }

    fun isSet(ctx: Context): Boolean = Prefs.get(ctx).getBoolean(KEY_SET, false)
    fun totalKm(ctx: Context): Double { load(ctx); return totalM / 1000.0 }
    fun tripKm(ctx: Context): Double { load(ctx); return tripM / 1000.0 }

    /** Tiempo en movimiento durante el viaje actual. */
    fun tripMovingMs(ctx: Context): Long { load(ctx); return tripMoveMs }

    /** Velocidad promedio del viaje (solo el tiempo en movimiento), en km/h. */
    fun tripAvgKmh(ctx: Context): Double {
        load(ctx)
        if (tripMoveMs < 60_000L) return 0.0
        return (tripM / 1000.0) / (tripMoveMs / 3_600_000.0)
    }

    fun addListener(ctx: Context, l: Listener) {
        load(ctx)
        listeners.add(l)
        l.onOdometer(totalM / 1000.0, tripM / 1000.0)
    }

    fun removeListener(l: Listener) { listeners.remove(l) }

    fun setTotalKm(ctx: Context, km: Double) {
        load(ctx)
        totalM = km * 1000.0
        Prefs.get(ctx).edit().putBoolean(KEY_SET, true).apply()
        save(ctx)
        notifyListeners()
    }

    fun resetTrip(ctx: Context) {
        load(ctx)
        tripM = 0.0
        tripMoveMs = 0L
        save(ctx)
        notifyListeners()
    }

    /** Recibe cada punto del GPS (desde el servicio en segundo plano). */
    fun onLocation(ctx: Context, loc: Location) {
        load(ctx)
        if (loc.provider != LocationManager.GPS_PROVIDER) return
        if (loc.hasAccuracy() && loc.accuracy > 30f) return

        val now = SystemClock.elapsedRealtime()
        val prev = anchor
        // Detenido (o deriva del GPS): no sumar, pero mover el ancla
        val moving = loc.hasSpeed() && loc.speed > 1.4f
        if (prev == null || !moving) {
            anchor = Location(loc)
            anchorAt = now
            return
        }
        val d = loc.distanceTo(prev).toDouble()
        val dt = (now - anchorAt) / 1000.0
        anchor = Location(loc)
        anchorAt = now
        // Saltos imposibles (más de ~250 km/h) se descartan
        if (dt <= 0.0 || d / dt > 70.0) return
        if (d < 1.0) return
        add(ctx, d, (dt * 1000).toLong().coerceAtMost(5_000L))
    }

    private fun add(ctx: Context, meters: Double, movedMs: Long) {
        val wall = System.currentTimeMillis()
        if (lastMoveAt > 0 && wall - lastMoveAt > TRIP_GAP_MS) {
            tripM = 0.0
            tripMoveMs = 0L
        }
        tripMoveMs += movedMs
        lastMoveAt = wall
        totalM += meters
        tripM += meters
        unsaved += meters
        if (unsaved >= 50.0) save(ctx)
        notifyListeners()
    }

    fun save(ctx: Context) {
        load(ctx)
        unsaved = 0.0
        Prefs.get(ctx).edit()
            .putLong(KEY_TOTAL, totalM.toLong())
            .putLong(KEY_TRIP, tripM.toLong())
            .putLong(KEY_LAST_MOVE, lastMoveAt)
            .putLong(KEY_TRIP_TIME, tripMoveMs)
            .apply()
    }

    private fun notifyListeners() {
        val t = totalM / 1000.0
        val tr = tripM / 1000.0
        for (l in listeners.toList()) l.onOdometer(t, tr)
    }
}
