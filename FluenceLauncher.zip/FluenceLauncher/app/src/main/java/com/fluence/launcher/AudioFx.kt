package com.fluence.launcher

import android.content.Context
import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import android.media.audiofx.LoudnessEnhancer

/**
 * Ecualizador global (sesión de audio 0 = toda la salida de la radio).
 * Vive mientras el launcher esté abierto, que en una radio es siempre.
 * Si la radio no lo permite, los objetos quedan en null y la pantalla de ajustes lo indica.
 */
object AudioFx {
    var eq: Equalizer? = null
        private set
    var bass: BassBoost? = null
        private set
    var loud: LoudnessEnhancer? = null
        private set

    private var initialized = false

    /** Ajustes rápidos: niveles relativos (-1..1) para graves → agudos. */
    val PRESETS: Map<String, FloatArray> = linkedMapOf(
        "Plano" to floatArrayOf(0f, 0f, 0f, 0f, 0f),
        "Graves" to floatArrayOf(0.7f, 0.45f, 0f, 0f, 0.1f),
        "Voces" to floatArrayOf(-0.2f, 0f, 0.4f, 0.35f, 0.1f),
        "Rock" to floatArrayOf(0.5f, 0.2f, -0.2f, 0.25f, 0.5f),
        "Pop" to floatArrayOf(-0.1f, 0.3f, 0.45f, 0.3f, -0.1f),
        "Electrónica" to floatArrayOf(0.6f, 0.35f, 0f, 0.3f, 0.55f)
    )

    fun init(ctx: Context) {
        if (initialized) return
        initialized = true
        eq = try { Equalizer(0, 0) } catch (e: Throwable) { null }
        bass = try { BassBoost(0, 0) } catch (e: Throwable) { null }
        loud = try { LoudnessEnhancer(0) } catch (e: Throwable) { null }
        applyFromPrefs(ctx)
    }

    fun applyFromPrefs(ctx: Context) {
        val p = Prefs.get(ctx)
        val on = p.getBoolean(Prefs.EQ_ENABLED, false)
        eq?.let { e ->
            try {
                val bands = e.numberOfBands.toInt()
                for (b in 0 until bands) {
                    val lvl = p.getInt(Prefs.EQ_BAND + b, 0)
                    e.setBandLevel(b.toShort(), lvl.toShort())
                }
                e.setEnabled(on)
            } catch (t: Throwable) { }
        }
        bass?.let { b ->
            try {
                val s = p.getInt(Prefs.BASS, 0)
                if (b.strengthSupported) b.setStrength(s.toShort())
                b.setEnabled(on && s > 0)
            } catch (t: Throwable) { }
        }
        loud?.let { l ->
            try {
                val g = p.getInt(Prefs.LOUD, 0)
                l.setTargetGain(g)
                l.setEnabled(on && g > 0)
            } catch (t: Throwable) { }
        }
    }

    fun bandCount(): Int = try { eq?.numberOfBands?.toInt() ?: 0 } catch (t: Throwable) { 0 }

    /** Rango en milibeles, por ejemplo -1500..1500. */
    fun bandRange(): IntArray {
        return try {
            val r = eq?.bandLevelRange
            if (r != null && r.size >= 2) intArrayOf(r[0].toInt(), r[1].toInt()) else intArrayOf(-1500, 1500)
        } catch (t: Throwable) {
            intArrayOf(-1500, 1500)
        }
    }

    fun bandLabel(band: Int): String {
        return try {
            val hz = (eq?.getCenterFreq(band.toShort()) ?: 0) / 1000
            if (hz >= 1000) "${hz / 1000} kHz" else "$hz Hz"
        } catch (t: Throwable) {
            "Banda ${band + 1}"
        }
    }

    /** Aplica un ajuste rápido a las bandas disponibles y lo guarda. */
    fun applyPreset(ctx: Context, name: String) {
        val preset = PRESETS[name] ?: return
        val n = bandCount()
        if (n == 0) return
        val range = bandRange()
        val maxLvl = minOf(-range[0], range[1]).toFloat() * 0.8f
        val e = Prefs.get(ctx).edit()
        for (b in 0 until n) {
            // Interpolar el ajuste de 5 puntos a la cantidad real de bandas
            val pos = if (n == 1) 0f else b * (preset.size - 1).toFloat() / (n - 1)
            val i = pos.toInt().coerceAtMost(preset.size - 2)
            val frac = pos - i
            val v = preset[i] * (1 - frac) + preset[i + 1] * frac
            e.putInt(Prefs.EQ_BAND + b, (v * maxLvl).toInt())
        }
        e.apply()
        applyFromPrefs(ctx)
    }
}
