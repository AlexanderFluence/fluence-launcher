package com.fluence.launcher

import android.content.Context
import android.graphics.Color
import org.json.JSONArray
import org.json.JSONObject
import java.text.NumberFormat
import java.util.Locale
import kotlin.math.abs
import kotlin.math.roundToLong

/** Mantenimientos por kilómetros y documentos por fecha (SOAT, revisión técnica). */
object Maintenance {

    const val BY_KM = "km"
    const val BY_DAYS = "days"
    private const val KEY = "maintenance_items"
    private const val DAY_MS = 24L * 60 * 60 * 1000

    class Item(
        val id: String,
        var name: String,
        var type: String,
        /** km o días según el tipo */
        var interval: Int,
        /** km del odómetro en el último servicio (tipo km) */
        var lastKm: Double,
        /** fecha del último servicio / renovación en milisegundos (tipo días) */
        var lastDate: Long
    )

    enum class Level { OK, SOON, DUE }

    class Status(val item: Item, val remaining: Double, val fraction: Float, val level: Level, val text: String)

    private val es = Locale("es")

    fun fmtKm(km: Double): String {
        val nf = NumberFormat.getIntegerInstance(es)
        return nf.format(km.roundToLong())
    }

    fun load(ctx: Context): MutableList<Item> {
        val raw = Prefs.get(ctx).getString(KEY, null)
        if (raw == null) return defaults(ctx).also { save(ctx, it) }
        return try {
            val arr = JSONArray(raw)
            val out = ArrayList<Item>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(
                    Item(
                        o.getString("id"), o.getString("name"), o.getString("type"),
                        o.getInt("interval"), o.optDouble("lastKm", 0.0), o.optLong("lastDate", 0L)
                    )
                )
            }
            out
        } catch (e: Exception) {
            defaults(ctx)
        }
    }

    fun save(ctx: Context, items: List<Item>) {
        val arr = JSONArray()
        for (it in items) {
            val o = JSONObject()
            o.put("id", it.id)
            o.put("name", it.name)
            o.put("type", it.type)
            o.put("interval", it.interval)
            o.put("lastKm", it.lastKm)
            o.put("lastDate", it.lastDate)
            arr.put(o)
        }
        Prefs.get(ctx).edit().putString(KEY, arr.toString()).apply()
    }

    private fun defaults(ctx: Context): MutableList<Item> {
        val km = Odometer.totalKm(ctx)
        val now = System.currentTimeMillis()
        return mutableListOf(
            Item("aceite", "Cambio de aceite y filtro", BY_KM, 5000, km, 0L),
            Item("aire", "Filtro de aire", BY_KM, 10000, km, 0L),
            Item("frenos", "Pastillas de freno", BY_KM, 20000, km, 0L),
            Item("rotacion", "Rotación de llantas", BY_KM, 10000, km, 0L),
            Item("soat", "SOAT", BY_DAYS, 365, 0.0, now),
            Item("revision", "Revisión técnica", BY_DAYS, 365, 0.0, now)
        )
    }

    /** Si el usuario corrige el odómetro por primera vez, los servicios "nuevos" quedan en ese km. */
    fun rebaseUntouched(ctx: Context, oldKm: Double, newKm: Double) {
        val items = load(ctx)
        var changed = false
        for (it in items) {
            if (it.type == BY_KM && abs(it.lastKm - oldKm) < 0.5) {
                it.lastKm = newKm
                changed = true
            }
        }
        if (changed) save(ctx, items)
    }

    fun status(ctx: Context, item: Item, odometerKm: Double = Odometer.totalKm(ctx)): Status {
        return if (item.type == BY_KM) {
            val used = odometerKm - item.lastKm
            val remaining = item.interval - used
            val frac = (used / item.interval).toFloat().coerceIn(0f, 1f)
            val soonAt = maxOf(500.0, item.interval * 0.1)
            val level = when {
                remaining <= 0 -> Level.DUE
                remaining <= soonAt -> Level.SOON
                else -> Level.OK
            }
            val text = if (remaining <= 0) "vencido hace ${fmtKm(-remaining)} km" else "faltan ${fmtKm(remaining)} km"
            Status(item, remaining, frac, level, text)
        } else {
            val due = item.lastDate + item.interval * DAY_MS
            val days = Math.floorDiv(due - System.currentTimeMillis(), DAY_MS).toDouble()
            val frac = (1f - (days / item.interval).toFloat()).coerceIn(0f, 1f)
            val level = when {
                days < 0 -> Level.DUE
                days <= 30 -> Level.SOON
                else -> Level.OK
            }
            val n = abs(days).toLong()
            val text = when {
                days < 0 -> "venció hace $n ${if (n == 1L) "día" else "días"}"
                days == 0.0 -> "vence hoy"
                else -> "faltan $n ${if (n == 1L) "día" else "días"}"
            }
            Status(item, days, frac, level, text)
        }
    }

    /** Los más urgentes primero. */
    fun urgent(ctx: Context, limit: Int): List<Status> {
        val km = Odometer.totalKm(ctx)
        return load(ctx).map { status(ctx, it, km) }
            .sortedWith(compareBy<Status> { -it.level.ordinal }.thenByDescending { it.fraction })
            .take(limit)
    }

    fun color(level: Level): Int = when (level) {
        Level.DUE -> Color.rgb(248, 113, 113)
        Level.SOON -> Color.rgb(251, 191, 36)
        Level.OK -> Color.rgb(52, 211, 153)
    }
}
