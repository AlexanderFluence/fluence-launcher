package com.fluence.launcher;

import android.location.Location;
import android.location.LocationListener;
import android.os.Bundle;

/**
 * En Android 10 LocationListener exige implementar los cuatro métodos;
 * esta clase los deja vacíos y solo reenvía la velocidad.
 */
public class GpsListener implements LocationListener {
    public interface SpeedCallback {
        void onSpeed(float kmh);
    }

    private final SpeedCallback callback;

    public GpsListener(SpeedCallback callback) {
        this.callback = callback;
    }

    @Override
    public void onLocationChanged(Location location) {
        if (location == null) return;
        float kmh = location.hasSpeed() ? location.getSpeed() * 3.6f : 0f;
        callback.onSpeed(kmh);
    }

    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) { }

    @Override
    public void onProviderEnabled(String provider) { }

    @Override
    public void onProviderDisabled(String provider) {
        callback.onSpeed(-1f);
    }
}
