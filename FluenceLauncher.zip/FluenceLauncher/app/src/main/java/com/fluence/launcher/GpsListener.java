package com.fluence.launcher;

import android.location.Location;
import android.location.LocationListener;
import android.os.Bundle;

/**
 * En Android 10 LocationListener exige implementar los cuatro métodos;
 * esta clase los deja vacíos y solo reenvía la ubicación.
 */
public class GpsListener implements LocationListener {
    public interface Callback {
        void onLocation(Location location);
        void onLost();
    }

    private final Callback callback;

    public GpsListener(Callback callback) {
        this.callback = callback;
    }

    @Override
    public void onLocationChanged(Location location) {
        if (location != null) callback.onLocation(location);
    }

    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) { }

    @Override
    public void onProviderEnabled(String provider) { }

    @Override
    public void onProviderDisabled(String provider) {
        callback.onLost();
    }
}
