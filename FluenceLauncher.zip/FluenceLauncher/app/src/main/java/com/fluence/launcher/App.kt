package com.fluence.launcher

import android.app.Application
import org.osmdroid.config.Configuration
import java.io.File

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        SpotifyBroadcast.register(this)
        // En el celular no se toca el audio del sistema ni se reanuda música sola al prender la pantalla
        if (!BuildConfig.PHONE) {
            AudioFx.init(this)
            AutoResume.init(this)
        }
        setupMap()
    }

    /** Configura el mapa: identificación ante OpenStreetMap y caché de calles dentro de la app. */
    private fun setupMap() {
        try {
            val cfg = Configuration.getInstance()
            cfg.load(this, getSharedPreferences("osmdroid", MODE_PRIVATE))
            cfg.setUserAgentValue(packageName)
            val base = File(filesDir, "osmdroid")
            cfg.setOsmdroidBasePath(base)
            cfg.setOsmdroidTileCache(File(base, "tiles"))
            cfg.setTileFileSystemCacheMaxBytes(300L * 1024 * 1024)
            cfg.setTileFileSystemCacheTrimBytes(250L * 1024 * 1024)
        } catch (e: Throwable) { }
    }
}
