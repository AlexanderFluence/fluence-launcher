package com.fluence.launcher

import android.app.Application

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        AudioFx.init(this)
    }
}
