package com.fluence.launcher

import android.service.notification.NotificationListenerService

/**
 * Servicio vacío: solo sirve para que Android permita leer qué canción suena
 * (título, artista y carátula de Spotify u otra app de música).
 */
class MediaListener : NotificationListenerService()
