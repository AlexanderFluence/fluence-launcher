package com.fluence.launcher

import android.app.Activity
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognizerIntent
import android.util.TypedValue
import android.view.Gravity
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

/**
 * Ventana de "Te escucho…". Usa el reconocimiento de Google si existe (más preciso, con internet);
 * si no, avisa cómo instalarlo. El texto se manda al inicio para ejecutarlo.
 */
class VoiceActivity : Activity() {

    private val dp by lazy { resources.displayMetrics.density }
    private val main = Handler(Looper.getMainLooper())
    private lateinit var status: TextView
    private lateinit var heard: TextView
    private var done = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        if (!startGoogle()) startOffline()
    }

    private fun buildUi() {
        val root = FrameLayout(this).apply {
            setBackgroundColor(Color.argb(150, 0, 0, 0))
            setOnClickListener { finishVoice(null) }
        }
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            val p = (28 * dp).toInt()
            setPadding(p, p, p, p)
            background = GradientDrawable().apply {
                setCornerRadius(24 * dp)
                setColor(Color.rgb(17, 17, 19))
                setStroke((1 * dp).toInt().coerceAtLeast(1), Color.rgb(46, 46, 50))
            }
            setOnClickListener { }
        }
        val mic = ImageView(this).apply {
            setImageResource(R.drawable.ic_mic)
            imageTintList = ColorStateList.valueOf(Color.rgb(20, 18, 14))
            val p = (18 * dp).toInt()
            setPadding(p, p, p, p)
            background = GradientDrawable().apply {
                setShape(GradientDrawable.OVAL)
                setColor(Color.rgb(230, 211, 166))
            }
        }
        card.addView(mic, LinearLayout.LayoutParams((76 * dp).toInt(), (76 * dp).toInt()))
        status = TextView(this).apply {
            text = "Te escucho…"
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 22f)
            typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
            gravity = Gravity.CENTER
            setPadding(0, (16 * dp).toInt(), 0, (6 * dp).toInt())
        }
        heard = TextView(this).apply {
            text = "Ej: \"llévame a Larcomar\", \"pon Def Leppard\", \"abre YouTube\""
            setTextColor(Color.rgb(140, 140, 146))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            gravity = Gravity.CENTER
        }
        card.addView(status)
        card.addView(heard)
        root.addView(card, FrameLayout.LayoutParams((420 * dp).toInt(), -2, Gravity.CENTER))
        setContentView(root)
    }

    private fun startGoogle(): Boolean {
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "es-PE")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "¿A dónde vamos? ¿Qué abro o pongo?")
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        }
        if (packageManager.queryIntentActivities(i, 0).isEmpty()) return false
        return try {
            startActivityForResult(i, REQ)
            true
        } catch (e: Exception) {
            false
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQ) return
        val text = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        finishVoice(if (resultCode == RESULT_OK) text else null)
    }

    /** Sin la app de Google no hay reconocimiento de voz. */
    private fun startOffline() {
        status.text = "No hay reconocimiento de voz"
        heard.text = "Instala la app \"Google\" desde la Play Store o escribe el destino en el inicio."
        main.postDelayed({ finishVoice(null) }, 3500L)
    }

    private fun finishVoice(text: String?) {
        if (done) return
        done = true
        if (!text.isNullOrBlank()) {
            // El inicio ejecuta el comando (puede mostrar diálogos, abrir apps, etc.)
            startActivity(
                Intent(this, MainActivity::class.java)
                    .putExtra(MainActivity.EXTRA_VOICE_TEXT, text)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            )
        }
        finish()
        overridePendingTransition(0, 0)
    }

    override fun onDestroy() {
        super.onDestroy()
        main.removeCallbacksAndMessages(null)
        WakeWord.resumeAfterCommand(this)
    }

    companion object {
        private const val REQ = 4301
    }
}
