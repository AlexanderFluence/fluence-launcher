package com.fluence.launcher

import android.content.Context
import java.util.Calendar

/** Modo día / noche del estilo Claro: "auto" (según la hora), "day" o "night". */
object DayNight {
    const val AUTO = "auto"
    const val DAY = "day"
    const val NIGHT = "night"

    fun mode(ctx: Context): String = Prefs.get(ctx).getString(Prefs.DAY_NIGHT, AUTO) ?: AUTO

    fun setMode(ctx: Context, m: String) = Prefs.get(ctx).edit().putString(Prefs.DAY_NIGHT, m).apply()

    /** De noche entre las 6 p. m. y las 6 a. m. en modo automático. */
    fun isNight(ctx: Context): Boolean = when (mode(ctx)) {
        DAY -> false
        NIGHT -> true
        else -> Calendar.getInstance().get(Calendar.HOUR_OF_DAY).let { it >= 18 || it < 6 }
    }

    fun label(m: String) = when (m) {
        DAY -> "Día"
        NIGHT -> "Noche"
        else -> "Automático"
    }

    fun next(m: String) = when (m) {
        AUTO -> DAY
        DAY -> NIGHT
        else -> AUTO
    }
}
