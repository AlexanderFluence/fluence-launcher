package com.fluence.launcher

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.media.AudioManager
import android.os.Handler
import android.os.Looper
import android.view.KeyEvent

/**
 * Reanuda la música al encender el auto si estaba sonando cuando se apagó.
 * Se recuerda cada 15 s si había música; al encender (o al prender la pantalla) se manda "Play".
 */
object AutoResume {
    private const val KEY_PLAYING = "was_playing"
    private const val KEY_AT = "was_playing_at"
    private const val MAX_AGE_MS = 24L * 60 * 60 * 1000

    private val main = Handler(Looper.getMainLooper())
    private var registered = false
    private var watching = false
    private var app: Context? = null

    fun enabled(ctx: Context) = Prefs.get(ctx).getBoolean(Prefs.AUTO_RESUME, true)

    private fun audio(ctx: Context) = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager

    /** Llamar al iniciar la app: cuenta como "encendido". */
    fun init(ctx: Context) {
        app = ctx.applicationContext
        if (!registered) {
            registered = true
            val f = IntentFilter(Intent.ACTION_SCREEN_ON)
            try {
                ctx.applicationContext.registerReceiver(object : BroadcastReceiver() {
                    override fun onReceive(c: Context, i: Intent) = onPowerOn(c)
                }, f)
            } catch (e: Exception) { }
        }
        onPowerOn(ctx)
        startWatching()
    }

    /** Guarda periódicamente si hay música sonando. */
    private fun startWatching() {
        if (watching) return
        watching = true
        main.post(watcher)
    }

    private val watcher = object : Runnable {
        override fun run() {
            app?.let { c ->
                val playing = try { audio(c).isMusicActive } catch (e: Exception) { false }
                val p = Prefs.get(c)
                if (playing != p.getBoolean(KEY_PLAYING, false) || playing) {
                    p.edit().putBoolean(KEY_PLAYING, playing).putLong(KEY_AT, System.currentTimeMillis()).apply()
                }
            }
            main.postDelayed(this, 15_000L)
        }
    }

    fun onPowerOn(ctx: Context) {
        val c = ctx.applicationContext
        if (!enabled(c)) return
        val p = Prefs.get(c)
        val was = p.getBoolean(KEY_PLAYING, false)
        val age = System.currentTimeMillis() - p.getLong(KEY_AT, 0L)
        if (!was || age > MAX_AGE_MS) return
        // Esperar a que la radio termine de encender y el Bluetooth/audio estén listos
        main.postDelayed({ tryPlay(c, 1) }, 6_000L)
    }

    private fun tryPlay(c: Context, attempt: Int) {
        val am = audio(c)
        if (am.isMusicActive) return
        try {
            am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_MEDIA_PLAY))
            am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_MEDIA_PLAY))
        } catch (e: Exception) { }
        // Un segundo intento por si la app de música tardó en despertar
        if (attempt < 2) main.postDelayed({ tryPlay(c, attempt + 1) }, 6_000L)
    }
}
