package com.fluence.launcher

import android.content.Context
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.location.Location
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import java.util.Locale
import kotlin.math.roundToInt

/**
 * Estilo "Claro": fondo claro, columna de apps a la izquierda, velocidad grande y el auto
 * visto desde arriba; a la derecha el mapa en vivo con buscador, zoom y la barra de música.
 * Diseñado sobre 1024×600 y escalado a la pantalla real.
 */
class LightHome(private val activity: MainActivity) : HomeScreen, Odometer.Listener {

    private val ctx: Context = activity
    private val es = Locale("es")

    /** Colores según el modo día / noche (se elige al crear la pantalla). */
    val night = DayNight.isNight(activity)
    private val BG = if (night) Color.rgb(12, 13, 16) else Color.rgb(230, 233, 237)
    private val CARD = if (night) Color.argb(240, 26, 28, 33) else Color.argb(235, 248, 249, 251)
    private val SURFACE = if (night) Color.rgb(32, 35, 41) else Color.WHITE
    private val LINE = if (night) Color.rgb(50, 54, 62) else Color.rgb(214, 218, 224)
    private val TEXT = if (night) Color.rgb(236, 238, 242) else Color.rgb(28, 31, 36)
    private val MUTED = if (night) Color.rgb(142, 148, 158) else Color.rgb(120, 126, 136)
    private val BLUE = Color.rgb(37, 99, 235)
    private val GOLD = Color.rgb(230, 211, 166)

    override val root = FrameLayout(activity).apply { setBackgroundColor(BG) }

    private var s = 1f
    private var ox = 0f
    private var oy = 0f
    private val placed = ArrayList<Pair<View, String>>()
    private val appIcons = ArrayList<ImageView>()
    private lateinit var apps: LinearLayout
    private var portrait = false
    private val sized = ArrayList<Pair<TextView, Float>>()
    private val icons = ArrayList<Pair<ImageView, Float>>()
    private val radii = ArrayList<Pair<GradientDrawable, Float>>()
    private val pads = ArrayList<Pair<View, FloatArray>>()

    private val speed = text(TEXT, 72f, "sans-serif-light")
    private val unit = text(MUTED, 15f)
    private val clock = text(TEXT, 22f, "sans-serif-light")
    private val date = text(MUTED, 12f)
    private val street = text(MUTED, 13f).apply {
        maxLines = 1
        ellipsize = TextUtils.TruncateAt.END
    }
    private val car = TopCarView(activity)
    private val photo = CarView(activity).apply { visibility = View.GONE }
    private val odoValue = text(TEXT, 15f)
    private val tripValue = text(TEXT, 15f)
    private val oilValue = text(TEXT, 15f)
    private val netText = text(TEXT, 11.5f)
    private val netDot = View(activity)

    private val mapBox = FrameLayout(activity)
    private val map = LiveMap(activity, true, forceDark = night)
    private val main = android.os.Handler(android.os.Looper.getMainLooper())
    private val autoRecenter = Runnable { map.recenter() }
    private lateinit var compass: TextView
    private val media = MediaPanel(activity, wide = true)
    private var lastKm = -1L

    init {
        // Columna de apps
        apps = card(14f)
        apps.orientation = LinearLayout.VERTICAL
        apps.gravity = Gravity.CENTER_HORIZONTAL
        fun appIcon(icon: Int, color: Int, onLong: (() -> Unit)? = null, action: () -> Unit) {
            val iv = ImageView(ctx).apply {
                setImageResource(icon)
                imageTintList = ColorStateList.valueOf(Color.WHITE)
                background = GradientDrawable().apply { setColor(color); radii.add(Pair(this, 10f)) }
                setOnClickListener { action() }
                if (onLong != null) setOnLongClickListener { onLong(); true }
            }
            apps.addView(iv, LinearLayout.LayoutParams(0, 0))
            icons.add(Pair(iv, 40f))
            appIcons.add(iv)
            pads.add(Pair(iv, floatArrayOf(9f, 9f, 9f, 9f)))
        }
        appIcon(R.drawable.ic_play, Color.rgb(230, 33, 23)) { open("com.google.android.youtube", "YouTube") }
        appIcon(R.drawable.ic_music, Color.rgb(29, 185, 84)) { openMusic() }
        if (BuildConfig.PHONE) {
            appIcon(R.drawable.ic_chat, Color.rgb(37, 211, 102)) { open("com.whatsapp", "WhatsApp") }
        } else {
            appIcon(R.drawable.ic_car, Color.rgb(17, 17, 19), onLong = { activity.onCarPlayLongClick() }) { CarPlay.open(activity) }
        }
        appIcon(R.drawable.ic_navigation, Color.rgb(51, 204, 255), onLong = { Navigator.openWaze(ctx, adjacent = true) }) { Navigator.openWaze(ctx) }
        appIcon(R.drawable.ic_phone, Color.rgb(52, 199, 89), onLong = { activity.onLaneLongClick(1) }) { Shortcuts.launch(activity, 1) }
        appIcon(R.drawable.ic_apps, Color.rgb(99, 102, 241)) { Shortcuts.launch(activity, 0) }
        put(apps, "apps")

        // Tarjeta del auto
        put(card(18f), "card")
        put(speed, "speed")
        put(unit, "unit")
        clock.gravity = Gravity.END
        date.gravity = Gravity.END
        put(clock, "clock")
        put(date, "date")
        put(street, "street")
        car.setOnLongClickListener { activity.onCarLongClick(); true }
        photo.setOnLongClickListener { activity.onCarLongClick(); true }
        put(car, "car")
        put(photo, "photo")
        put(stat("ODÓMETRO", odoValue), "odo")
        put(stat("VIAJE", tripValue), "trip")
        put(stat("ACEITE", oilValue), "oil")
        val statsTouch = View(ctx).apply {
            setOnClickListener {
                if (Odometer.isSet(ctx)) activity.startActivity(Intent(ctx, MaintenanceActivity::class.java))
                else MaintenanceActivity.askOdometer(activity) { refresh() }
            }
            setOnLongClickListener { MaintenanceActivity.askOdometer(activity) { refresh() }; true }
        }
        put(statsTouch, "statsTouch")

        // Barra inferior
        val dock = card(18f)
        dock.orientation = LinearLayout.HORIZONTAL
        dock.gravity = Gravity.CENTER_VERTICAL
        fun dockIcon(icon: Int, action: () -> Unit) {
            val iv = ImageView(ctx).apply {
                setImageResource(icon)
                imageTintList = ColorStateList.valueOf(TEXT)
                setOnClickListener { action() }
            }
            val cell = FrameLayout(ctx)
            cell.addView(iv, FrameLayout.LayoutParams(0, 0, Gravity.CENTER))
            icons.add(Pair(iv, 24f))
            dock.addView(cell, LinearLayout.LayoutParams(0, -1, 1f))
        }
        dockIcon(R.drawable.ic_settings) { activity.startActivity(Intent(ctx, SettingsActivity::class.java)) }
        dockIcon(R.drawable.ic_mic) { Voice.start(activity) }
        dockIcon(R.drawable.ic_map) { activity.startActivity(Intent(ctx, MapActivity::class.java)) }
        dockIcon(R.drawable.ic_build) { activity.startActivity(Intent(ctx, MaintenanceActivity::class.java)) }
        dockIcon(R.drawable.ic_place) { Navigator.goSaved(activity, Prefs.DEST_HOME, "Casa") }
        dockIcon(if (night) R.drawable.ic_moon else R.drawable.ic_sun) {
            val m = DayNight.next(DayNight.mode(ctx))
            DayNight.setMode(ctx, m)
            android.widget.Toast.makeText(ctx, "Modo: ${DayNight.label(m)}", android.widget.Toast.LENGTH_SHORT).show()
            activity.checkDayNight()
        }
        put(dock, "dock")

        // Mapa
        mapBox.background = GradientDrawable().apply { setColor(Color.rgb(220, 224, 228)); radii.add(Pair(this, 18f)) }
        mapBox.clipToOutline = true
        mapBox.addView(map.view, FrameLayout.LayoutParams(-1, -1))
        put(mapBox, "map")

        // Buscador sobre el mapa
        val search = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = pill(SURFACE)
            elevation = 4f
            setOnClickListener { Voice.typed(activity) }
        }
        search.addView(text(MUTED, 14f).apply { text = "¿A dónde vamos?" }, LinearLayout.LayoutParams(0, -2, 1f))
        val mic = ImageView(ctx).apply {
            setImageResource(R.drawable.ic_mic)
            imageTintList = ColorStateList.valueOf(BLUE)
            setOnClickListener { Voice.start(activity) }
        }
        search.addView(mic)
        icons.add(Pair(mic, 22f))
        pads.add(Pair(search, floatArrayOf(16f, 0f, 12f, 0f)))
        put(search, "search")

        // Conexión
        val chip = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = pill(SURFACE)
            elevation = 4f
        }
        if (BuildConfig.PHONE) {
            // En el celular: botón grande para abrir Waze (mantener presionado = pantalla dividida)
            chip.background = GradientDrawable().apply { setColor(Color.rgb(51, 204, 255)); radii.add(Pair(this, 15f)) }
            chip.gravity = Gravity.CENTER
            val wz = text(Color.rgb(8, 40, 60), 13f, "sans-serif-medium").apply { text = "Abrir Waze" }
            chip.addView(wz)
            chip.setOnClickListener { Navigator.openWaze(ctx) }
            chip.setOnLongClickListener { Navigator.openWaze(ctx, adjacent = true); true }
        } else {
            chip.addView(netDot)
            chip.addView(netText)
        }
        pads.add(Pair(chip, floatArrayOf(10f, 0f, 12f, 0f)))
        put(chip, "chip")

        // Zoom y centrar
        put(round("+") { map.zoomIn() }, "z1")
        put(round("−") { map.zoomOut() }, "z2")
        put(round("◎") { map.recenter() }, "z3")
        // Brújula: dirección del auto arriba (por defecto) o norte arriba
        compass = round("") { toggleHeading() }
        put(compass, "z4")
        map.setHeadingUp(Prefs.get(ctx).getBoolean(Prefs.MAP_HEADING, true))
        updateCompass()
        // Si mueves el mapa con el dedo, a los 10 s vuelve a seguir al auto
        map.onFollowChanged = { following ->
            main.removeCallbacks(autoRecenter)
            if (!following) main.postDelayed(autoRecenter, 10_000L)
        }

        // Música
        root.addView(media.view, FrameLayout.LayoutParams(0, 0))

        root.addOnLayoutChangeListener { _, l, t, r, b, ol, ot, or_, ob ->
            if (r - l != or_ - ol || b - t != ob - ot) layout(r - l, b - t)
        }
    }

    // ================= Escalado =================

    /**
     * Rectángulo (x, y, ancho, alto) de cada elemento en unidades de diseño.
     * Horizontal: 600 de alto (la radio es 1024×600). Vertical: 480 de ancho (celular).
     * -1 = tamaño automático.
     */
    private fun rect(id: String, W: Float, H: Float): FloatArray {
        val A = -1f
        return if (!portrait) when (id) {
            "apps" -> floatArrayOf(14f, 14f, 62f, H - 28f)
            "card" -> floatArrayOf(86f, 14f, 370f, H - 84f)
            "speed" -> floatArrayOf(106f, 22f, A, A)
            "unit" -> floatArrayOf(112f, 104f, A, A)
            "clock" -> floatArrayOf(300f, 30f, 140f, A)
            "date" -> floatArrayOf(300f, 60f, 140f, A)
            "street" -> floatArrayOf(106f, 132f, 330f, A)
            "car" -> floatArrayOf(160f, 156f, 222f, H - 310f)
            "photo" -> floatArrayOf(100f, 170f, 342f, H - 330f)
            "odo" -> floatArrayOf(106f, H - 138f, 110f, A)
            "trip" -> floatArrayOf(222f, H - 138f, 100f, A)
            "oil" -> floatArrayOf(330f, H - 138f, 110f, A)
            "statsTouch" -> floatArrayOf(96f, H - 144f, 350f, 66f)
            "dock" -> floatArrayOf(86f, H - 60f, 370f, 50f)
            "map" -> floatArrayOf(466f, 14f, W - 480f, H - 28f)
            "search" -> floatArrayOf(480f, 28f, minOf(300f, W - 720f), 42f)
            "chip" -> floatArrayOf(W - 224f, 34f, 196f, 30f)
            "z1" -> floatArrayOf(480f, 220f, 42f, 42f)
            "z2" -> floatArrayOf(480f, 270f, 42f, 42f)
            "z3" -> floatArrayOf(480f, 320f, 42f, 42f)
            "z4" -> floatArrayOf(480f, 370f, 42f, 42f)
            else -> floatArrayOf(0f, 0f, A, A)
        } else when (id) {
            "card" -> floatArrayOf(14f, 14f, W - 28f, 286f)
            "speed" -> floatArrayOf(34f, 26f, A, A)
            "unit" -> floatArrayOf(40f, 108f, A, A)
            "clock" -> floatArrayOf(W - 174f, 30f, 140f, A)
            "date" -> floatArrayOf(W - 174f, 60f, 140f, A)
            "street" -> floatArrayOf(34f, 136f, W - 230f, A)
            "car" -> floatArrayOf(W - 170f, 84f, 130f, 150f)
            "photo" -> floatArrayOf(W - 250f, 96f, 220f, 130f)
            "odo" -> floatArrayOf(34f, 240f, 120f, A)
            "trip" -> floatArrayOf(164f, 240f, 100f, A)
            "oil" -> floatArrayOf(280f, 240f, 120f, A)
            "statsTouch" -> floatArrayOf(24f, 232f, W - 48f, 62f)
            "dock" -> floatArrayOf(14f, 310f, W - 28f, 50f)
            "map" -> floatArrayOf(14f, 370f, W - 28f, H - 460f)
            "search" -> floatArrayOf(28f, 384f, W - 196f, 42f)
            "chip" -> floatArrayOf(W - 156f, 390f, 128f, 30f)
            "z1" -> floatArrayOf(28f, 446f, 42f, 42f)
            "z2" -> floatArrayOf(28f, 496f, 42f, 42f)
            "z3" -> floatArrayOf(28f, 546f, 42f, 42f)
            "z4" -> floatArrayOf(28f, 596f, 42f, 42f)
            "apps" -> floatArrayOf(14f, H - 78f, W - 28f, 64f)
            else -> floatArrayOf(0f, 0f, A, A)
        }
    }

    private fun layout(w: Int, h: Int) {
        portrait = h > w
        s = if (portrait) minOf(w / 480f, h / 800f) else minOf(w / 1024f, h / 600f)
        val W = w / s
        val H = h / s
        ox = 0f
        oy = 0f
        apps.orientation = if (portrait) LinearLayout.HORIZONTAL else LinearLayout.VERTICAL
        apps.gravity = Gravity.CENTER
        for ((tv, sz) in sized) tv.setTextSize(TypedValue.COMPLEX_UNIT_PX, sz * s)
        for ((g, rr) in radii) g.setCornerRadius(rr * s)
        for ((v, p) in pads) v.setPadding(u(p[0]), u(p[1]), u(p[2]), u(p[3]))
        for ((iv, sz) in icons) {
            val lp = iv.layoutParams
            lp.width = u(sz); lp.height = u(sz)
            iv.layoutParams = lp
        }
        for (iv in appIcons) {
            val lp = iv.layoutParams as LinearLayout.LayoutParams
            if (portrait) { lp.setMargins(u(8f), 0, u(8f), 0) } else { lp.setMargins(0, u(6f), 0, u(6f)) }
            iv.layoutParams = lp
        }
        netDot.layoutParams = LinearLayout.LayoutParams(u(7f), u(7f)).apply { rightMargin = u(7f) }
        for ((v, id) in placed) {
            val r = rect(id, W, H)
            val lp = (v.layoutParams as? FrameLayout.LayoutParams) ?: FrameLayout.LayoutParams(-2, -2)
            lp.gravity = Gravity.TOP or Gravity.START
            lp.leftMargin = (ox + r[0] * s).toInt()
            lp.topMargin = (oy + r[1] * s).toInt()
            lp.width = if (r[2] < 0) -2 else u(r[2])
            lp.height = if (r[3] < 0) -2 else u(r[3])
            v.layoutParams = lp
        }
        val m = rect("map", W, H)
        media.placeAt(u(m[0] + 14f), u(m[1] + m[3] - 80f), u(m[2] - 28f), u(66f))
        media.usePanelStyle(GOLD, 16f * s, s)
        media.setArtSize(u(42f))
        media.view.elevation = 6f
    }

    private fun u(v: Float) = (v * s).roundToInt()

    // ================= HomeScreen =================

    override fun setClock(time: String, date: String) {
        clock.text = time
        this.date.text = date
    }

    override fun setSpeed(kmh: Float) {
        speed.text = if (kmh < 0f) "--" else kmh.roundToInt().toString()
        unit.text = if (kmh < 0f) "km/h · sin GPS" else "km/h"
    }

    /** Con foto propia se muestra la foto; si no, el auto visto desde arriba. */
    override fun setCar(bmp: Bitmap?) {
        photo.bitmap = bmp
        photo.visibility = if (bmp != null) View.VISIBLE else View.GONE
        car.visibility = if (bmp != null) View.GONE else View.VISIBLE
    }

    private fun toggleHeading() {
        val on = !map.headingUp
        Prefs.get(ctx).edit().putBoolean(Prefs.MAP_HEADING, on).apply()
        map.setHeadingUp(on)
        map.recenter()
        updateCompass()
        android.widget.Toast.makeText(ctx, if (on) "El mapa gira según tu dirección" else "Norte arriba", android.widget.Toast.LENGTH_SHORT).show()
    }

    private fun updateCompass() {
        compass.text = if (map.headingUp) "➤" else "N"
        compass.rotation = if (map.headingUp) -90f else 0f
    }

    override fun onLocation(loc: Location) = map.update(loc)

    override fun onStreet(name: String) { street.text = "📍 $name" }

    override fun refresh() {
        refreshNumbers()
        val st = NetStatus.read(ctx)
        netText.text = if (st.online) "En línea · ${st.label}" else st.label
        netDot.background = GradientDrawable().apply {
            setShape(GradientDrawable.OVAL)
            setColor(if (st.online) Color.rgb(34, 197, 94) else Color.rgb(239, 68, 68))
        }
        if (street.text.isNullOrEmpty()) street.text = "Buscando ubicación…"
    }

    override fun onResume() {
        Odometer.addListener(ctx, this)
        media.onResume()
        map.onResume()
    }

    override fun onPause() {
        Odometer.removeListener(this)
        media.onPause()
        map.onPause()
    }

    override fun onDestroy() {
        main.removeCallbacksAndMessages(null)
        media.onDestroy()
        map.onDestroy()
    }

    override fun onOdometer(totalKm: Double, tripKm: Double) {
        tripValue.text = "${String.format(es, "%.1f", tripKm)} km"
        if (totalKm.toLong() != lastKm) refreshNumbers()
    }

    private fun refreshNumbers() {
        val km = Odometer.totalKm(ctx)
        lastKm = km.toLong()
        val set = Odometer.isSet(ctx)
        odoValue.text = if (set) "${Maintenance.fmtKm(km)} km" else "Ingresar"
        tripValue.text = "${String.format(es, "%.1f", Odometer.tripKm(ctx))} km"
        val oil = Maintenance.load(ctx).firstOrNull { it.id == "aceite" }
        if (oil != null && set) {
            val st = Maintenance.status(ctx, oil, km)
            oilValue.text = if (st.remaining >= 0) "${Maintenance.fmtKm(st.remaining)} km" else "Vencido"
            oilValue.setTextColor(if (st.level == Maintenance.Level.OK) TEXT else Maintenance.color(st.level))
        } else {
            oilValue.text = "—"
            oilValue.setTextColor(TEXT)
        }
    }

    // ================= Componentes =================

    private fun open(pkg: String, name: String) {
        if (!Shortcuts.launchPackage(ctx, pkg)) android.widget.Toast.makeText(ctx, "$name no está instalado", android.widget.Toast.LENGTH_SHORT).show()
    }

    private fun openMusic() {
        val saved = Prefs.get(ctx).getString("music_pkg", null)
        if (saved != null && Shortcuts.launchPackage(ctx, saved)) return
        if (!Shortcuts.launchPackage(ctx, MediaPanel.SPOTIFY)) Shortcuts.launch(activity, 0)
    }

    private fun put(v: View, id: String) {
        root.addView(v, FrameLayout.LayoutParams(-2, -2))
        placed.add(Pair(v, id))
    }

    private fun text(color: Int, size: Float, family: String = "sans-serif") = TextView(ctx).apply {
        setTextColor(color)
        typeface = Typeface.create(family, Typeface.NORMAL)
        includeFontPadding = false
        sized.add(Pair(this, size))
    }

    private fun card(radius: Float) = LinearLayout(ctx).apply {
        background = GradientDrawable().apply {
            setColor(CARD)
            setStroke(1, LINE)
            radii.add(Pair(this, radius))
        }
        pads.add(Pair(this, floatArrayOf(10f, 10f, 10f, 10f)))
    }

    private fun pill(color: Int) = GradientDrawable().apply {
        setColor(color)
        setStroke(1, LINE)
        radii.add(Pair(this, 21f))
    }

    private fun stat(label: String, value: TextView) = LinearLayout(ctx).apply {
        orientation = LinearLayout.VERTICAL
        addView(text(MUTED, 10.5f, "sans-serif-medium").apply {
            text = label
            letterSpacing = 0.12f
        })
        addView(value)
        value.setPadding(0, 6, 0, 0)
    }

    private fun round(label: String, action: () -> Unit) = TextView(ctx).apply {
        text = label
        gravity = Gravity.CENTER
        setTextColor(TEXT)
        sized.add(Pair(this, 20f))
        background = GradientDrawable().apply {
            setShape(GradientDrawable.OVAL)
            setColor(SURFACE)
            setStroke(1, LINE)
        }
        elevation = 4f
        setOnClickListener { action() }
    }
}
