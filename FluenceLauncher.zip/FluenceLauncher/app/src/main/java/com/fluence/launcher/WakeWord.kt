package com.fluence.launcher

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import org.json.JSONArray
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import org.vosk.android.RecognitionListener
import org.vosk.android.SpeechService
import org.vosk.android.StorageService

/**
 * Palabra de activación sin internet ("Oye copiloto"), con el reconocedor Vosk en español.
 * Solo escucha esa frase; al oírla suelta el micrófono y abre el reconocimiento del comando.
 */
object WakeWord {

    val PHRASES = listOf("oye copiloto", "hola copiloto", "oye carro", "hola auto")

    private const val ASSET_DIR = "model-es"
    private val main = Handler(Looper.getMainLooper())

    var model: Model? = null
        private set
    private var loading = false
    private var service: SpeechService? = null
    private var wanted = false
    private var lastTrigger = 0L
    private var appCtx: Context? = null
    private var listeningPhrase = ""
    private val onModelReady = ArrayList<(Model?) -> Unit>()

    fun enabled(ctx: Context) = Prefs.get(ctx).getBoolean(Prefs.WAKE_ENABLED, true)
    fun background(ctx: Context) = Prefs.get(ctx).getBoolean(Prefs.WAKE_BACKGROUND, false)
    fun phrase(ctx: Context): String = Prefs.get(ctx).getString(Prefs.WAKE_PHRASE, PHRASES[0]) ?: PHRASES[0]

    fun hasMic(ctx: Context) =
        ctx.checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    fun hasModel(ctx: Context): Boolean = try {
        ctx.assets.list(ASSET_DIR)?.isNotEmpty() == true
    } catch (e: Exception) {
        false
    }

    /** Frase bonita para mostrar: «Oye copiloto». */
    fun display(ctx: Context): String = phrase(ctx).replaceFirstChar { it.uppercase() }

    /** Empieza a escuchar (no hace nada si ya está escuchando o si está desactivado). */
    fun start(ctx: Context) {
        appCtx = ctx.applicationContext
        wanted = true
        val c = appCtx ?: return
        if (!enabled(c) || !hasMic(c) || !hasModel(c)) return
        // Si cambió la frase, reiniciar con la nueva
        if (service != null && listeningPhrase != phrase(c)) release()
        if (service != null) return
        withModel(c) { m -> if (m != null && wanted && service == null) begin(c, m) }
    }

    /** Deja de escuchar (al salir del inicio, salvo que esté activado "en segundo plano"). */
    fun stop() {
        wanted = false
        release()
    }

    /** Carga el modelo (la primera vez se copia a la memoria de la radio, ~15 s). */
    fun withModel(ctx: Context, cb: (Model?) -> Unit) {
        model?.let { cb(it); return }
        onModelReady.add(cb)
        if (loading) return
        loading = true
        StorageService.unpack(ctx.applicationContext, ASSET_DIR, "vosk",
            { m ->
                loading = false
                model = m
                val cbs = onModelReady.toList()
                onModelReady.clear()
                for (f in cbs) f(m)
            },
            { _ ->
                loading = false
                val cbs = onModelReady.toList()
                onModelReady.clear()
                for (f in cbs) f(null)
            })
    }

    private fun begin(ctx: Context, m: Model) {
        try {
            val p = phrase(ctx)
            val grammar = JSONArray().put(p).put("[unk]").toString()
            val rec = Recognizer(m, 16000f, grammar)
            val s = SpeechService(rec, 16000f)
            s.startListening(listener)
            service = s
            listeningPhrase = p
        } catch (e: Exception) {
            service = null
            // El micrófono puede estar ocupado (llamada, CarPlay): reintentar más tarde
            main.postDelayed({ appCtx?.let { if (wanted) start(it) } }, 10_000L)
        }
    }

    private fun release() {
        val s = service ?: return
        service = null
        try {
            s.stop()
            s.shutdown()
        } catch (e: Exception) { }
    }

    private val listener = object : RecognitionListener {
        override fun onPartialResult(hypothesis: String?) = check(hypothesis, "partial")
        override fun onResult(hypothesis: String?) = check(hypothesis, "text")
        override fun onFinalResult(hypothesis: String?) = check(hypothesis, "text")
        override fun onError(exception: Exception?) {
            release()
            main.postDelayed({ appCtx?.let { if (wanted) start(it) } }, 5_000L)
        }
        override fun onTimeout() {}
    }

    private fun check(json: String?, key: String) {
        if (json == null || listeningPhrase.isEmpty()) return
        val heard = try { JSONObject(json).optString(key, "") } catch (e: Exception) { "" }
        if (heard.contains(listeningPhrase)) trigger()
    }

    private fun trigger() {
        val now = SystemClock.elapsedRealtime()
        if (now - lastTrigger < 3_000L) return
        lastTrigger = now
        val c = appCtx ?: return
        // Soltar el micrófono para que se pueda escuchar el comando
        release()
        beep()
        c.startActivity(Intent(c, VoiceActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    /** Llamado al cerrar la ventana de voz: volver a escuchar la frase. */
    fun resumeAfterCommand(ctx: Context) {
        if (wanted) main.postDelayed({ start(ctx) }, 800L)
    }

    private fun beep() {
        try {
            val tg = ToneGenerator(AudioManager.STREAM_MUSIC, 70)
            tg.startTone(ToneGenerator.TONE_PROP_BEEP, 150)
            main.postDelayed({ tg.release() }, 400L)
        } catch (e: Exception) { }
    }
}
