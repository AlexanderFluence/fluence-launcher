package com.fluence.launcher

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager

/**
 * La palabra de activación sin internet ("Oye copiloto") se quitó en la v1.9:
 * el modelo de voz pesaba ~60 MB y ponía lenta la radio.
 * Se deja esta versión vacía para que el resto del código no cambie.
 */
object WakeWord {
    val PHRASES = listOf("oye copiloto")
    fun enabled(ctx: Context) = false
    fun background(ctx: Context) = false
    fun phrase(ctx: Context) = PHRASES[0]
    fun display(ctx: Context) = "Oye copiloto"
    fun hasModel(ctx: Context) = false
    fun hasMic(ctx: Context) =
        ctx.checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
    fun start(ctx: Context) {}
    fun stop() {}
    fun resumeAfterCommand(ctx: Context) {}
}
