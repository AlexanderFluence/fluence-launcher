package com.fluence.launcher

import android.content.Context
import android.location.Geocoder
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

/** Nombre de la calle o avenida en una coordenada. Se ejecuta en segundo plano. */
object StreetName {

    fun lookup(ctx: Context, lat: Double, lon: Double): String? =
        fromGeocoder(ctx, lat, lon) ?: fromOpenStreetMap(lat, lon)

    /** Servicio de Android (funciona si la radio tiene servicios de Google). */
    @Suppress("DEPRECATION")
    private fun fromGeocoder(ctx: Context, lat: Double, lon: Double): String? = try {
        if (!Geocoder.isPresent()) {
            null
        } else {
            val list = Geocoder(ctx, Locale("es")).getFromLocation(lat, lon, 1)
            list?.firstOrNull()?.thoroughfare?.takeIf { it.isNotBlank() }
        }
    } catch (e: Exception) {
        null
    }

    /** Respaldo con OpenStreetMap (para radios sin servicios de Google). */
    private fun fromOpenStreetMap(lat: Double, lon: Double): String? {
        var conn: HttpURLConnection? = null
        return try {
            val url = URL(
                String.format(
                    Locale.US,
                    "https://nominatim.openstreetmap.org/reverse?format=jsonv2&lat=%.6f&lon=%.6f&zoom=17&accept-language=es",
                    lat, lon
                )
            )
            conn = url.openConnection() as HttpURLConnection
            conn.connectTimeout = 6000
            conn.readTimeout = 6000
            conn.setRequestProperty("User-Agent", "FluenceLauncher/1.2 (Android car launcher)")
            if (conn.responseCode != 200) return null
            val body = conn.inputStream.bufferedReader().use { it.readText() }
            val address = JSONObject(body).optJSONObject("address") ?: return null
            for (key in arrayOf("road", "pedestrian", "residential", "neighbourhood", "suburb")) {
                val v = address.optString(key, "")
                if (v.isNotBlank()) return v
            }
            null
        } catch (e: Exception) {
            null
        } finally {
            conn?.disconnect()
        }
    }
}
