package com.fluence.launcher

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/**
 * Canción actual de Spotify SIN necesitar "Acceso a notificaciones".
 * Spotify avisa a otras apps qué está sonando si en Spotify se activa
 * "Estado de transmisión del dispositivo" (Device Broadcast Status).
 */
object SpotifyBroadcast {

    private const val ACTION_META = "com.spotify.music.metadatachanged"
    private const val ACTION_STATE = "com.spotify.music.playbackstatechanged"

    var hasData = false
        private set
    var trackId = ""
        private set
    var title = ""
        private set
    var artist = ""
        private set
    var lengthMs = 0L
        private set
    var playing = false
        private set
    var art: Bitmap? = null
        private set

    private var positionMs = 0L
    private var positionAt = 0L
    private var artFor = ""

    private val main = Handler(Looper.getMainLooper())
    private val listeners = LinkedHashSet<() -> Unit>()
    private var registered = false

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            when (intent.action) {
                ACTION_META -> {
                    hasData = true
                    val id = intent.getStringExtra("id") ?: ""
                    title = intent.getStringExtra("track") ?: ""
                    artist = intent.getStringExtra("artist") ?: ""
                    // Spotify a veces lo manda en segundos y a veces en milisegundos
                    val len = intent.getIntExtra("length", 0).toLong()
                    lengthMs = if (len in 1..19_999) len * 1000 else len
                    if (id != trackId) {
                        trackId = id
                        art = null
                        positionMs = 0
                        positionAt = SystemClock.elapsedRealtime()
                        loadArt(id)
                    }
                    if (intent.hasExtra("playing")) playing = intent.getBooleanExtra("playing", playing)
                }
                ACTION_STATE -> {
                    hasData = true
                    playing = intent.getBooleanExtra("playing", false)
                    positionMs = intent.getIntExtra("playbackPosition", 0).toLong()
                    positionAt = SystemClock.elapsedRealtime()
                }
            }
            notifyListeners()
        }
    }

    fun register(ctx: Context) {
        if (registered) return
        registered = true
        val f = IntentFilter().apply {
            addAction(ACTION_META)
            addAction(ACTION_STATE)
        }
        try { ctx.applicationContext.registerReceiver(receiver, f) } catch (e: Exception) { registered = false }
    }

    fun addListener(l: () -> Unit) { listeners.add(l) }
    fun removeListener(l: () -> Unit) { listeners.remove(l) }

    /** Posición estimada en este momento (0..lengthMs). */
    fun positionNow(): Long {
        var pos = positionMs
        if (playing && positionAt > 0) pos += SystemClock.elapsedRealtime() - positionAt
        return if (lengthMs > 0) pos.coerceIn(0L, lengthMs) else pos
    }

    /** Al tocar los botones se asume el cambio de inmediato, sin esperar a Spotify. */
    fun assumePlaying(p: Boolean) {
        if (!hasData) return
        positionMs = positionNow()
        positionAt = SystemClock.elapsedRealtime()
        playing = p
        notifyListeners()
    }

    private fun notifyListeners() {
        for (l in listeners.toList()) l()
    }

    /** Carátula desde la página pública de Spotify (oEmbed), en segundo plano. */
    private fun loadArt(id: String) {
        val trackPart = id.removePrefix("spotify:track:")
        if (trackPart.isBlank() || trackPart.contains(":") || artFor == id) return
        artFor = id
        Thread {
            val bmp = try {
                val json = fetch("https://open.spotify.com/oembed?url=https://open.spotify.com/track/$trackPart")
                val thumb = json?.let { JSONObject(it).optString("thumbnail_url", "") }.orEmpty()
                if (thumb.isEmpty()) null else download(thumb)
            } catch (e: Exception) {
                null
            }
            main.post {
                if (trackId == id && bmp != null) {
                    art = bmp
                    notifyListeners()
                }
            }
        }.start()
    }

    private fun open(url: String): HttpURLConnection {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 6000
        c.readTimeout = 6000
        c.setRequestProperty("User-Agent", "FluenceLauncher/1.4 (Android car launcher)")
        return c
    }

    private fun fetch(url: String): String? {
        val c = open(url)
        return try {
            if (c.responseCode != 200) null else c.inputStream.bufferedReader().use { it.readText() }
        } finally {
            c.disconnect()
        }
    }

    private fun download(url: String): Bitmap? {
        val c = open(url)
        return try {
            if (c.responseCode != 200) null else c.inputStream.use { BitmapFactory.decodeStream(it) }
        } finally {
            c.disconnect()
        }
    }
}
