package com.fluence.launcher

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.location.Location
import android.location.LocationManager
import android.os.Bundle
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import kotlin.math.roundToInt

/** Mapa en vivo a pantalla completa con el nombre de la calle actual y la velocidad. */
class MapActivity : Activity(), LocationHub.Listener {

    private val dp by lazy { resources.displayMetrics.density }
    private lateinit var map: LiveMap
    private lateinit var streetText: TextView
    private lateinit var speedText: TextView
    private lateinit var recenterBtn: View
    private lateinit var compassBtn: ImageView
    private var hasStreet = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        val root = FrameLayout(this).apply { setBackgroundColor(Color.rgb(14, 24, 44)) }
        map = LiveMap(this, true)
        root.addView(map.view, FrameLayout.LayoutParams(-1, -1))

        // Panel con calle y velocidad
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            val p = (14 * dp).toInt()
            setPadding(p + (4 * dp).toInt(), p, p + (4 * dp).toInt(), p)
            background = GradientDrawable().apply {
                setCornerRadius(16 * dp)
                setColor(Color.argb(225, 11, 20, 36))
                setStroke((1 * dp).toInt().coerceAtLeast(1), Color.argb(110, 34, 211, 238))
            }
            elevation = 6 * dp
        }
        streetText = TextView(this).apply {
            text = "Buscando señal GPS…"
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 22f)
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
            maxLines = 2
            ellipsize = TextUtils.TruncateAt.END
        }
        speedText = TextView(this).apply {
            text = "-- km/h"
            setTextColor(Color.rgb(103, 232, 249))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 17f)
            setPadding(0, (4 * dp).toInt(), 0, 0)
        }
        panel.addView(streetText)
        panel.addView(speedText)
        root.addView(panel, FrameLayout.LayoutParams((340 * dp).toInt(), -2, Gravity.TOP or Gravity.START).apply {
            leftMargin = (16 * dp).toInt()
            topMargin = (16 * dp).toInt()
        })

        // Botón cerrar
        root.addView(roundIcon(R.drawable.ic_close) { finish() },
            FrameLayout.LayoutParams(size(), size(), Gravity.TOP or Gravity.END).apply {
                rightMargin = (16 * dp).toInt()
                topMargin = (16 * dp).toInt()
            })

        // Controles a la derecha
        val controls = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
        }
        controls.addView(roundText("+") { map.zoomIn() }, column())
        controls.addView(roundText("−") { map.zoomOut() }, column())
        compassBtn = roundIcon(R.drawable.ic_navigation) { toggleHeading() }
        controls.addView(compassBtn, column())
        root.addView(controls, FrameLayout.LayoutParams(-2, -2, Gravity.END or Gravity.CENTER_VERTICAL).apply {
            rightMargin = (16 * dp).toInt()
        })

        // Volver a centrar (aparece cuando el usuario mueve el mapa)
        recenterBtn = pill("Centrar en mi auto") { map.recenter() }.apply { visibility = View.GONE }
        root.addView(recenterBtn, FrameLayout.LayoutParams(-2, (52 * dp).toInt(), Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply {
            bottomMargin = (20 * dp).toInt()
        })
        map.onFollowChanged = { following -> recenterBtn.visibility = if (following) View.GONE else View.VISIBLE }

        // Atribución exigida por OpenStreetMap
        root.addView(TextView(this).apply {
            text = "© OpenStreetMap"
            setTextColor(Color.argb(200, 255, 255, 255))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
            val p = (4 * dp).toInt()
            setPadding(p * 2, p, p * 2, p)
            setBackgroundColor(Color.argb(140, 0, 0, 0))
        }, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.START))

        updateCompassIcon()
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        map.onResume()
        if (LocationHub.hasPermission(this)) {
            LocationHub.add(this, this)
        } else {
            requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), REQ_LOCATION)
        }
    }

    override fun onPause() {
        super.onPause()
        map.onPause()
        LocationHub.remove(this, this)
    }

    override fun onDestroy() {
        super.onDestroy()
        map.onDestroy()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ_LOCATION && grantResults.isNotEmpty() &&
            grantResults[0] == PackageManager.PERMISSION_GRANTED
        ) {
            LocationHub.add(this, this)
        } else if (requestCode == REQ_LOCATION) {
            streetText.text = "Sin permiso de ubicación"
        }
    }

    // ---------- GPS ----------

    override fun onLocation(loc: Location) {
        map.update(loc)
        val fromGps = loc.provider == LocationManager.GPS_PROVIDER
        speedText.text = if (fromGps && loc.hasSpeed()) "${(loc.speed * 3.6f).roundToInt()} km/h" else "-- km/h"
        if (!hasStreet) streetText.text = "Ubicación en vivo"
    }

    override fun onStreet(name: String) {
        hasStreet = true
        streetText.text = name
    }

    override fun onGpsLost() {
        speedText.text = "GPS desactivado"
    }

    private fun toggleHeading() {
        map.setHeadingUp(!map.headingUp)
        updateCompassIcon()
        Toast.makeText(this, if (map.headingUp) "Dirección del auto arriba" else "Norte arriba", Toast.LENGTH_SHORT).show()
    }

    private fun updateCompassIcon() {
        compassBtn.imageTintList = ColorStateList.valueOf(
            if (map.headingUp) Color.rgb(34, 211, 238) else Color.WHITE
        )
    }

    // ---------- Botones ----------

    private fun size() = (56 * dp).toInt()

    private fun column() = LinearLayout.LayoutParams(size(), size()).apply {
        bottomMargin = (12 * dp).toInt()
    }

    private fun circle() = GradientDrawable().apply {
        setShape(GradientDrawable.OVAL)
        setColor(Color.argb(225, 11, 20, 36))
        setStroke((1 * dp).toInt().coerceAtLeast(1), Color.argb(130, 34, 211, 238))
    }

    private fun roundIcon(icon: Int, action: () -> Unit) = ImageView(this).apply {
        setImageResource(icon)
        val p = (15 * dp).toInt()
        setPadding(p, p, p, p)
        background = circle()
        elevation = 6 * dp
        setOnClickListener { action() }
    }

    private fun roundText(label: String, action: () -> Unit) = TextView(this).apply {
        text = label
        gravity = Gravity.CENTER
        setTextColor(Color.WHITE)
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 26f)
        background = circle()
        elevation = 6 * dp
        setOnClickListener { action() }
    }

    private fun pill(label: String, action: () -> Unit) = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        val ph = (18 * dp).toInt()
        setPadding(ph, 0, ph + (4 * dp).toInt(), 0)
        background = GradientDrawable().apply {
            setCornerRadius(26 * dp)
            setColor(Color.rgb(28, 50, 96))
            setStroke((1.5f * dp).toInt().coerceAtLeast(1), Color.rgb(34, 211, 238))
        }
        elevation = 6 * dp
        addView(ImageView(this@MapActivity).apply { setImageResource(R.drawable.ic_my_location) },
            LinearLayout.LayoutParams((24 * dp).toInt(), (24 * dp).toInt()))
        addView(TextView(this@MapActivity).apply {
            text = label
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
            setPadding((10 * dp).toInt(), 0, 0, 0)
        })
        setOnClickListener { action() }
    }

    companion object {
        private const val REQ_LOCATION = 78
    }
}
