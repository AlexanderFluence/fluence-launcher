package com.fluence.launcher;

import android.media.MediaMetadata;
import android.media.session.MediaController;
import android.media.session.PlaybackState;

/** Avisa con un Runnable cada vez que cambia la canción o el estado de reproducción. */
public class SimpleMediaCallback extends MediaController.Callback {
    private final Runnable onChange;
    private final Runnable onGone;

    public SimpleMediaCallback(Runnable onChange, Runnable onGone) {
        this.onChange = onChange;
        this.onGone = onGone;
    }

    @Override
    public void onPlaybackStateChanged(PlaybackState state) {
        onChange.run();
    }

    @Override
    public void onMetadataChanged(MediaMetadata metadata) {
        onChange.run();
    }

    @Override
    public void onSessionDestroyed() {
        onGone.run();
    }
}
