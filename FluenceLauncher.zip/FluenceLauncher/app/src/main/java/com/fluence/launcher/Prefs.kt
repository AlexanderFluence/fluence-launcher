package com.fluence.launcher

import android.content.Context
import android.content.SharedPreferences

object Prefs {
    const val NAME = "name"
    const val CAR_VERSION = "car_version"
    const val SHOW_SPEED = "show_speed"
    const val ANIMATE_ROAD = "animate_road"
    const val EQ_ENABLED = "eq_enabled"
    const val EQ_BAND = "eq_band_"
    const val BASS = "bass"
    const val LOUD = "loud"
    const val LANE_PKG = "lane_pkg_"
    const val CARPLAY_PKG = "carplay_pkg"
    const val MAP_HOME = "map_home"
    const val MAP_DARK = "map_dark"
    const val LAST_LAT = "last_lat"
    const val LAST_LON = "last_lon"
    const val HOME_STYLE = "home_style"
    const val NAV_APP = "nav_app"
    const val DEST_HOME = "dest_home"
    const val DEST_WORK = "dest_work"
    const val DEST_LAST = "dest_last"
    const val WEATHER = "weather_cache"

    fun get(ctx: Context): SharedPreferences =
        ctx.applicationContext.getSharedPreferences("launcher", Context.MODE_PRIVATE)
}
