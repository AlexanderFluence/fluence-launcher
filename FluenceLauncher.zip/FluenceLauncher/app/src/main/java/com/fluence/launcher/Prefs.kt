package com.fluence.launcher

import android.content.Context
import android.content.SharedPreferences

object Prefs {
    const val NAME = "name"
    const val CAR_VERSION = "car_version"
    const val SHOW_SPEED = "show_speed"
    const val ANIMATE_ROAD = "animate_road"
    const val EQ_ENABLED = "eq_enabled"
    const val EQ_BAND = "eq_band_"
    const val BASS = "bass"
    const val LOUD = "loud"
    const val LANE_PKG = "lane_pkg_"
    const val CARPLAY_PKG = "carplay_pkg"

    fun get(ctx: Context): SharedPreferences =
        ctx.applicationContext.getSharedPreferences("launcher", Context.MODE_PRIVATE)
}
