package com.fluence.launcher

import android.content.Context
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.location.Location
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import java.util.Locale
import kotlin.math.roundToInt

/**
 * Estilo "Moderno": fondo negro, reloj, Spotify arriba al centro, odómetro y viaje,
 * el auto al centro, avisos de mantenimiento y una barra de accesos abajo.
 */
class ModernHome(private val activity: MainActivity) : HomeScreen, Odometer.Listener {

    private val ctx: Context = activity
    private val dp = activity.resources.displayMetrics.density
    private val es = Locale("es")

    override val root = object : FrameLayout(activity) {
        // Fondo negro con un halo suave detrás del auto
        private val glow = Paint(Paint.ANTI_ALIAS_FLAG)
        init { setWillNotDraw(false) }
        override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
            super.onSizeChanged(w, h, ow, oh)
            glow.shader = RadialGradient(
                w * 0.5f, h * 0.52f, w * 0.42f,
                Color.rgb(26, 30, 40), Color.rgb(6, 7, 10), Shader.TileMode.CLAMP
            )
        }
        override fun onDraw(canvas: Canvas) {
            canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), glow)
        }
    }

    private val time = text(Color.WHITE, "sans-serif-light")
    private val date = text(Color.rgb(150, 158, 172), "sans-serif")
    private val media = MediaPanel(activity)

    private val speed = text(Color.WHITE, "sans-serif-light")
    private val street = text(Color.rgb(200, 206, 218), "sans-serif-medium")
    private val streetChip = LinearLayout(activity)

    private val odoBlock = LinearLayout(activity)
    private val odoValue = text(Color.WHITE, "sans-serif-light")
    private val odoUnit = text(Color.rgb(150, 158, 172), "sans-serif-light")
    private val trip = text(Color.rgb(150, 158, 172), "sans-serif")

    private val car = CarView(activity)

    private val attention = LinearLayout(activity)
    private val dock = LinearLayout(activity)
    private val dockLabels = HashMap<Int, TextView>()

    private var lastAttentionKm = -1L
    private var speedSize = 0f

    init {
        // ---- Reloj ----
        root.addView(time, FrameLayout.LayoutParams(-2, -2))
        root.addView(date, FrameLayout.LayoutParams(-2, -2))

        // ---- Spotify arriba al centro ----
        media.useFlatStyle()
        root.addView(media.view, FrameLayout.LayoutParams(0, 0))

        // ---- Velocidad y calle arriba a la derecha ----
        speed.gravity = Gravity.END
        root.addView(speed, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.END))
        streetChip.apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            val ph = (12 * dp).toInt()
            setPadding(ph, (5 * dp).toInt(), ph, (5 * dp).toInt())
            background = GradientDrawable().apply {
                setCornerRadius(16 * dp)
                setColor(Color.TRANSPARENT)
                setStroke((1 * dp).toInt().coerceAtLeast(1), Color.rgb(70, 60, 30))
            }
            addView(ImageView(activity).apply {
                setImageResource(R.drawable.ic_place)
                imageTintList = ColorStateList.valueOf(Color.rgb(251, 191, 36))
            }, LinearLayout.LayoutParams((14 * dp).toInt(), (14 * dp).toInt()))
            street.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
            street.maxLines = 1
            street.ellipsize = TextUtils.TruncateAt.END
            street.setPadding((6 * dp).toInt(), 0, 0, 0)
            addView(street)
            visibility = View.GONE
            setOnClickListener { activity.startActivity(Intent(activity, MapActivity::class.java)) }
        }
        root.addView(streetChip, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.END))

        // ---- Odómetro ----
        odoBlock.orientation = LinearLayout.VERTICAL
        odoBlock.addView(label("ODÓMETRO"))
        val row = LinearLayout(activity).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.BOTTOM
        }
        row.addView(odoValue)
        odoUnit.text = " km"
        row.addView(odoUnit)
        odoBlock.addView(row)
        odoBlock.addView(trip)
        odoBlock.setOnClickListener {
            if (Odometer.isSet(ctx)) activity.startActivity(Intent(activity, MaintenanceActivity::class.java))
            else MaintenanceActivity.askOdometer(activity) { lastAttentionKm = -1; updateAttention() }
        }
        odoBlock.setOnLongClickListener {
            it.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
            MaintenanceActivity.askOdometer(activity) { lastAttentionKm = -1; updateAttention() }
            true
        }
        root.addView(odoBlock, FrameLayout.LayoutParams(-2, -2))

        // ---- Auto ----
        car.setOnLongClickListener {
            activity.onCarLongClick()
            true
        }
        root.addView(car, FrameLayout.LayoutParams(0, 0))

        // ---- Avisos ----
        attention.orientation = LinearLayout.VERTICAL
        attention.setOnClickListener { activity.startActivity(Intent(activity, MaintenanceActivity::class.java)) }
        root.addView(attention, FrameLayout.LayoutParams(0, -2))

        // ---- Barra de accesos ----
        dock.orientation = LinearLayout.HORIZONTAL
        dock.gravity = Gravity.CENTER_VERTICAL
        dockItem(R.drawable.ic_apps, "Apps") { Shortcuts.launch(activity, 0) }
        dockItem(R.drawable.ic_navigation, "Navegación", lane = 2) { Shortcuts.launch(activity, 2) }
        dockItem(R.drawable.ic_map, "Mapa") { activity.startActivity(Intent(activity, MapActivity::class.java)) }
        dockItem(R.drawable.ic_phone, "Llamadas", lane = 1) { Shortcuts.launch(activity, 1) }
        dockItem(R.drawable.ic_music, "Spotify") {
            if (!Shortcuts.launchPackage(activity, MediaPanel.SPOTIFY)) Shortcuts.launch(activity, 0)
        }
        dockItem(R.drawable.ic_car, "CarPlay", onLong = { activity.onCarPlayLongClick() }) { CarPlay.open(activity) }
        dockItem(R.drawable.ic_build, "Mantenimiento") {
            activity.startActivity(Intent(activity, MaintenanceActivity::class.java))
        }
        dockItem(R.drawable.ic_settings, "Ajustes") {
            activity.startActivity(Intent(activity, SettingsActivity::class.java))
        }
        root.addView(dock, FrameLayout.LayoutParams(-1, 0))

        root.addOnLayoutChangeListener { _, l, t, r, b, ol, ot, or_, ob ->
            if (r - l != or_ - ol || b - t != ob - ot) layout(r - l, b - t)
        }
    }

    /** Coloca todo según el tamaño de la pantalla (pensado para 1024×600 y 1280×720). */
    private fun layout(w: Int, h: Int) {
        val padX = (0.035f * w).toInt()

        time.setTextSize(TypedValue.COMPLEX_UNIT_PX, 0.13f * h)
        date.setTextSize(TypedValue.COMPLEX_UNIT_PX, 0.036f * h)
        setPos(time, padX, (0.025f * h).toInt())
        setPos(date, padX + (0.004f * w).toInt(), (0.025f * h + 0.155f * h).toInt())

        val playerW = (0.38f * w).toInt()
        val playerH = maxOf((0.17f * h).toInt(), (100 * dp).toInt())
        val playerTop = (0.035f * h).toInt()
        media.placeAt((w - playerW) / 2, playerTop, playerW, playerH)

        speedSize = 0.05f * h
        speed.setTextSize(TypedValue.COMPLEX_UNIT_PX, speedSize)
        setPosEnd(speed, padX, (0.04f * h).toInt())
        (streetChip.layoutParams as FrameLayout.LayoutParams).apply {
            rightMargin = padX
            topMargin = (0.04f * h + speedSize * 1.6f).toInt()
            width = -2
        }
        street.maxWidth = (0.22f * w).toInt()
        streetChip.requestLayout()

        odoValue.setTextSize(TypedValue.COMPLEX_UNIT_PX, 0.092f * h)
        odoUnit.setTextSize(TypedValue.COMPLEX_UNIT_PX, 0.04f * h)
        trip.setTextSize(TypedValue.COMPLEX_UNIT_PX, 0.034f * h)
        setPos(odoBlock, padX, (0.36f * h).toInt())

        val carTop = maxOf((0.27f * h).toInt(), playerTop + playerH + (10 * dp).toInt())
        val carBottom = (0.76f * h).toInt()
        (car.layoutParams as FrameLayout.LayoutParams).apply {
            width = (0.40f * w).toInt()
            height = carBottom - carTop
            leftMargin = (0.30f * w).toInt()
            topMargin = carTop
        }
        car.requestLayout()

        (attention.layoutParams as FrameLayout.LayoutParams).apply {
            width = (0.25f * w).toInt()
            leftMargin = (0.72f * w).toInt()
            topMargin = (0.34f * h).toInt()
        }
        attention.requestLayout()

        val dockH = (0.17f * h).toInt()
        (dock.layoutParams as FrameLayout.LayoutParams).apply {
            height = dockH
            gravity = Gravity.BOTTOM
            leftMargin = (0.03f * w).toInt()
            rightMargin = (0.03f * w).toInt()
            bottomMargin = (0.02f * h).toInt()
        }
        dock.requestLayout()
    }

    private fun setPos(v: View, left: Int, top: Int) {
        val lp = v.layoutParams as FrameLayout.LayoutParams
        lp.gravity = Gravity.TOP or Gravity.START
        lp.leftMargin = left
        lp.topMargin = top
        v.layoutParams = lp
    }

    private fun setPosEnd(v: View, right: Int, top: Int) {
        val lp = v.layoutParams as FrameLayout.LayoutParams
        lp.gravity = Gravity.TOP or Gravity.END
        lp.rightMargin = right
        lp.topMargin = top
        v.layoutParams = lp
    }

    // ---------- HomeScreen ----------

    override fun setClock(time: String, date: String) {
        this.time.text = time
        this.date.text = date
    }

    override fun setSpeed(kmh: Float) {
        speed.text = if (kmh < 0f) "-- km/h" else "${kmh.roundToInt()} km/h"
    }

    override fun setCar(bmp: Bitmap?) { car.bitmap = bmp }

    override fun onStreet(name: String) {
        street.text = name
        streetChip.visibility = View.VISIBLE
    }

    override fun refresh() {
        val labels = Shortcuts.labels(ctx)
        for ((lane, tv) in dockLabels) tv.text = labels[lane]
        lastAttentionKm = -1
        updateAttention()
    }

    fun reloadLanes() = refresh()

    override fun onResume() {
        Odometer.addListener(ctx, this)
        media.onResume()
    }

    override fun onPause() {
        Odometer.removeListener(this)
        media.onPause()
    }

    override fun onDestroy() = media.onDestroy()

    override fun onOdometer(totalKm: Double, tripKm: Double) {
        if (Odometer.isSet(ctx)) {
            odoValue.text = Maintenance.fmtKm(totalKm)
            odoUnit.visibility = View.VISIBLE
        } else {
            odoValue.text = "Toca aquí"
            odoUnit.visibility = View.GONE
        }
        trip.text = if (Odometer.isSet(ctx)) "Viaje · ${String.format(es, "%.1f", tripKm)} km"
        else "para ingresar los km de tu tablero"
        // Los avisos se recalculan cada km
        if (totalKm.toLong() != lastAttentionKm) updateAttention()
    }

    private fun updateAttention() {
        lastAttentionKm = Odometer.totalKm(ctx).toLong()
        attention.removeAllViews()
        attention.addView(label("ATENCIÓN"))
        val items = Maintenance.urgent(ctx, 3)
        if (items.isEmpty()) {
            attention.addView(text(Color.rgb(150, 158, 172), "sans-serif").apply { text = "Sin recordatorios" })
            return
        }
        for (s in items) {
            val row = LinearLayout(ctx).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(0, (10 * dp).toInt(), 0, 0)
            }
            row.addView(View(ctx).apply {
                background = GradientDrawable().apply {
                    setShape(GradientDrawable.OVAL)
                    setColor(Maintenance.color(s.level))
                }
            }, LinearLayout.LayoutParams((8 * dp).toInt(), (8 * dp).toInt()).apply {
                topMargin = (7 * dp).toInt()
                rightMargin = (10 * dp).toInt()
            })
            val col = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
            col.addView(text(Color.WHITE, "sans-serif").apply {
                text = s.item.name
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
            })
            col.addView(text(Color.rgb(140, 148, 162), "sans-serif").apply {
                text = s.text
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
            })
            row.addView(col, LinearLayout.LayoutParams(0, -2, 1f))
            attention.addView(row)
        }
    }

    // ---------- Componentes ----------

    private fun text(color: Int, family: String) = TextView(ctx).apply {
        setTextColor(color)
        typeface = Typeface.create(family, Typeface.NORMAL)
        includeFontPadding = false
    }

    private fun label(t: String) = text(Color.rgb(120, 128, 142), "sans-serif-medium").apply {
        text = t
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f)
        letterSpacing = 0.14f
        setPadding(0, 0, 0, (4 * dp).toInt())
    }

    private fun dockItem(icon: Int, title: String, lane: Int = -1, onLong: (() -> Unit)? = null, action: () -> Unit) {
        val item = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            val ta = ctx.obtainStyledAttributes(intArrayOf(android.R.attr.selectableItemBackgroundBorderless))
            background = ta.getDrawable(0)
            ta.recycle()
            setOnClickListener {
                it.playSoundEffect(android.view.SoundEffectConstants.CLICK)
                action()
            }
            val longAction: (() -> Unit)? = onLong ?: if (lane in 1..3) ({ activity.onLaneLongClick(lane) }) else null
            if (longAction != null) setOnLongClickListener {
                it.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
                longAction()
                true
            }
        }
        item.addView(ImageView(ctx).apply {
            setImageResource(icon)
            imageTintList = ColorStateList.valueOf(Color.rgb(225, 230, 238))
        }, LinearLayout.LayoutParams((28 * dp).toInt(), (28 * dp).toInt()))
        val tv = text(Color.rgb(150, 158, 172), "sans-serif").apply {
            text = title
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            setPadding(0, (6 * dp).toInt(), 0, 0)
        }
        item.addView(tv)
        if (lane in 0..3) dockLabels[lane] = tv
        dock.addView(item, LinearLayout.LayoutParams(0, -1, 1f))
    }
}
