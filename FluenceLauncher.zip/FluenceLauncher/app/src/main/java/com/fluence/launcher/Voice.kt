package com.fluence.launcher

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.speech.RecognizerIntent
import android.widget.Toast
import java.text.Normalizer

/**
 * Búsqueda y comandos por voz (usa el reconocedor de voz de Google de la radio).
 *
 * Ejemplos:
 *  "llévame a Larcomar" · "ir a casa" · "al trabajo"   → navega con Waze o Google Maps
 *  "abre YouTube" · "abrir Waze"                       → abre la app
 *  "pon Def Leppard" · "reproduce rock en español"     → busca en Spotify
 *  "mapa" · "carplay" · "mantenimiento" · "ajustes"
 *  Cualquier otra frase se toma como destino.
 */
object Voice {
    const val REQUEST = 4201

    /** Abre la ventana "Te escucho…" (Google si está instalado; si no, reconocimiento sin internet). */
    fun start(activity: Activity) {
        activity.startActivity(Intent(activity, VoiceActivity::class.java))
        activity.overridePendingTransition(0, 0)
    }

    /** Si no hay voz, escribir el destino o comando. */
    fun typed(activity: Activity) {
        Navigator.askText(activity, "¿A dónde vamos?", "", "Destino, \"abre YouTube\" o \"pon …\"") {
            handle(activity, it)
        }
    }

    fun onResult(activity: Activity, data: Intent?) {
        val text = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull() ?: return
        handle(activity, text)
    }

    private fun norm(s: String): String =
        Normalizer.normalize(s.lowercase(), Normalizer.Form.NFD).replace(Regex("\\p{Mn}+"), "").trim()

    private fun stripPrefix(text: String, prefixes: List<String>): String? {
        val n = norm(text)
        for (p in prefixes) {
            if (n == p) return ""
            if (n.startsWith("$p ")) {
                // Devolver el resto con sus tildes originales
                val words = p.split(" ").size
                return text.trim().split(Regex("\\s+")).drop(words).joinToString(" ")
            }
        }
        return null
    }

    fun handle(activity: Activity, text: String) {
        val n = norm(text)
        Toast.makeText(activity, "\"$text\"", Toast.LENGTH_SHORT).show()

        // Atajos directos
        when {
            n.endsWith("casa") && n.length <= 18 -> { Navigator.goSaved(activity, Prefs.DEST_HOME, "Casa"); return }
            n.endsWith("trabajo") && n.length <= 20 -> { Navigator.goSaved(activity, Prefs.DEST_WORK, "Trabajo"); return }
            n == "mapa" || n == "abre el mapa" || n == "abrir mapa" -> {
                activity.startActivity(Intent(activity, MapActivity::class.java)); return
            }
            n.contains("carplay") || n.contains("car play") -> { CarPlay.open(activity); return }
            n.contains("mantenimiento") -> {
                activity.startActivity(Intent(activity, MaintenanceActivity::class.java)); return
            }
            n == "ajustes" || n == "configuracion" -> {
                activity.startActivity(Intent(activity, SettingsActivity::class.java)); return
            }
        }

        // Abrir una app
        stripPrefix(text, listOf("abre", "abrir", "abreme", "ejecuta", "inicia"))?.let { name ->
            if (name.isNotBlank() && openApp(activity, name)) return
            if (name.isNotBlank()) {
                Toast.makeText(activity, "No encontré la app \"$name\"", Toast.LENGTH_LONG).show()
                return
            }
        }

        // Música en Spotify
        stripPrefix(text, listOf("pon", "ponme", "reproduce", "reproducir", "escuchar", "quiero escuchar", "toca"))?.let { q ->
            playOnSpotify(activity, q)
            return
        }

        // Navegación
        val dest = stripPrefix(
            text,
            listOf("llevame a", "llevame al", "ir a", "ir al", "vamos a", "vamos al", "navegar a", "navega a", "como llego a", "ruta a")
        ) ?: text
        Navigator.navigate(activity, dest)
    }

    private fun openApp(activity: Activity, name: String): Boolean {
        val target = norm(name).replace(" ", "")
        val pm = activity.packageManager
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = try { pm.queryIntentActivities(launcher, 0) } catch (e: Exception) { emptyList() }
        val match = apps.firstOrNull { norm(it.loadLabel(pm).toString()).replace(" ", "") == target }
            ?: apps.firstOrNull { norm(it.loadLabel(pm).toString()).replace(" ", "").contains(target) }
            ?: return false
        return Shortcuts.launchPackage(activity, match.activityInfo.packageName)
    }

    private fun playOnSpotify(activity: Activity, query: String) {
        if (query.isBlank()) {
            Shortcuts.launchPackage(activity, MediaPanel.SPOTIFY)
            return
        }
        try {
            val i = Intent(Intent.ACTION_VIEW, Uri.parse("spotify:search:" + Uri.encode(query)))
                .setPackage(MediaPanel.SPOTIFY)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            activity.startActivity(i)
        } catch (e: Exception) {
            Toast.makeText(activity, "Spotify no está instalado", Toast.LENGTH_LONG).show()
        }
    }
}
