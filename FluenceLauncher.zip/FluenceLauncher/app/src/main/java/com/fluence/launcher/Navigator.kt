package com.fluence.launcher

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.text.InputType
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Toast

/** Abre la navegación en Waze o Google Maps y guarda Casa, Trabajo y el último destino. */
object Navigator {
    const val WAZE = "waze"
    const val GMAPS = "gmaps"
    private const val WAZE_PKG = "com.waze"
    private const val GMAPS_PKG = "com.google.android.apps.maps"

    fun app(ctx: Context): String =
        if (BuildConfig.PHONE) WAZE else Prefs.get(ctx).getString(Prefs.NAV_APP, WAZE) ?: WAZE

    /** Abre Waze tal cual; si adjacent = true intenta abrirlo en pantalla dividida al lado. */
    fun openWaze(ctx: Context, adjacent: Boolean = false): Boolean {
        val i = ctx.packageManager.getLaunchIntentForPackage(WAZE_PKG) ?: run {
            Toast.makeText(ctx, "Instala Waze desde la Play Store", Toast.LENGTH_LONG).show()
            return false
        }
        var flags = Intent.FLAG_ACTIVITY_NEW_TASK
        if (adjacent) flags = flags or Intent.FLAG_ACTIVITY_LAUNCH_ADJACENT or Intent.FLAG_ACTIVITY_MULTIPLE_TASK
        i.addFlags(flags)
        return try { ctx.startActivity(i); true } catch (e: Exception) { false }
    }
    fun setApp(ctx: Context, a: String) = Prefs.get(ctx).edit().putString(Prefs.NAV_APP, a).apply()

    fun saved(ctx: Context, key: String): String = Prefs.get(ctx).getString(key, "").orEmpty()

    fun navigate(ctx: Context, destination: String) {
        val dest = destination.trim()
        if (dest.isEmpty()) return
        Prefs.get(ctx).edit().putString(Prefs.DEST_LAST, dest).apply()
        val enc = Uri.encode(dest)
        val pm = ctx.packageManager
        val useWaze = app(ctx) == WAZE && pm.getLaunchIntentForPackage(WAZE_PKG) != null
        val intents = if (useWaze) {
            listOf(Intent(Intent.ACTION_VIEW, Uri.parse("https://waze.com/ul?q=$enc&navigate=yes")).setPackage(WAZE_PKG))
        } else {
            listOf(
                Intent(Intent.ACTION_VIEW, Uri.parse("google.navigation:q=$enc")).setPackage(GMAPS_PKG),
                Intent(Intent.ACTION_VIEW, Uri.parse("https://waze.com/ul?q=$enc&navigate=yes")).setPackage(WAZE_PKG),
                Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=$enc"))
            )
        }
        for (i in intents) {
            try {
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                ctx.startActivity(i)
                return
            } catch (e: Exception) { }
        }
        Toast.makeText(ctx, "Instala Waze o Google Maps para navegar", Toast.LENGTH_LONG).show()
    }

    /** Casa / Trabajo: si no está guardado, pide la dirección. */
    fun goSaved(activity: Activity, key: String, title: String) {
        val v = saved(activity, key)
        if (v.isBlank()) askSaved(activity, key, title) else navigate(activity, v)
    }

    fun askSaved(activity: Activity, key: String, title: String, onDone: () -> Unit = {}) {
        askText(activity, "Dirección de $title", saved(activity, key), "Ej: Av. Arequipa 1234, Lima") { text ->
            Prefs.get(activity).edit().putString(key, text).apply()
            Toast.makeText(activity, "$title guardado", Toast.LENGTH_SHORT).show()
            onDone()
        }
    }

    fun askText(activity: Activity, title: String, value: String, hint: String, onOk: (String) -> Unit) {
        val dp = activity.resources.displayMetrics.density
        val input = EditText(activity).apply {
            this.hint = hint
            setText(value)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            setSingleLine(true)
        }
        val box = LinearLayout(activity).apply {
            val p = (20 * dp).toInt()
            setPadding(p, 0, p, 0)
            addView(input, LinearLayout.LayoutParams(-1, -2))
        }
        AlertDialog.Builder(activity)
            .setTitle(title)
            .setView(box)
            .setPositiveButton("Listo") { _, _ ->
                val t = input.text.toString().trim()
                if (t.isNotEmpty()) onOk(t)
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }
}
