package com.fluence.launcher

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.net.Uri
import android.widget.Toast
import java.io.File
import java.io.FileOutputStream
import kotlin.math.abs
import kotlin.math.max

/** Imagen personalizada del auto: elegirla, quitar fondo blanco, recortar y guardar. */
object CarImage {
    const val REQUEST_PICK = 4101
    private const val FILE_NAME = "car.png"
    private const val MAX_SIDE = 1100

    fun file(ctx: Context) = File(ctx.filesDir, FILE_NAME)

    fun pick(activity: Activity) {
        val open = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "image/*"
        }
        try {
            activity.startActivityForResult(open, REQUEST_PICK)
        } catch (e: ActivityNotFoundException) {
            try {
                val get = Intent(Intent.ACTION_GET_CONTENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "image/*"
                }
                activity.startActivityForResult(get, REQUEST_PICK)
            } catch (e2: ActivityNotFoundException) {
                Toast.makeText(activity, "No hay un explorador de archivos en la radio", Toast.LENGTH_LONG).show()
            }
        }
    }

    fun load(ctx: Context): Bitmap? {
        val f = file(ctx)
        if (!f.exists()) return null
        return try {
            BitmapFactory.decodeFile(f.absolutePath)
        } catch (e: Throwable) {
            null
        }
    }

    fun reset(ctx: Context) {
        file(ctx).delete()
        bumpVersion(ctx)
    }

    private fun bumpVersion(ctx: Context) {
        val p = Prefs.get(ctx)
        p.edit().putLong(Prefs.CAR_VERSION, System.currentTimeMillis()).apply()
    }

    /** Se ejecuta en segundo plano. Devuelve true si se guardó bien. */
    fun importFrom(ctx: Context, uri: Uri): Boolean {
        return try {
            val resolver = ctx.contentResolver
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            var sample = 1
            while (max(bounds.outWidth, bounds.outHeight) / sample > MAX_SIDE * 2) sample *= 2
            val opts = BitmapFactory.Options().apply { inSampleSize = sample }
            val decoded = resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
                ?: return false

            var bmp = scaleDown(decoded)
            if (!bmp.isMutable || bmp.config != Bitmap.Config.ARGB_8888) {
                bmp = bmp.copy(Bitmap.Config.ARGB_8888, true)
            }
            removeFlatBackground(bmp)
            val trimmed = trim(bmp)

            FileOutputStream(file(ctx)).use { trimmed.compress(Bitmap.CompressFormat.PNG, 100, it) }
            bumpVersion(ctx)
            true
        } catch (e: Throwable) {
            false
        }
    }

    private fun scaleDown(src: Bitmap): Bitmap {
        val m = max(src.width, src.height)
        if (m <= MAX_SIDE) return src
        val s = MAX_SIDE.toFloat() / m
        return Bitmap.createScaledBitmap(src, (src.width * s).toInt(), (src.height * s).toInt(), true)
    }

    /**
     * Si la foto no tiene transparencia y el fondo es claro y parejo (foto de catálogo),
     * lo vuelve transparente rellenando desde los bordes.
     */
    private fun removeFlatBackground(bmp: Bitmap) {
        val w = bmp.width
        val h = bmp.height
        if (w < 4 || h < 4) return
        val px = IntArray(w * h)
        bmp.getPixels(px, 0, w, 0, 0, w, h)

        // ¿Ya tiene transparencia?
        val corners = intArrayOf(px[0], px[w - 1], px[(h - 1) * w], px[h * w - 1])
        if (corners.any { Color.alpha(it) < 200 }) return

        val ref = corners[0]
        val refBright = (Color.red(ref) + Color.green(ref) + Color.blue(ref)) / 3
        if (refBright < 185) return
        if (corners.any { dist(it, ref) > 60 }) return

        val tol = 48
        val visited = BooleanArray(w * h)
        val stack = IntArray(w * h)
        var sp = 0
        fun push(i: Int) {
            if (!visited[i] && dist(px[i], ref) <= tol) {
                visited[i] = true
                stack[sp++] = i
            }
        }
        for (x in 0 until w) { push(x); push((h - 1) * w + x) }
        for (y in 0 until h) { push(y * w); push(y * w + w - 1) }
        while (sp > 0) {
            val i = stack[--sp]
            px[i] = Color.TRANSPARENT
            val x = i % w
            val y = i / w
            if (x > 0) push(i - 1)
            if (x < w - 1) push(i + 1)
            if (y > 0) push(i - w)
            if (y < h - 1) push(i + w)
        }
        bmp.setPixels(px, 0, w, 0, 0, w, h)
    }

    private fun dist(a: Int, b: Int): Int =
        abs(Color.red(a) - Color.red(b)) + abs(Color.green(a) - Color.green(b)) + abs(Color.blue(a) - Color.blue(b))

    /** Recorta los bordes transparentes para que el auto quede bien apoyado en la carretera. */
    private fun trim(bmp: Bitmap): Bitmap {
        val w = bmp.width
        val h = bmp.height
        val px = IntArray(w * h)
        bmp.getPixels(px, 0, w, 0, 0, w, h)
        var minX = w
        var minY = h
        var maxX = -1
        var maxY = -1
        for (y in 0 until h) {
            val row = y * w
            for (x in 0 until w) {
                if (Color.alpha(px[row + x]) > 24) {
                    if (x < minX) minX = x
                    if (x > maxX) maxX = x
                    if (y < minY) minY = y
                    if (y > maxY) maxY = y
                }
            }
        }
        if (maxX < minX || maxY < minY) return bmp
        if (minX == 0 && minY == 0 && maxX == w - 1 && maxY == h - 1) return bmp
        return Bitmap.createBitmap(bmp, minX, minY, maxX - minX + 1, maxY - minY + 1)
    }
}
