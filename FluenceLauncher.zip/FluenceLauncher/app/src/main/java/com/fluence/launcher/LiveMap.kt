package com.fluence.launcher

import android.content.Context
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.location.Location
import android.view.MotionEvent
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.CustomZoomButtonsController
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Marker
import kotlin.math.abs

/**
 * Mapa de OpenStreetMap con la posición del auto (flecha) que sigue al GPS.
 * Los nombres de calles y avenidas vienen dibujados en el mapa.
 */
class LiveMap(private val ctx: Context, interactive: Boolean, private val forceDark: Boolean? = null) {

    val view: MapView = MapView(ctx)
    private val marker = Marker(view)
    private val dp = ctx.resources.displayMetrics.density

    /** Si es true, el mapa se centra en el auto en cada actualización. */
    var follow = true
        set(value) {
            field = value
            onFollowChanged?.invoke(value)
        }
    var onFollowChanged: ((Boolean) -> Unit)? = null

    var headingUp = false
        private set

    private var bearing = 0f
    private var hasFix = false
    private var last: Location? = null

    init {
        view.setTileSource(TileSourceFactory.MAPNIK)
        // Letras más grandes en pantallas de radio
        view.setTilesScaledToDpi(true)
        view.setMultiTouchControls(interactive)
        view.getZoomController().setVisibility(CustomZoomButtonsController.Visibility.NEVER)

        val tiles = view.getOverlayManager().getTilesOverlay()
        tiles.setLoadingBackgroundColor(Color.rgb(14, 24, 44))
        tiles.setLoadingLineColor(Color.rgb(24, 38, 66))
        applyTheme()

        val p = Prefs.get(ctx)
        val start = GeoPoint(
            p.getFloat(Prefs.LAST_LAT, DEFAULT_LAT).toDouble(),
            p.getFloat(Prefs.LAST_LON, DEFAULT_LON).toDouble()
        )
        view.getController().setZoom(if (interactive) 17.0 else 16.0)
        view.getController().setCenter(start)

        marker.setIcon(ctx.getDrawable(R.drawable.ic_nav_arrow))
        marker.setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_CENTER)
        marker.setFlat(true)
        marker.setPosition(start)
        marker.setEnabled(false)
        marker.setOnMarkerClickListener { _, _ -> true }
        view.getOverlays().add(marker)

        if (interactive) {
            // Al arrastrar el mapa con el dedo se deja de seguir el auto
            var downX = 0f
            var downY = 0f
            view.setOnTouchListener { _, e ->
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> { downX = e.x; downY = e.y }
                    MotionEvent.ACTION_MOVE ->
                        if (follow && (abs(e.x - downX) > 24 * dp || abs(e.y - downY) > 24 * dp)) follow = false
                }
                false
            }
        }
    }

    /** Mapa oscuro (colores invertidos con el mismo tono) o claro según Ajustes. */
    fun applyTheme() {
        val dark = forceDark ?: Prefs.get(ctx).getBoolean(Prefs.MAP_DARK, true)
        view.getOverlayManager().getTilesOverlay().setColorFilter(if (dark) darkFilter() else null)
    }

    fun update(loc: Location) {
        last = loc
        if (loc.hasBearing() && loc.hasSpeed() && loc.speed > 1.5f) bearing = loc.bearing
        val gp = GeoPoint(loc.latitude, loc.longitude)
        marker.setPosition(gp)
        // osmdroid rota en sentido antihorario; el rumbo del GPS es horario
        marker.setRotation(-bearing)
        marker.setEnabled(true)
        if (follow) {
            if (hasFix) view.getController().animateTo(gp) else view.getController().setCenter(gp)
            view.setMapOrientation(if (headingUp) -bearing else 0f)
        }
        hasFix = true
        view.invalidate()
    }

    fun recenter() {
        follow = true
        last?.let { update(it) }
    }

    fun setHeadingUp(on: Boolean) {
        headingUp = on
        view.setMapOrientation(if (on) -bearing else 0f)
        view.invalidate()
    }

    fun zoomIn() { view.getController().zoomIn() }
    fun zoomOut() { view.getController().zoomOut() }

    fun onResume() {
        applyTheme()
        view.onResume()
    }

    fun onPause() = view.onPause()
    fun onDestroy() = view.onDetach()

    companion object {
        // Si nunca hubo GPS, el mapa empieza en Lima
        private const val DEFAULT_LAT = -12.0464f
        private const val DEFAULT_LON = -77.0428f

        private fun darkFilter(): ColorMatrixColorFilter {
            // Invierte el brillo y gira el tono 180°: fondo oscuro, letras claras, colores parecidos
            val m = ColorMatrix(
                floatArrayOf(
                    0.574f, -1.430f, -0.144f, 0f, 255f,
                    -0.426f, -0.430f, -0.144f, 0f, 255f,
                    -0.426f, -1.430f, 0.856f, 0f, 255f,
                    0f, 0f, 0f, 1f, 0f
                )
            )
            // Tinte azul marino para que combine con el launcher
            val tint = ColorMatrix(
                floatArrayOf(
                    0.80f, 0f, 0f, 0f, 4f,
                    0f, 0.85f, 0f, 0f, 10f,
                    0f, 0f, 0.95f, 0f, 26f,
                    0f, 0f, 0f, 1f, 0f
                )
            )
            m.postConcat(tint)
            return ColorMatrixColorFilter(m)
        }
    }
}
