# Fluence Launcher

Pantalla de inicio para radios Android (Android 10) con el estilo de carretera neón:
saludo, reloj grande, tu auto sobre la carretera, velocidad por GPS y accesos a
Todas las apps, Llamadas, Navegación y Ajustes.

**Incluye**
- Tarjeta de Spotify en el inicio (canción, artista, carátula, anterior / reproducir / siguiente).
- Ecualizador global con ajustes rápidos (Graves, Voces, Rock…), graves extra y volumen extra.
- Botón para liberar memoria y app muy liviana (todo se dibuja en una sola vista, sin librerías).
- Mapa en vivo (OpenStreetMap) con nombres de calles, en el inicio y a pantalla completa.
- Botón CarPlay que vuelve a ZLink sin reiniciar la conexión.
- Auto gris por defecto o la foto de tu propio auto (quita el fondo blanco automáticamente).

## Obtener el APK sin PC (con GitHub, gratis)

1. Sube esta carpeta a un repositorio de GitHub.
2. GitHub compila solo el APK (pestaña **Actions**, tarda ~5 minutos).
3. Descarga `FluenceLauncher.apk` desde **Releases** en la página del repositorio.

## Obtener el APK con PC

Abre la carpeta en Android Studio y usa **Build > Build APK(s)**.
El archivo queda en `app/build/outputs/apk/debug/app-debug.apk`.

## Instalar en la radio

1. Copia el APK a una USB, conéctala a la radio y ábrelo con el explorador de archivos.
2. Si pide permiso, activa "Instalar apps de fuentes desconocidas".
3. Presiona el botón Inicio y elige **Fluence Launcher** → "Siempre".
   (O en la app: engranaje ⚙ > "Usar como pantalla de inicio".)
4. Acepta el permiso de ubicación para ver la velocidad.

## Uso

| Acción | Resultado |
|---|---|
| Tocar un nombre en la carretera | Abre ese acceso |
| Mantener presionado Llamadas / Navegación / Ajustes | Asignar otra app |
| Mantener presionado el auto | Cambiar la foto del auto |
| Tocar la tarjeta de música | Abrir Spotify / activar info de la canción |
| Tocar el mapa pequeño | Mapa a pantalla completa |
| Engranaje ⚙ arriba a la derecha | Nombre, sonido, memoria y más |

Si vuelves a la pantalla de inicio original: Ajustes de Android > Apps > Apps predeterminadas > Pantalla de inicio.
